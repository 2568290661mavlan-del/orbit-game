// 30 分钟连续对局浸泡：辅助免伤只为跑满时长，专查崩溃、软锁与实体泄漏。
// 用法: node tools/soak.mjs [分钟] [seed]
import { createWorld, stepWorld, STATE } from '../src/core/sim.mjs';
import { pilotInput } from '../src/platform/autopilot.mjs';
import { loadData, DT } from '../tests/helpers.mjs';

const minutes = Number(process.argv[2] || 30);
const seed = Number(process.argv[3] || 20261125);
const data = loadData();
const w = createWorld(data, seed);
w.session.state = STATE.PLAYING;
w.assistReduction = 1;          // 免伤不是「通关证据」，只是让浸泡能跑满 30 分钟
w.aimMode = 'auto';
w.opened = true;

const total = Math.round(minutes * 60 / DT);
let maxEnt = 0, loops = 0, picked = 0;
const marks = new Set();
const t0 = Date.now();
for (let k = 0; k < total; k++) {
  if (w.session.state === STATE.LEVELUP) {
    // 与探针同一套「自动选第一项」策略，避免卡在升级界面造成假软锁
    const id = w.session.choices[0];
    const { applyUpgrade, applyCombos } = await import('../src/core/upgrades.mjs');
    const { confirmChoice } = await import('../src/core/session.mjs');
    applyUpgrade(w.stats, { id, ...data.upgrades[id] }, w.session.owned);
    applyCombos(w.stats, w.session.owned, data.combos, w.session.combos);
    confirmChoice(w.session, id);
    picked++;
  }
  const ev = stepWorld(w, DT, pilotInput(w));
  if (ev && ev.loop) loops++;
  if (ev && ev.chapter >= 0) marks.add(`chapter${ev.chapter}@${Math.round(w.session.t)}s`);
  const ent = w.enemies.count + w.bullets.count + w.ebullets.count + w.gems.count + w.parts.count;
  if (ent > maxEnt) maxEnt = ent;
  if (w.session.state === STATE.DEAD || w.session.state === STATE.WIN) {
    marks.add(`END ${w.session.state} @${w.session.t.toFixed(1)}s`);
    break;
  }
  if (k % 36000 === 0 && k > 0) marks.add(`alive@${Math.round(w.session.t)}s`);
}
const mem = process.memoryUsage();
console.log(`浸泡 ${minutes} 分钟 | seed ${seed}`);
console.log(`结局状态=${w.session.state} 存活=${w.session.t.toFixed(1)}s 击杀=${w.session.kills} 等级=${w.session.level}`);
console.log(`引爆=${loops} 次 | 升级=${picked} 次 | 实体峰值=${maxEnt} | 当前敌人=${w.enemies.count} 子弹=${w.bullets.count} 宝石=${w.gems.count}`);
console.log(`节点标记: ${[...marks].join(' | ')}`);
console.log(`Node 内存: heapUsed ${(mem.heapUsed / 1048576).toFixed(1)} MB | RSS ${(mem.rss / 1048576).toFixed(1)} MB`);
console.log(`耗时 ${(Date.now() - t0) / 1000}s（未崩溃、未抛异常即通过）`);

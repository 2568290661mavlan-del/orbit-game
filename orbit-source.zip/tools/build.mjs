// 一键构建：把 ESM 源码 + 全部 json 数据打包内联成单文件 build/index.html。
// 产物完全离线、file:// 双击即玩，不依赖服务器、网络或账号。
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync, statSync, readdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

// CC0 音效内联为 base64：产物仍是单文件，完全离线，不发起任何外部请求。
const audioDir = join(root, 'assets/audio');
const sfx = {};
let audioBytes = 0;
if (existsSync(audioDir)) {
  for (const f of readdirSync(audioDir)) {
    if (!f.endsWith('.ogg')) continue;
    const buf = readFileSync(join(audioDir, f));
    audioBytes += buf.length;
    sfx[f.replace(/\.ogg$/, '')] = buf.toString('base64');
  }
}

// CC0 真实 sprite 内联为 dataURL：同样零外部请求，双击即玩。
const spriteDir = join(root, 'assets/sprites');
const sprites = {};
let spriteBytes = 0;
if (existsSync(spriteDir)) {
  for (const f of readdirSync(spriteDir)) {
    if (!f.endsWith('.png')) continue;
    const buf = readFileSync(join(spriteDir, f));
    spriteBytes += buf.length;
    sprites[f.replace(/\.png$/, '')] = `data:image/png;base64,${buf.toString('base64')}`;
  }
}

const result = await build({
  entryPoints: [join(root, 'src/main.mjs')],
  bundle: true,
  format: 'iife',
  target: ['chrome100', 'firefox100', 'safari15'],
  minify: true,
  legalComments: 'none',
  write: false,
  logLevel: 'warning',
});

const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const template = readFileSync(join(root, 'tools/template.html'), 'utf8');
if (!template.includes('__BUNDLE__')) throw new Error('模板缺少 __BUNDLE__ 占位符');
const sfxJs = `window.__ORBIT_SFX=${JSON.stringify(sfx)};window.__ORBIT_SPRITES=${JSON.stringify(sprites)};`;
const html = template.replace('__BUNDLE__', () => sfxJs + js);

const outDir = join(root, 'build');
mkdirSync(outDir, { recursive: true });
const outFile = join(outDir, 'index.html');
writeFileSync(outFile, html, 'utf8');

const kb = (statSync(outFile).size / 1024).toFixed(1);
console.log(`[build] ${outFile}`);
console.log(`[build] 单文件体积 ${kb} KB（含 ${Object.keys(sfx).length} 个 CC0 音效 ${(audioBytes / 1024).toFixed(1)} KB + ${Object.keys(sprites).length} 张 CC0 贴图 ${(spriteBytes / 1024).toFixed(1)} KB，零外部请求）`);
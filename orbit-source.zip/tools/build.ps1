# 《回旋》一键构建：依赖 -> 单测 -> 打包。任一步失败即中止，不产出半成品。
# 用法: pwsh -File tools/build.ps1        （加 -SkipTests 可跳过单测）
param([switch]$SkipTests)

$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $repo

function Resolve-Tool([string]$name) {
  $c = Get-Command $name -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  throw "找不到 $name，请先安装 Node.js 22+"
}

$node = Resolve-Tool 'node'
$npm  = Resolve-Tool 'npm'

Write-Output "[1/3] 检查依赖"
if (-not (Test-Path -LiteralPath (Join-Path $repo 'node_modules/esbuild'))) {
  & $npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw '依赖安装失败' }
} else {
  Write-Output "      已就绪，跳过安装"
}

if ($SkipTests) {
  Write-Output "[2/3] 单测已按参数跳过"
} else {
  Write-Output "[2/3] 运行单测"
  & $node --test tests/core.test.mjs tests/systems.test.mjs tests/sim.test.mjs tests/aiming.test.mjs tests/feel.test.mjs tests/world.test.mjs tests/loop.test.mjs tests/chapter_tut.test.mjs tests/release.test.mjs
  if ($LASTEXITCODE -ne 0) { throw '单测未通过，构建中止' }
}

Write-Output "[3/3] 打包单文件产物"
& $node tools/build.mjs
if ($LASTEXITCODE -ne 0) { throw '打包失败' }

Write-Output ""
Write-Output "完成：双击 build/index.html 即可离线游玩"
// 平衡探针：用 QA 自动驾驶跑一局，打印成长曲线。不是单测，是调参用的观测工具。
// 用法: node tools/probe.mjs [秒数] [seed]
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { createWorld, resetWorld, stepWorld, STATE } from '../src/core/sim.mjs';
import { confirmChoice } from '../src/core/session.mjs';
import { applyUpgrade, applyCombos } from '../src/core/upgrades.mjs';
import { pilotInput } from '../src/platform/autopilot.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const rd = (p) => JSON.parse(readFileSync(join(root, p), 'utf8'));
const data = {
  tuning: rd('data/tuning.json'), enemies: rd('data/enemies.json'),
  upgrades: rd('data/upgrades.json'), waves: rd('data/waves.json'), arenas: rd('data/arenas.json'),
  combos: rd('data/combos.json'),
};

const secs = Number(process.argv[2]) || 600;
const seed = Number(process.argv[3]) || 20261125;
const DT = data.tuning.fixedDt;
const w = createWorld(data, seed);
w.aimMode = 'auto';   // 探针用自动瞄准，贴近解耦后的真实输出能力
let deaths = 0;
let nextMark = 30;
let firstLevelAt = null;
const levelTimes = [];
let loops = 0, loopHits = 0, loopKills = 0, loopArea = 0;
let gunDmg = 0, loopDmg = 0, burstDmg = 0, playTime = 0, miss = 0;
// 装甲敌人 45s 才登场，之前是教学期。核心动词的判据要看「装甲登场之后」的窗口，
// 否则会被开场那段只能开枪的垃圾怪稀释。两个窗口都打印，不藏数据。
const WIN = 45;
let marked = false, base = null, wGun = 0, wLoop = 0, wLoops = 0, wHits = 0, wTime = 0;
let cleared = 0, miniKill = 0, survived = 0;
const reach = { 150: 0, 330: 0, 540: 0 };
let wins = 0;

for (let k = 0; k < Math.round(secs / DT); k++) {
  if (w.session.state === STATE.LEVELUP) {
    const id = w.session.choices[0];
    applyUpgrade(w.stats, { id, ...data.upgrades[id] }, w.session.owned);
    applyCombos(w.stats, w.session.owned, data.combos, w.session.combos);
    confirmChoice(w.session, id);
    if (firstLevelAt === null) firstLevelAt = w.session.t;
    levelTimes.push(w.session.t);
  }
  if (w.session.state === STATE.DEAD || w.session.state === STATE.WIN) {
    console.log(`  [${w.session.outcome}] t=${w.session.t.toFixed(1)}s kills=${w.session.kills} lv=${w.session.level} 死因=${w.session.lastHitBy}`);
    deaths++;
    cleared += w.session.bulletsCleared; miniKill += w.session.miniKilled; survived += w.session.t;
    for (const mark of [150, 330, 540]) if (w.session.t >= mark) reach[mark]++;
    if (w.session.outcome === 'win') wins++;
    if (marked) { wGun += w.dmg.gun - base.gun; wLoop += w.dmg.loop - base.loop; wLoops += loops - base.loops; wHits += loopHits - base.hits; wTime += w.session.t - WIN; }
    marked = false; base = null;
    gunDmg += w.dmg.gun; loopDmg += w.dmg.loop; burstDmg += w.dmg.burst; miss += w.loopMiss;
    resetWorld(w, seed + deaths);
    nextMark = 30;
    continue;
  }
  const ev = stepWorld(w, DT, pilotInput(w));
  if (ev && ev.loop) { loops++; loopHits += ev.loop.hits; loopArea += ev.loop.area; }
  playTime += DT;
  if (!marked && w.session.t >= WIN) { marked = true; base = { gun: w.dmg.gun, loop: w.dmg.loop, loops, hits: loopHits }; }
  if (w.session.t >= nextMark) {
    console.log(`t=${nextMark}s  lv=${w.session.level}  kills=${w.session.kills}  hp=${w.stats.hp.toFixed(1)}  敌=${w.enemies.count}  宝石=${w.gems.count}`);
    nextMark += 30;
  }
}
const gaps = levelTimes.slice(1).map((t, i) => t - levelTimes[i]);
const avgGap = gaps.length ? gaps.reduce((a, b) => a + b, 0) / gaps.length : 0;
console.log(`\n首次升级 ${firstLevelAt?.toFixed(1) ?? '未达成'}s | 升级次数 ${levelTimes.length} | 平均间隔 ${avgGap.toFixed(1)}s | 死亡 ${deaths}`);
console.log(`闭环引爆 ${loops} 次 | 累计命中 ${loopHits} | 平均圈面积 ${loops ? Math.round(loopArea / loops) : 0} | 平均每次命中 ${loops ? (loopHits / loops).toFixed(1) : 0}`);
gunDmg += w.dmg.gun; loopDmg += w.dmg.loop; burstDmg += w.dmg.burst; miss += w.loopMiss;
const total = gunDmg + loopDmg + burstDmg || 1;
console.log(`\n=== 核心动词三条判据 ===`);
console.log(`① 圈伤害占比 ${(loopDmg / total * 100).toFixed(1)}%  （枪 ${(gunDmg / total * 100).toFixed(1)}% / 回旋爆发 ${(burstDmg / total * 100).toFixed(1)}%）  目标 ≥50%`);
console.log(`② 平均每圈套住 ${loops ? (loopHits / loops).toFixed(2) : 0} 只  目标 ≥4    空圈 ${miss} 次`);
console.log(`③ 每 10 秒主动画圈 ${(loops / playTime * 10).toFixed(2)} 次  目标 ≥1`);
console.log(`\n--- 防御与小Boss ---`);
console.log(`平均存活 ${(survived / Math.max(1, deaths)).toFixed(1)}s | 清弹总数 ${cleared} | 小Boss击破 ${miniKill}`);
console.log(`章节到达率（共 ${deaths} 局）：150s ${reach[150]} 局 | 330s ${reach[330]} 局 | 540s ${reach[540]} 局 | 通关 ${wins} 局`);
const wt = wGun + wLoop || 1;
console.log(`\n--- 装甲登场后（t≥${WIN}s）窗口 ---`);
console.log(`① 圈伤害占比 ${(wLoop / wt * 100).toFixed(1)}%   ② 平均每圈套住 ${wLoops ? (wHits / wLoops).toFixed(2) : 0} 只   ③ 每 10 秒画圈 ${wTime ? (wLoops / wTime * 10).toFixed(2) : 0} 次`);
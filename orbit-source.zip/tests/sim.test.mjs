import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, resetWorld, spawnEnemy, stepWorld, STATE } from '../src/core/sim.mjs';
import { confirmChoice } from '../src/core/session.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

test('开局两秒内世界开始生成敌人', () => {
  const w = createWorld(data, 42);
  for (let i = 0; i < 120; i++) stepWorld(w, DT, NO_INPUT);
  assert.ok(w.enemies.count > 0, `enemies=${w.enemies.count}`);
  assert.ok(w.bullets.count > 0, '自动开火应该已经产生子弹');
});

test('同 seed 同输入产生完全一致的仿真（可复现单局）', () => {
  const a = createWorld(data, 2026);
  const b = createWorld(data, 2026);
  const input = { x: 1, y: 0.35 };
  for (let i = 0; i < 300; i++) { stepWorld(a, DT, input); stepWorld(b, DT, input); }
  assert.equal(a.craft.x, b.craft.x);
  assert.equal(a.enemies.count, b.enemies.count);
  assert.equal(a.session.kills, b.session.kills);
});

test('不同 seed 产生不同的局', () => {
  const a = createWorld(data, 1);
  const b = createWorld(data, 999);
  for (let i = 0; i < 240; i++) { stepWorld(a, DT, NO_INPUT); stepWorld(b, DT, NO_INPUT); }
  const sum = (w) => {
    let t = 0;
    for (let i = 0; i < w.enemies.count; i++) t += w.enemies.f.x[i];
    return t;
  };
  assert.notEqual(sum(a), sum(b), '不同 seed 的敌人生成位置必须不同');
});

test('接触敌人会扣血直至死亡，失败状态真实存在', () => {
  const w = createWorld(data, 5);
  w.stats.maxHp = 1;
  w.stats.hp = 1;
  spawnEnemy(w, 'tank', w.craft.x, w.craft.y);
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.state, STATE.DEAD);
  assert.equal(w.session.outcome, 'lose');
  assert.equal(w.session.lastHitBy, 'tank');
});

test('击杀掉落经验宝石', () => {
  const w = createWorld(data, 5);
  const i = spawnEnemy(w, 'charger', w.craft.x + 200, w.craft.y);
  w.enemies.f.hp[i] = 0;
  stepWorld(w, DT, NO_INPUT);
  assert.ok(w.gems.count > 0);
  assert.equal(w.session.kills, 1);
});

test('回旋槽蓄满不再另放核弹，而是强化下一次套圈', () => {
  const w = createWorld(data, 5);
  for (let k = 0; k < 3; k++) spawnEnemy(w, 'charger', w.craft.x + 40 + k * 20, w.craft.y);
  w.craft.orbit = w.stats.orbitThreshold - 0.01;
  const ev = stepWorld(w, DT, { x: 1, y: 0 });
  assert.equal(ev.burst, true);
  assert.ok(w.loopBoost > 0, '蓄满应进入套圈强化窗口');
  assert.equal(w.loop.cool, 0, '蓄满应立刻解除套圈冷却');
  assert.equal(w.session.kills, 0, '回旋槽不该再自带杀伤，否则与套圈输出同源');
});

test('Boss 到点登场', () => {
  const w = createWorld(data, 5);
  w.session.t = data.waves.bossAt - DT / 2;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.bossSpawned, true);
  let found = false;
  for (let i = 0; i < w.enemies.count; i++) {
    if (w.enemies.f.kind[i] === w.kindIndex.boss) found = true;
  }
  assert.equal(found, true);
});

test('击杀 Boss 判定为胜利', () => {
  const w = createWorld(data, 5);
  const i = spawnEnemy(w, 'boss', 100, 100);
  w.enemies.f.hp[i] = 0;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.state, STATE.WIN);
  assert.equal(w.session.outcome, 'win');
});

test('实体容量打满时拒绝生成而不是崩溃', () => {
  const w = createWorld(data, 5);
  for (let k = 0; k < data.tuning.caps.enemies + 500; k++) spawnEnemy(w, 'charger', k % 1900, k % 1000);
  assert.equal(w.enemies.count, data.tuning.caps.enemies);
  assert.doesNotThrow(() => stepWorld(w, DT, NO_INPUT));
});

test('回复不能把 0 血奶活（失败状态不可被 regen 抹掉）', () => {
  const w = createWorld(data, 11);
  w.stats.regen = 5;
  w.stats.hp = 1;
  spawnEnemy(w, 'tank', w.craft.x, w.craft.y);
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.stats.hp, 0);
  assert.equal(w.session.state, STATE.DEAD);
});

test('重开耗时远低于 2 秒门禁，且状态干净', () => {
  const w = createWorld(data, 5);
  for (let i = 0; i < 600; i++) stepWorld(w, DT, NO_INPUT);
  const t0 = performance.now();
  resetWorld(w, 6);
  const ms = performance.now() - t0;
  assert.ok(ms < 50, `reset 耗时 ${ms.toFixed(2)}ms`);
  assert.equal(w.session.state, STATE.PLAYING);
  assert.equal(w.enemies.count, 0);
  assert.equal(w.session.kills, 0);
  assert.equal(w.stats.hp, w.stats.maxHp);
});

test('升级弹出时仿真冻结，选择后继续', () => {
  const w = createWorld(data, 5);
  w.session.xp = w.session.xpNext;
  const i = spawnEnemy(w, 'charger', w.craft.x, w.craft.y);
  w.enemies.f.hp[i] = 0;
  w.gems.spawn();
  const g = w.gems.count - 1;
  w.gems.f.x[g] = w.craft.x; w.gems.f.y[g] = w.craft.y; w.gems.f.value[g] = 999; w.gems.f.life[g] = 10;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.state, STATE.LEVELUP);
  const tBefore = w.session.t;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.t, tBefore, '升级选择期间时间必须冻结');
  confirmChoice(w.session, w.session.choices[0]);
  assert.equal(w.session.state, STATE.PLAYING);
});

/** 简易自动驾驶：朝最近敌人的反方向逃。用于引擎压测，不代表玩家水平 */
function fleeInput(w) {
  let best = 1e9; let bx = 0; let by = 0;
  const f = w.enemies.f;
  for (let i = 0; i < w.enemies.count; i++) {
    const d = (f.x[i] - w.craft.x) ** 2 + (f.y[i] - w.craft.y) ** 2;
    if (d < best) { best = d; bx = f.x[i]; by = f.y[i]; }
  }
  return best < 1e9 ? { x: w.craft.x - bx, y: w.craft.y - by } : { x: 1, y: 0 };
}

test('10 分钟连续仿真：0 异常、0 软锁（引擎压测，开无敌排除平衡干扰）', () => {
  const w = createWorld(data, 777);
  const god = () => { w.stats.maxHp = 1e6; w.stats.hp = 1e6; };
  god();
  let maxEntities = 0;
  let steps = 0;
  let sawBoss = false;
  const total = Math.round(600 / DT) + 10; // 多跑 10 步，跨过浮点累加误差
  let input = { x: 1, y: 0 };
  for (let k = 0; k < total; k++) {
    if (w.session.state === STATE.LEVELUP) confirmChoice(w.session, w.session.choices[0]);
    assert.equal(w.session.state, STATE.PLAYING, `第 ${k} 步出现非预期状态 ${w.session.state}`);
    if (k % 10 === 0) input = fleeInput(w);
    stepWorld(w, DT, input);
    if (w.session.bossSpawned) sawBoss = true;
    const n = w.enemies.count + w.bullets.count + w.gems.count;
    if (n > maxEntities) maxEntities = n;
    steps++;
  }
  assert.equal(steps, total);
  assert.equal(sawBoss, true, '10 分钟必须走到 Boss 阶段');
  assert.ok(maxEntities > 300, `峰值实体 ${maxEntities}`);
  console.log(`      [ endurance ] 步数=${steps} 峰值实体=${maxEntities} 软锁=0`);
});

test('只逃不打必死：失败状态有真实代价（平衡探针）', () => {
  const w = createWorld(data, 2027);
  let input = { x: 1, y: 0 };
  for (let k = 0; k < Math.round(600 / DT); k++) {
    if (w.session.state === STATE.LEVELUP) confirmChoice(w.session, w.session.choices[0]);
    if (w.session.state !== STATE.PLAYING) break;
    if (k % 10 === 0) input = fleeInput(w);
    stepWorld(w, DT, input);
  }
  assert.equal(w.session.state, STATE.DEAD, '纯逃跑不应该能通关');
  assert.ok(w.session.t < 600, `存活 ${w.session.t.toFixed(1)}s`);
  console.log(`      [ balance ] 纯逃跑存活 ${w.session.t.toFixed(1)}s，死因=${w.session.lastHitBy}`);
});

test('仿真单帧成本：1000 实体压测（纯 CPU，与显卡无关）', () => {
  const w = createWorld(data, 3);
  for (let k = 0; k < 1000; k++) {
    spawnEnemy(w, k % 7 === 0 ? 'tank' : 'charger', (k * 37) % 1920, (k * 53) % 1080);
  }
  for (let i = 0; i < 30; i++) stepWorld(w, DT, { x: 1, y: 0.2 });
  const t0 = performance.now();
  const N = 300;
  for (let i = 0; i < N; i++) {
    if (w.session.state === STATE.LEVELUP) confirmChoice(w.session, w.session.choices[0]);
    if (w.session.state !== STATE.PLAYING) resetWorld(w, 3);
    stepWorld(w, DT, { x: 1, y: 0.2 });
  }
  const msPerStep = (performance.now() - t0) / N;
  console.log(`      [ sim-cost ] 1000 实体 ${msPerStep.toFixed(3)} ms/step（16.67ms 预算）`);
  assert.ok(msPerStep < 16.67, `仿真超预算: ${msPerStep.toFixed(3)}ms`);
});
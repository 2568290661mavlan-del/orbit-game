import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveAim, pickTarget, AIM_MODES } from '../src/core/aiming.mjs';
import { createWorld, spawnEnemy, stepWorld, STATE } from '../src/core/sim.mjs';
import { fireVolley } from '../src/core/weapons.mjs';
import { DEFAULTS, loadSettings, saveSettings, applySettings } from '../src/platform/settings.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

test('三种瞄准模式都在册', () => {
  assert.deepEqual(AIM_MODES, ['mouse', 'auto', 'move']);
});

test('move 模式：枪口跟随移动朝向（纯键盘无障碍）', () => {
  const w = createWorld(data, 1);
  w.aimMode = 'move';
  w.craft.heading = 1.234;
  resolveAim(w, 'move', null, DT);
  assert.ok(Math.abs(w.craft.aim - 1.234) < 1e-9);
});

test('mouse 模式：枪口指向鼠标，与移动朝向无关', () => {
  const w = createWorld(data, 1);
  w.craft.x = 500; w.craft.y = 500; w.craft.heading = 0;
  resolveAim(w, 'mouse', { x: 500, y: 900 }, DT);
  assert.ok(Math.abs(w.craft.aim - Math.PI / 2) < 1e-6, `aim=${w.craft.aim}`);
  assert.equal(w.craft.heading, 0, '瞄准不应改变移动朝向');
});

test('mouse 模式：鼠标与自身重合时保持原朝向，不产生 NaN', () => {
  const w = createWorld(data, 1);
  w.craft.x = 500; w.craft.y = 500;
  resolveAim(w, 'mouse', { x: 500, y: 500 }, DT);
  assert.ok(Number.isFinite(w.craft.aim));
});

test('auto 模式：锁定最近敌人', () => {
  const w = createWorld(data, 1);
  w.craft.x = 500; w.craft.y = 500;
  spawnEnemy(w, 'charger', 900, 500);
  spawnEnemy(w, 'charger', 560, 500);
  const t = pickTarget(w);
  assert.ok(Math.abs(t.x - 60) < 1e-6);
});

test('auto 模式：无敌人时退回移动朝向', () => {
  const w = createWorld(data, 1);
  w.craft.heading = 0;
  w.craft.aim = 0;
  resolveAim(w, 'auto', null, DT);
  assert.ok(Math.abs(w.craft.aim) < 1e-6);
});

test('auto 模式有转速上限，不会瞬间吸附', () => {
  const w = createWorld(data, 1);
  w.craft.x = 500; w.craft.y = 500; w.craft.aim = 0;
  spawnEnemy(w, 'charger', 500, 800);
  resolveAim(w, 'auto', null, DT);
  assert.ok(w.craft.aim > 0 && w.craft.aim < Math.PI / 2, `aim=${w.craft.aim}`);
});

test('子弹沿枪口而非机头飞出（瞄准与移动已解耦）', () => {
  const w = createWorld(data, 1);
  w.craft.x = 500; w.craft.y = 500;
  w.craft.heading = 0;
  w.craft.aim = Math.PI / 2;
  fireVolley(w);
  const bf = w.bullets.f;
  assert.equal(w.bullets.count, 1);
  assert.ok(bf.vy[0] > 0 && Math.abs(bf.vx[0]) < 1e-6, `vx=${bf.vx[0]} vy=${bf.vy[0]}`);
});

test('mouse 模式下能打死正侧面的敌人（修复「子弹没用」）', () => {
  const w = createWorld(data, 5);
  w.aimMode = 'mouse';
  w.craft.x = 500; w.craft.y = 500; w.craft.heading = 0;
  const i = spawnEnemy(w, 'charger', 500, 700);
  w.enemies.f.speed[i] = 0;
  w.pointer = { x: 500, y: 700 };
  for (let k = 0; k < 90; k++) {
    if (w.session.state !== STATE.PLAYING) break;
    stepWorld(w, DT, NO_INPUT);
    w.pointer = { x: 500, y: 700 };
  }
  assert.ok(w.session.kills >= 1, `kills=${w.session.kills}`);
});

test('辅助模式 100% 减伤完全免伤，50% 减半', () => {
  const mk = (assist) => {
    const w = createWorld(data, 9);
    w.assistReduction = assist;
    w.stats.hp = 4;
    spawnEnemy(w, 'tank', w.craft.x, w.craft.y);
    stepWorld(w, DT, NO_INPUT);
    return w.stats.hp;
  };
  assert.equal(mk(1), 4);
  assert.ok(Math.abs(mk(0.5) - 3.5) < 1e-9);
  assert.equal(mk(0), 3);
});

test('敌人速度辅助倍率生效', () => {
  const w = createWorld(data, 3);
  w.enemySpeedMul = 0.75;
  const i = spawnEnemy(w, 'charger', 200, 200);
  const x0 = w.enemies.f.x[i];
  stepWorld(w, DT, NO_INPUT);
  const moved = Math.abs(w.enemies.f.x[i] - x0);
  const full = createWorld(data, 3);
  const j = spawnEnemy(full, 'charger', 200, 200);
  const fx0 = full.enemies.f.x[j];
  stepWorld(full, DT, NO_INPUT);
  const movedFull = Math.abs(full.enemies.f.x[j] - fx0);
  assert.ok(moved < movedFull, `${moved} vs ${movedFull}`);
});

test('击杀产生粒子与屏幕震动（打击感有数据支撑）', () => {
  const w = createWorld(data, 5);
  const i = spawnEnemy(w, 'tank', 300, 300);
  w.enemies.f.hp[i] = 0;
  const ev = stepWorld(w, DT, NO_INPUT);
  assert.equal(ev.kills, 1);
  assert.ok(w.parts.count > 0, '应有击杀粒子');
  assert.ok(w.shake > 0, '应有屏幕震动');
});

test('命中给敌人闪白与击退', () => {
  const w = createWorld(data, 5);
  const i = spawnEnemy(w, 'tank', 500, 560);
  w.craft.x = 500; w.craft.y = 500;
  w.craft.aim = Math.PI / 2;
  fireVolley(w);
  for (let k = 0; k < 6; k++) stepWorld(w, DT, NO_INPUT);
  assert.ok(w.enemies.f.flash[i] > 0 || w.enemies.f.ky[i] !== 0, '命中应留下闪白或击退');
});

test('设置默认值包含语言与瞄准模式', () => {
  assert.equal(DEFAULTS.lang, 'zh');
  assert.equal(DEFAULTS.aim, 'mouse');
  assert.ok(['zh', 'en'].includes(DEFAULTS.lang));
});

test('设置落盘失败时不抛异常（file:// 隐私模式兜底）', () => {
  const broken = { getItem() { throw new Error('denied'); }, setItem() { throw new Error('denied'); } };
  const orig = globalThis.localStorage;
  globalThis.localStorage = broken;
  try {
    assert.doesNotThrow(() => loadSettings());
    assert.equal(saveSettings({ ...DEFAULTS }), false);
    assert.equal(loadSettings().aim, 'mouse');
  } finally {
    if (orig === undefined) delete globalThis.localStorage; else globalThis.localStorage = orig;
  }
});

test('applySettings 把瞄准与辅助写进世界', () => {
  const w = createWorld(data, 1);
  const calls = [];
  applySettings({ ...DEFAULTS, aim: 'auto', assistReduction: 0.5, enemySpeedMul: 0.75, lang: 'en', uiScale: 1.5, volume: 0.3, colorblind: true, shake: false }, {
    world: w,
    renderer: { setColorblind: (v) => calls.push(['cb', v]) },
    audio: { setVolume: (v) => calls.push(['vol', v]) },
    i18n: { setLang: (v) => calls.push(['lang', v]), t: (k) => k },
    ui: { setScale: (v) => calls.push(['scale', v]) },
  });
  assert.equal(w.aimMode, 'auto');
  assert.equal(w.assistReduction, 0.5);
  assert.equal(w.enemySpeedMul, 0.75);
  assert.deepEqual(calls, [['vol', 0.3], ['lang', 'en'], ['scale', 1.5], ['cb', true]]);
});
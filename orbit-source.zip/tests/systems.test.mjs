import test from 'node:test';
import assert from 'node:assert/strict';
import { createCraft, stepCraft, turnRadius, STEER_DEFAULTS } from '../src/core/steering.mjs';
import { segmentAt, spawnRate, takeSpawnBudget } from '../src/core/waves.mjs';
import { rollChoices, applyUpgrade, buildStats, applyCombos, pendingCombo } from '../src/core/upgrades.mjs';
import { makeRng } from '../src/core/rng.mjs';
import {
  createSession, resetRun, registerKill, tickChain, grantXp,
  enterLevelUp, confirmChoice, recordHit, endRun, summarize, STATE,
} from '../src/core/session.mjs';
import { loadData, DT } from './helpers.mjs';

const data = loadData();

test('无输入时仍然恒速前进（物理上不存在站桩）', () => {
  const c = createCraft(500, 500, 0);
  stepCraft(c, 0, 0, DT);
  assert.ok(c.x > 500 + 3, `x=${c.x}`);
  assert.equal(c.y, 500);
});

test('转向速率不超过 turnRate 上限', () => {
  const c = createCraft(500, 500, 0);
  const r = stepCraft(c, 0, 1, DT);
  assert.ok(Math.abs(r.turned - STEER_DEFAULTS.turnRate * DT) < 1e-12);
});

test('转弯半径 = 速度 / 转向速率', () => {
  assert.ok(Math.abs(turnRadius() - 230 / 3.4) < 1e-9);
});

test('反向转向降低蓄能效率但不清零（允许微调准星）', () => {
  const c = createCraft(500, 500, 1.0);
  c.turnSign = 1;
  c.orbit = 2.0;
  stepCraft(c, Math.cos(-1), Math.sin(-1), DT);
  assert.ok(c.orbit > 2.0, '反向不应清空已攒的能量');
  assert.ok(c.orbit < 2.0 + STEER_DEFAULTS.turnRate * DT, '反向蓄能必须比同向慢');
  assert.equal(c.turnSign, -1);
});

test('回旋槽累计满一圈触发一次爆发', () => {
  const c = createCraft(500, 500, 0);
  c.orbit = STEER_DEFAULTS.orbitThreshold - 0.01;
  const r = stepCraft(c, 0, 1, DT);
  assert.equal(r.burst, true);
  assert.equal(c.bursts, 1);
});

test('无限地图：飞出原边界不再回绕，坐标继续增长', () => {
  const c = createCraft(1919, 500, 0);
  stepCraft(c, 0, 0, DT);
  assert.ok(c.x > 1919, `x=${c.x}`);
  for (let k = 0; k < 600; k++) stepCraft(c, 0, 0, DT);
  assert.ok(c.x > 4000, `长时间飞行后 x=${c.x}`);
});

test('前置依赖未满足时不会抽到高级项', () => {
  const rng = makeRng(9);
  for (let k = 0; k < 40; k++) {
    const picks = rollChoices(rng, data.upgrades, {}, 3, 0);
    assert.ok(!picks.includes('multishot'), '没有重弹头就不该出分裂枪口');
    assert.ok(!picks.includes('loop_band'), '没有收口装药就不该出扩幅套索');
  }
  const owned = { damage_up: 1, orbit_eff: 1, loop_dmg: 1 };
  let sawAdvanced = false;
  for (let k = 0; k < 200; k++) {
    const picks = rollChoices(rng, data.upgrades, owned, 3, 0);
    if (picks.includes('multishot') || picks.includes('loop_band')) sawAdvanced = true;
  }
  assert.ok(sawAdvanced, '满足前置后高级项应可出现');
});

test('组合化学反应：凑齐两项触发一次且只触发一次', () => {
  const stats = buildStats(data.tuning.base);
  const owned = {};
  const applied = {};
  applyUpgrade(stats, { id: 'pierce', ...data.upgrades.pierce }, owned);
  assert.deepEqual(applyCombos(stats, owned, data.combos, applied), []);
  applyUpgrade(stats, { id: 'multishot', ...data.upgrades.multishot }, owned);
  const fired = applyCombos(stats, owned, data.combos, applied);
  assert.ok(fired.includes('pierce_rain'), '穿甲芯 + 分裂枪口应触发贯穿齐射');
  assert.equal(stats.pierce, 3, '穿透 1 + 组合 2');
  assert.deepEqual(applyCombos(stats, owned, data.combos, applied), [], '同一组合不该重复加成');
});

test('选卡前能预告即将触发的组合', () => {
  const owned = { pierce: 1 };
  assert.equal(pendingCombo('multishot', owned, data.combos, {}), 'pierce_rain');
  assert.equal(pendingCombo('multishot', owned, data.combos, { pierce_rain: true }), null);
});

test('敌潮分段取最后一个已开始的段', () => {
  // 取「最后一个 start <= t 的段」，期望值从数据推导，避免调参就误报回归
  const expectAt = (t) => data.waves.timeline.filter((s) => s.start <= t).pop().start;
  assert.equal(segmentAt(0, data.waves.timeline).start, expectAt(0));
  assert.equal(segmentAt(65, data.waves.timeline).start, expectAt(65));
  assert.equal(segmentAt(999, data.waves.timeline).start, expectAt(999));
});

test('段内生成速率按 ramp 线性爬升', () => {
  const seg = segmentAt(70, data.waves.timeline);
  const expect = seg.rate + seg.ramp * (70 - seg.start);
  assert.ok(Math.abs(spawnRate(70, data.waves.timeline) - expect) < 1e-9);
  assert.ok(spawnRate(90, data.waves.timeline) > spawnRate(70, data.waves.timeline));
});

test('生成配额的小数余量保留到下一帧，不丢怪', () => {
  const acc = { value: 0.9 };
  const n = takeSpawnBudget(acc, 1, 0.2);
  assert.equal(n, 1);
  assert.ok(acc.value > 0 && acc.value < 1);
});

test('长卡顿后单帧生成数被钳制，不会爆量掉帧', () => {
  const acc = { value: 0 };
  const n = takeSpawnBudget(acc, 1000, 5, 24);
  assert.equal(n, 24);
  assert.ok(acc.value <= 24);
});

test('升级抽取无重复项', () => {
  const rng = makeRng(99);
  const picks = rollChoices(rng, data.upgrades, {}, 3);
  assert.equal(picks.length, 3);
  assert.equal(new Set(picks).size, 3);
});

test('已满层的升级不再出现在选项里', () => {
  const owned = {};
  for (const id in data.upgrades) owned[id] = data.upgrades[id].maxStacks;
  const picks = rollChoices(makeRng(1), data.upgrades, owned, 3);
  assert.equal(picks.length, 0);
});

test('升级效果 mul 与 add 都按数据生效（不写死数值，随平衡调整自动跟随）', () => {
  const stats = buildStats(data.tuning.base);
  const rateDef = data.upgrades.rate_up.effects[0];
  const before = stats[rateDef.stat];
  applyUpgrade(stats, { id: 'rate_up', ...data.upgrades.rate_up }, {});
  assert.ok(Math.abs(stats[rateDef.stat] - before * rateDef.value) < 1e-9, 'mul 应按数据倍率生效');
  const dmgDef = data.upgrades.damage_up.effects[0];
  const dmg = stats[dmgDef.stat];
  applyUpgrade(stats, { id: 'damage_up', ...data.upgrades.damage_up }, {});
  assert.equal(stats[dmgDef.stat], dmg + dmgDef.value, 'add 应按数据增量生效');
});

test('升级卡展示的「当前 → 新值」与真实结算一致', () => {
  const stats = buildStats(data.tuning.base);
  for (const id of ['rate_up', 'damage_up', 'loop_dmg', 'loop_band', 'rudder']) {
    const def = data.upgrades[id];
    const shown = def.effects.map((e) => (e.op === 'mul' ? stats[e.stat] * e.value : stats[e.stat] + e.value));
    applyUpgrade(stats, { id, ...def }, {});
    def.effects.forEach((e, i) => {
      assert.ok(Math.abs(stats[e.stat] - shown[i]) < 1e-9, `${id} 的预览值必须等于实际值`);
    });
  }
});

test('超过层数上限的升级不再生效', () => {
  const stats = buildStats(data.tuning.base);
  const owned = { wide_scan: 1 };
  const ok = applyUpgrade(stats, { id: 'wide_scan', ...data.upgrades.wide_scan }, owned);
  assert.equal(ok, false);
});

test('连锁在窗口结束后清零，但保留最高纪录', () => {
  const s = resetRun(createSession(), 1);
  registerKill(s); registerKill(s); registerKill(s);
  assert.equal(s.chain, 3);
  tickChain(s, 2.0);
  assert.equal(s.chain, 0);
  assert.equal(s.maxChain, 3);
});

test('经验足够时连升多级', () => {
  const s = resetRun(createSession(), 1);
  const n = grantXp(s, 100);
  assert.ok(n >= 3, `leveled=${n}`);
  assert.ok(s.xp < s.xpNext);
});

test('升级选择期间时间冻结，确认后回到 playing', () => {
  const s = resetRun(createSession(), 1);
  enterLevelUp(s, ['rate_up', 'pierce', 'magnet']);
  assert.equal(s.state, STATE.LEVELUP);
  assert.equal(confirmChoice(s, 'pierce'), true);
  assert.equal(s.state, STATE.PLAYING);
  assert.deepEqual(s.upgradePath.at(-1).id, 'pierce');
});

test('死亡进入 dead 状态并留下死因', () => {
  const s = resetRun(createSession(), 1);
  recordHit(s, 'bomber');
  endRun(s, 'lose');
  assert.equal(s.state, STATE.DEAD);
  assert.equal(summarize(s).lastHitBy, 'bomber');
});

test('结算数据包含复盘所需的全部字段', () => {
  const s = resetRun(createSession(), 7);
  registerKill(s);
  const sum = summarize(s);
  for (const k of ['outcome', 'survived', 'kills', 'level', 'maxChain', 'lastHitBy', 'upgradePath', 'seed']) {
    assert.ok(k in sum, `缺字段 ${k}`);
  }
});

test('重开把上一局的痕迹清干净', () => {
  const s = resetRun(createSession(), 1);
  registerKill(s);
  grantXp(s, 50);
  s.owned.rate_up = 2;
  endRun(s, 'lose');
  resetRun(s, 2);
  assert.equal(s.kills, 0);
  assert.equal(s.level, 1);
  assert.equal(s.state, STATE.PLAYING);
  assert.deepEqual(Object.keys(s.owned), []);
  assert.equal(s.outcome, null);
});
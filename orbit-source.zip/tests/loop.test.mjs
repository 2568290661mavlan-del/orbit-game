import test from 'node:test';
import assert from 'node:assert/strict';
import { pointInPoly, polyArea, createLoop, resetLoop, cutLoop } from '../src/core/loop.mjs';
import { tickFire } from '../src/core/weapons.mjs';
import { createWorld, spawnEnemy, stepWorld, STATE } from '../src/core/sim.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

function playing(seed = 3) {
  const w = createWorld(data, seed);
  w.session.state = STATE.PLAYING;
  w.arena = { ...w.arena, rateMul: 0 };
  w.opened = true;
  w.fireCd = 999;
  w.stats.speed = 0;               // 手动摆位置，排除恒速干扰
  return w;
}

/** 手动把机体沿一串路径点摆放并步进，模拟飞行轨迹 */
function fly(w, pts, repeats = 1) {
  let last = null;
  for (let r = 0; r < repeats; r++) {
    for (const [x, y] of pts) {
      w.craft.x = x; w.craft.y = y;
      w.cam.x = x; w.cam.y = y;
      const ev = stepWorld(w, DT, NO_INPUT);
      if (ev && ev.loop) last = ev.loop;
    }
  }
  return last;
}

function square(cx, cy, r, n = 24) {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
  }
  return pts;
}

test('点在多边形内判定正确', () => {
  const xs = Float32Array.from([0, 100, 100, 0]);
  const ys = Float32Array.from([0, 0, 100, 100]);
  assert.equal(pointInPoly(50, 50, xs, ys, 4), true);
  assert.equal(pointInPoly(150, 50, xs, ys, 4), false);
  assert.equal(pointInPoly(-5, 50, xs, ys, 4), false);
});

test('鞋带公式面积正确', () => {
  const xs = Float32Array.from([0, 100, 100, 0]);
  const ys = Float32Array.from([0, 0, 100, 100]);
  assert.equal(polyArea(xs, ys, 4), 10000);
});

test('画一个闭合圈会引爆，圈住敌人', () => {
  const w = playing();
  const inside = spawnEnemy(w, 'tank', 500, 500);
  const hp0 = w.enemies.f.hp[inside];
  const loop = fly(w, square(500, 500, 220));
  assert.ok(loop, '应触发闭环引爆');
  assert.ok(loop.hits >= 1, `圈内敌人应被命中，实际 ${loop.hits}`);
  assert.ok(w.enemies.f.hp[0] < hp0 || w.enemies.count === 0, '圈内敌人应掉血');
});

test('圈外的敌人不受闭环伤害', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  const out = spawnEnemy(w, 'tank', 1400, 1400);
  w.enemies.f.speed[out] = 0;
  const hpOut = w.enemies.f.hp[out];
  fly(w, square(500, 500, 220));
  let found = false;
  for (let i = 0; i < w.enemies.count; i++) {
    if (Math.abs(w.enemies.f.x[i] - 1400) > 1) continue;
    found = true;
    assert.equal(w.enemies.f.hp[i], hpOut, '圈外敌人不该掉血');
  }
  assert.ok(found, '圈外敌人应仍在场');
});

test('套住越多伤害越高（伤害由数量决定，不由面积决定）', () => {
  const dmgOf = (count) => {
    const w = playing();
    for (let i = 0; i < count; i++) spawnEnemy(w, 'tank', 460 + i * 18, 500);
    const hp0 = w.enemies.f.hp[0];
    fly(w, square(500, 500, 220, 40));
    return hp0 - (w.enemies.count ? w.enemies.f.hp[0] : 0);
  };
  const few = dmgOf(1);
  const many = dmgOf(8);
  assert.ok(many > few, `套住 8 只 ${many} 应高于套住 1 只 ${few}`);
});

test('空圈没有伤害（收益必须来自框住了谁）', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 3000, 3000);
  const hp0 = w.enemies.f.hp[0];
  const loop = fly(w, square(500, 500, 220, 40));
  assert.equal(loop, null, '没套住任何东西就不该算一次引爆');
  assert.equal(w.enemies.f.hp[0], hp0);
  assert.ok(w.loopMiss > 0, '空圈应被记账');
});

test('套住的敌人被拽向圈心（套索收口）', () => {
  const w = playing();
  const i = spawnEnemy(w, 'tank', 500, 500);
  w.enemies.f.speed[i] = 0;
  w.enemies.f.x[i] = 700; w.enemies.f.y[i] = 500;   // 落在轨迹收口带上
  fly(w, square(500, 500, 220, 40));
  assert.ok(w.enemies.f.snare[i] > 0, '应进入收口状态');
  const before = w.enemies.f.x[i];
  for (let k = 0; k < 6; k++) stepWorld(w, DT, NO_INPUT);
  assert.ok(w.enemies.f.x[i] < before, '收口应把敌人拉向圈心');
});

test('受伤即断带：丢掉最老的一段，但不再清空到零（防死亡螺旋）', () => {
  const w = playing();
  fly(w, square(500, 500, 220, 40).slice(0, 12));
  const before = w.loop.n;
  assert.ok(before > 3, '先画出一段光带');
  spawnEnemy(w, 'charger', w.craft.x, w.craft.y);   // 贴脸接触伤害
  w.invuln = 0;
  for (let k = 0; k < 4; k++) stepWorld(w, DT, NO_INPUT);
  assert.ok(w.stats.hp < w.stats.maxHp, '应确实受伤');
  assert.ok(w.loop.n <= Math.ceil(before * 0.5), `受伤后光带应明显变短，实际 ${w.loop.n}/${before}`);
  assert.ok(w.loop.n > 0, '保留最近一段，避免「断带→没能量→停火」的连锁崩盘');
});

test('断带机制诊断：能量不足会真的压低射速，这不是错觉', () => {
  const w = playing();
  w.fireCd = 0;                      // playing() 会把 fireCd 设为 999 以关闭开火，这里要恢复
  w.stats.energy = 0;
  w.stats.energyRegen = 0;
  let shots = 0;
  for (let k = 0; k < 60; k++) shots += tickFire(w, DT);
  assert.equal(shots, 0, '没有能量就一发都打不出来');
  w.stats.energy = w.stats.energyMax;
  let full = 0;
  for (let k = 0; k < 60; k++) full += tickFire(w, DT);
  assert.ok(full >= 2, `满能量时每秒应接近 ${w.stats.fireRate} 发，实际 ${full}`);
});

test('断带保留的是最近的轨迹段', () => {
  const L = createLoop(64);
  for (let i = 0; i < 20; i++) { L.xs[i] = i * 10; L.ys[i] = 0; L.n = i + 1; }
  cutLoop(L, 0.4);
  assert.equal(L.n, 8);
  assert.equal(L.xs[0], 120, '最老的 12 个点被丢弃');
  assert.equal(L.xs[7], 190, '最新的点保留在末尾');
});

test('快绕机构缩短套圈冷却', () => {
  // 对照实验：同样的飞行路径，只改 loopCooldown，排除冷却随时间衰减的干扰
  const runWith = (cd) => {
    const w = playing();
    w.stats.loopCooldown = cd;
    spawnEnemy(w, 'tank', 500, 500);
    fly(w, square(500, 500, 220, 40), 3);
    return w.loop.cool;
  };
  const normal = runWith(1);
  const fast = runWith(0.5);
  assert.ok(normal > 0 && fast > 0, '两次都应确实闭合过');
  // 冷却会随步进继续衰减，且衰减量两边相同，所以该比的是「差值」而不是「比值」
  assert.ok(Math.abs((normal - fast) - data.tuning.loop.cooldown * 0.5) < 1e-9,
    `两次冷却的差应等于 cooldown×0.5，实际 ${normal} → ${fast}`);
});

test('太小的圈不引爆（防抖动刷伤害）', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  const loop = fly(w, square(500, 500, 20, 30), 3);
  assert.equal(loop, null);
});

test('不闭合的直线飞行不会引爆', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  const pts = [];
  for (let i = 0; i < 60; i++) pts.push([300 + i * 30, 500]);
  assert.equal(fly(w, pts), null);
});

test('引爆后有冷却，不会每帧连爆', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  fly(w, square(500, 500, 220));
  assert.ok(w.loop.cool > 0, '引爆后应进入冷却');
});

test('引爆后轨迹清空，重新开始画', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  fly(w, square(500, 500, 220));
  assert.ok(w.loop.n <= 2, `轨迹应已重置，实际 ${w.loop.n}`);
});

test('关掉闭环开关后不再引爆（可退回纯枪械玩法）', () => {
  const w = playing();
  w.loopEnabled = false;
  spawnEnemy(w, 'tank', 500, 500);
  assert.equal(fly(w, square(500, 500, 220)), null);
});

test('闭环引爆产生粒子与视觉多边形', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 500, 500);
  fly(w, square(500, 500, 220));
  assert.ok(w.parts.count > 0);
  assert.ok(w.loopFx && w.loopPoly && w.loopPoly.n > 3);
});

function putBullet(w, x, y) {
  const i = w.ebullets.spawn();
  const f = w.ebullets.f;
  f.x[i] = x; f.y[i] = y; f.px[i] = x; f.py[i] = y;
  f.vx[i] = 0; f.vy[i] = 0; f.r[i] = 8; f.life[i] = 4;
  return i;
}

test('守护姿态：圈是清弹手段', () => {
  const w = playing();
  w.stance = 'guard';
  spawnEnemy(w, 'tank', 500, 500);
  for (let k = 0; k < 5; k++) putBullet(w, 480 + k * 10, 500);
  const loop = fly(w, square(500, 500, 220, 40));
  assert.ok(loop && loop.cleared >= 5, `应清掉圈内敌弹，实际 ${loop && loop.cleared}`);
  assert.equal(w.ebullets.count, 0);
  assert.ok(w.session.bulletsCleared >= 5);
});

test('破甲姿态：不清弹、不回能（姿态必须有真实代价）', () => {
  const w = playing();
  w.stance = 'break';
  w.stats.energy = 10;
  w.stats.energyRegen = 0;   // 隔离涓流，只验姿态本身是否回能
  spawnEnemy(w, 'tank', 500, 500);
  for (let k = 0; k < 5; k++) putBullet(w, 480 + k * 10, 500);
  const loop = fly(w, square(500, 500, 220, 40));
  assert.ok(loop && loop.breaking);
  assert.equal(loop.cleared, 0, '破甲姿态不该清弹');
  assert.equal(w.ebullets.count, 5);
  assert.equal(w.stats.energy, 10, '破甲姿态不该回能');
});

test('破甲姿态对装甲目标的伤害远高于守护姿态', () => {
  const dmgOf = (stance) => {
    const w = playing();
    w.stance = stance;
    const i = spawnEnemy(w, 'tank', 500, 500);   // tank 带 armor
    const hp0 = w.enemies.f.hp[i];
    fly(w, square(500, 500, 220, 40));
    return hp0 - w.enemies.f.hp[i];
  };
  const guard = dmgOf('guard');
  const brk = dmgOf('break');
  assert.ok(brk > guard * 3, `破甲 ${brk} 应远高于守护 ${guard}`);
});

test('只清弹没套住敌人，也算一次有效引爆', () => {
  const w = playing();
  spawnEnemy(w, 'tank', 3000, 3000);
  for (let k = 0; k < 3; k++) putBullet(w, 490 + k * 10, 500);
  const loop = fly(w, square(500, 500, 220, 40));
  assert.ok(loop, '防御性套圈不该被判为空圈');
  assert.equal(loop.caught, 0);
  assert.ok(loop.cleared >= 3);
});

test('小 Boss 按时间点登场，击破不结束对局', () => {
  const w = playing();
  w.session.t = w.data.waves.miniBosses[0].at - DT;
  for (let k = 0; k < 3; k++) stepWorld(w, DT, NO_INPUT);
  let idx = -1;
  for (let i = 0; i < w.enemies.count; i++) if (w.enemies.f.mini[i]) idx = i;
  assert.ok(idx >= 0, '90 秒应有小 Boss 登场');
  assert.ok(w.enemies.f.hp[idx] < w.data.enemies.boss.hp, '小 Boss 血量应被缩减');
  w.enemies.f.hp[idx] = 0;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.miniKilled, 1);
  assert.equal(w.session.state, STATE.PLAYING, '小 Boss 不是终局 Boss');
});

test('轨迹缓冲有上限，长时间飞行不无限增长', () => {
  const L = createLoop(50);
  assert.equal(L.cap, 50);
  resetLoop(L);
  assert.equal(L.n, 0);
  const w = playing();
  const pts = [];
  for (let i = 0; i < 400; i++) pts.push([300 + i * 25, 500 + Math.sin(i / 5) * 10]);
  fly(w, pts);
  assert.ok(w.loop.n <= w.loop.cap, `轨迹点数 ${w.loop.n} 超过上限 ${w.loop.cap}`);
});

test('大圈不再被面积上限吞掉：超过旧上限(900000)也必须引爆', () => {
  const w = playing();
  const c = w.craft;
  spawnEnemy(w, 'tank', c.x + 300, c.y);
  const ev = fly(w, square(c.x, c.y, 700, 60));   // 面积约 153 万，旧版本会静默 return null
  assert.ok(ev, '玩家好不容易画的大圈绝不能无声消失');
  assert.ok(ev.area > 900000, `本测试必须真的超过旧上限，当前 ${ev.area}`);
  assert.ok(ev.caught >= 1, '大圈里的敌人必须被套住');
});

test('太小的圈给明确反馈，而不是无声消失', () => {
  const w = playing();
  const c = w.craft;
  // 半径 30 时相邻点间距小于采样间隔，必须多绕几圈才攒得够闭合所需的采样点
  const ev = fly(w, square(c.x, c.y, 30, 12), 4);
  assert.equal(ev, null, '误触级小圈不该引爆');
  assert.ok(w.floats.some((f) => f.fail === 'small'), '必须飘出「圈太小」告诉玩家为什么');
});

test('破甲引爆把敌人向外炸飞且不往圈心拽（与守护相反）', () => {
  const w = playing();
  const c = w.craft;
  const i = spawnEnemy(w, 'tank', c.x + 150, c.y);
  w.stance = 'break';
  const ev = fly(w, square(c.x, c.y, 200, 40));
  assert.ok(ev && ev.breaking);
  assert.ok(Math.hypot(w.enemies.f.kx[i], w.enemies.f.ky[i]) > 0, '破甲必须有击退');
  assert.equal(w.enemies.f.snare[i], 0, '破甲不该使用守护的收口拖拽');
});

test('破甲拆甲击杀掉能量核心，拾取后回能', () => {
  const w = playing();
  const c = w.craft;
  const i = spawnEnemy(w, 'tank', c.x + 150, c.y);
  w.enemies.f.hp[i] = 1;                 // 确保这一圈刚好拆掉
  w.stance = 'break';
  const ev = fly(w, square(c.x, c.y, 200, 40));
  assert.ok(ev);
  const gf = w.gems.f;
  let core = -1;
  for (let k = 0; k < w.gems.count; k++) if (gf.kind[k] === 1) core = k;
  assert.ok(core >= 0, '拆甲击杀必须掉能量核心');
  w.stats.energy = 0; w.stats.energyRegen = 0;
  w.craft.x = gf.x[core]; w.craft.y = gf.y[core];
  stepWorld(w, DT, NO_INPUT);
  assert.ok(w.stats.energy > 0, '能量核心必须真的能被拾取回能');
});

test('守护清弹把敌弹变成可见的能量球，而不只是跳数字', () => {
  const w = playing();
  const c = w.craft;
  const b = w.ebullets.spawn();
  const qf = w.ebullets.f;
  qf.x[b] = c.x + 100; qf.y[b] = c.y; qf.px[b] = qf.x[b]; qf.py[b] = qf.y[b];
  qf.vx[b] = 0; qf.vy[b] = 0; qf.r[b] = 8; qf.life[b] = 30;
  const ev = fly(w, square(c.x, c.y, 200, 40));
  assert.ok(ev && ev.cleared >= 1, '应当清掉那发弹');
  let motes = 0;
  for (let k = 0; k < w.gems.count; k++) if (w.gems.f.kind[k] === 1) motes++;
  assert.ok(motes >= 1, '清弹必须在场上留下能量球');
});
import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, resetWorld, spawnEnemy, stepWorld, STATE } from '../src/core/sim.mjs';
import { createHash } from '../src/core/spatialHash.mjs';
import { confirmChoice } from '../src/core/session.mjs';
import { pilotInput } from '../src/platform/autopilot.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

function playing(seed = 11) {
  const w = createWorld(data, seed);
  w.session.state = STATE.PLAYING;
  return w;
}

test('机体不再上下穿屏：坐标连续增长，不回绕', () => {
  const w = playing();
  w.stats.maxHp = 9999; w.stats.hp = 9999;   // 本例只验世界几何，隔离生存变量
  const x0 = w.craft.x;
  let prev = x0;
  for (let k = 0; k < 1200; k++) {
    stepWorld(w, DT, { x: 1, y: 0 });
    if (w.session.state === STATE.LEVELUP) confirmChoice(w.session, w.session.choices[0]);
    assert.ok(w.craft.x > prev - 1e-6, '恒速向右时 x 不应突然跳回');
    prev = w.craft.x;
  }
  assert.ok(w.craft.x > w.W * 2, `20 秒后应远超一屏，实际 ${w.craft.x}`);
});

test('摄像机平滑跟随玩家，玩家始终留在画面内', () => {
  const w = playing();
  for (let k = 0; k < 900; k++) {
    stepWorld(w, DT, { x: 1, y: 0.2 });
    assert.ok(Math.abs(w.craft.x - w.cam.x) < w.W / 2);
    assert.ok(Math.abs(w.craft.y - w.cam.y) < w.H / 2);
  }
});

test('摄像机有惯性：不会硬贴死在机体上', () => {
  const w = playing();
  for (let k = 0; k < 60; k++) stepWorld(w, DT, { x: 1, y: 0 });
  assert.ok(Math.abs(w.craft.x - w.cam.x) > 1, '应存在可见的跟随滞后');
});

test('敌人只在视野外一圈生成，不会凭空冒在脸上', () => {
  const w = playing();
  const ring = data.tuning.view.spawnRing;
  const halfDiag = Math.hypot(w.W / 2, w.H / 2);
  assert.ok(ring > halfDiag, '生成环必须大于视野半对角，否则会在画面内出现');
  for (let k = 0; k < 400; k++) {
    const before = w.enemies.count;
    stepWorld(w, DT, NO_INPUT);
    for (let i = before; i < w.enemies.count; i++) {
      const d = Math.hypot(w.enemies.f.x[i] - w.craft.x, w.enemies.f.y[i] - w.craft.y);
      assert.ok(d > halfDiag, `新生敌人距离 ${d} 太近`);
    }
  }
});

test('远离玩家的敌人被回收，实体数不会无限增长', () => {
  const w = playing();
  w.arena = { ...w.arena, rateMul: 0 };
  w.opened = true;
  const far = data.tuning.view.cull + 500;
  spawnEnemy(w, 'charger', w.craft.x + far, w.craft.y);
  const n0 = w.enemies.count;
  stepWorld(w, DT, NO_INPUT);
  assert.ok(w.enemies.count < n0, '超距敌人应被回收');
});

test('十分钟持续飞行后实体总数仍在容量内（无限地图不泄漏）', () => {
  const w = playing(4242);
  w.stats.maxHp = 1e9; w.stats.hp = 1e9;
  let peak = 0;
  for (let k = 0; k < 36000; k++) {
    if (w.session.state === STATE.LEVELUP) w.session.state = STATE.PLAYING;
    stepWorld(w, DT, { x: 1, y: 0 });
    const n = w.enemies.count + w.bullets.count + w.ebullets.count + w.gems.count + w.parts.count;
    if (n > peak) peak = n;
  }
  const cap = data.tuning.caps;
  const total = cap.enemies + cap.bullets + cap.ebullets + cap.gems + cap.parts;
  assert.ok(peak < total * 0.8, `峰值 ${peak} 相对总容量 ${total} 过高`);
  assert.ok(Math.abs(w.craft.x) > 10000, '确实飞出了很远');
});

test('远离且未被吸附的宝石被回收', () => {
  const w = playing();
  const i = w.gems.spawn();
  const gf = w.gems.f;
  gf.x[i] = w.craft.x + data.tuning.view.gemCull + 300;
  gf.y[i] = w.craft.y;
  gf.px[i] = gf.x[i]; gf.py[i] = gf.y[i];
  gf.vx[i] = 0; gf.vy[i] = 0; gf.pull[i] = 0; gf.value[i] = 1; gf.life[i] = 22;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.gems.count, 0);
});

test('空间哈希支持负坐标与超大坐标（无限地图必需）', () => {
  const h = createHash(80);
  h.insert(-5000, -9000, 1);
  h.insert(120000, 88000, 2);
  h.insert(-5000, -9000, 3);
  const out = [];
  assert.deepEqual(h.query(-5000, -9000, 10, out).slice().sort(), [1, 3]);
  assert.deepEqual(h.query(120000, 88000, 10, out), [2]);
  assert.deepEqual(h.query(0, 0, 10, out), []);
});

test('负半轴照样能打到敌人（哈希键不因负坐标失效）', () => {
  const w = playing();
  w.stats.speed = 0;
  w.craft.x = -8000; w.craft.y = -6000;
  w.cam.x = -8000; w.cam.y = -6000;
  w.craft.aim = 0;
  w.aimMode = 'auto';
  const i = spawnEnemy(w, 'charger', -7900, -6000);
  w.enemies.f.speed[i] = 0;
  w.fireCd = 0;
  for (let k = 0; k < 120 && w.session.kills === 0; k++) stepWorld(w, DT, NO_INPUT);
  assert.ok(w.session.kills >= 1, `负坐标下击杀数 ${w.session.kills}`);
});

test('开场波带入场加速，避免无限地图下前 20 秒空场', () => {
  const w = playing();
  stepWorld(w, DT, NO_INPUT);
  const n = data.tuning.view.opening;
  assert.ok(w.enemies.count >= n, `开场应至少 ${n} 个敌人`);
  let rushed = 0;
  for (let i = 0; i < w.enemies.count; i++) if (w.enemies.f.rush[i] > 0) rushed++;
  assert.ok(rushed >= n, '开场敌人都应处于入场加速状态');
});

test('开局 12 秒内就能打出击杀（开场不再干等）', () => {
  const w = playing(20261125);
  w.aimMode = 'auto';
  for (let k = 0; k < Math.round(12 / DT); k++) {
    if (w.session.state === STATE.LEVELUP) w.session.state = STATE.PLAYING;
    if (w.session.state !== STATE.PLAYING) break;
    stepWorld(w, DT, pilotInput(w));
  }
  assert.ok(w.session.kills >= 3, `12 秒击杀数 ${w.session.kills}`);
});

test('重开一局摄像机复位到新机体位置', () => {
  const w = playing();
  w.stats.maxHp = 9999; w.stats.hp = 9999;
  for (let k = 0; k < 300; k++) {
    stepWorld(w, DT, { x: 1, y: 0 });
    if (w.session.state === STATE.LEVELUP) confirmChoice(w.session, w.session.choices[0]);
  }
  const far = w.craft.x;
  assert.ok(far > 2000);
  w.session.state = STATE.PLAYING;
  resetWorld(w, 5);
  assert.equal(w.cam.x, w.craft.x);
  assert.equal(w.cam.y, w.craft.y);
});
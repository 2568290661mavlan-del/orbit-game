import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

function readJson(rel) {
  return JSON.parse(readFileSync(join(root, rel), 'utf8'));
}

export function loadData() {
  return {
    tuning: readJson('data/tuning.json'),
    enemies: readJson('data/enemies.json'),
    upgrades: readJson('data/upgrades.json'),
    waves: readJson('data/waves.json'),
    arenas: readJson('data/arenas.json'),
    combos: readJson('data/combos.json'),
  };
}

export const NO_INPUT = { x: 0, y: 0 };
export const DT = 1 / 60;
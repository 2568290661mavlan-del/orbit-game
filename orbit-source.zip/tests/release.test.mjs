import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, resetWorld, stepWorld, STATE } from '../src/core/sim.mjs';
import { snapshotRun } from '../src/platform/save.mjs';
import { shotCostFor } from '../src/platform/settings.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

test('检查点快照：保留种子/章节/升级，且owned是拷贝不是引用', () => {
  const w = createWorld(data, 4242);
  w.session.state = STATE.PLAYING;
  w.chapter = 1;
  w.session.owned.damage_up = 2;
  w.session.t = 150;
  const sv = snapshotRun(w);
  assert.equal(sv.seed, 4242, '必须存种子，否则无法重建同一个世界');
  assert.equal(sv.chapter, 1);
  assert.equal(sv.t, 150);
  assert.equal(sv.owned.damage_up, 2);
  w.session.owned.damage_up = 9;
  assert.equal(sv.owned.damage_up, 2, '快照不能被后续游戏改写');
});

test('resetWorld 记录种子，供存档重建使用', () => {
  const w = createWorld(data, 1);
  resetWorld(w, 987654);
  assert.equal(w.seed, 987654);
  assert.equal(w.stanceLock, false, '重开不能带着上一局的破甲锁定');
});

test('难度只改弹药经济：简单0 / 普通标准 / 困难1.8倍', () => {
  assert.equal(shotCostFor(3, 'easy'), 0, '简单模式必须无限子弹');
  assert.equal(shotCostFor(3, 'normal'), 3);
  assert.equal(shotCostFor(3, 'hard'), 5.4);
});

test('回旋蓄满：解除套圈冷却 + 强化收口带 + 当场飘字说明收益', () => {
  const w = createWorld(data, 7);
  w.session.state = STATE.PLAYING;
  w.arena = { ...w.arena, rateMul: 0 };
  w.opened = true;
  w.craft.orbit = w.stats.orbitThreshold;   // 已经蓄满，下一步应触发
  const ev = stepWorld(w, DT, { x: 1, y: 0 });
  assert.ok(ev && ev.burst, '蓄满必须触发强化事件');
  assert.ok(w.loopBoost > 0, '强化必须有持续时间');
  assert.ok(w.floats.some((f) => f.boost), '必须飘字告诉玩家换来了什么，否则条满了也白满');
});

// 章节结构与交互式教学的回归测试。
import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, stepWorld, STATE } from '../src/core/sim.mjs';
import { startTutorial, stepTutorial } from '../src/core/tutorial.mjs';
import { sweep } from '../src/core/store.mjs';
const sweepAll = (w) => sweep(w.enemies, () => true);
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

function playing(seed = 5) {
  const w = createWorld(data, seed);
  w.session.state = STATE.PLAYING;
  w.arena = { ...w.arena, rateMul: 0 };
  w.opened = true;
  w.fireCd = 999;
  w.stats.speed = 0;
  return w;
}

function circle(cx, cy, r, n = 30) {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
  }
  return pts;
}

function fly(w, pts) {
  let last = null;
  for (const [x, y] of pts) {
    w.craft.x = x; w.craft.y = y;
    w.cam.x = x; w.cam.y = y;
    const ev = stepWorld(w, DT, NO_INPUT);
    // 注意：ev 是复用缓冲，下一帧就被清空。必须保存 ev.loop 这个结果对象，不能存 ev 本身
    if (ev && ev.loop) last = ev.loop;
  }
  return last;
}

test('跨章：换背景、治疗、给收口带强化，并发事件', () => {
  const w = playing();
  w.stats.hp = 3;
  w.session.t = data.waves.chapters[1].at - DT;
  const ev = stepWorld(w, DT, NO_INPUT);
  assert.equal(w.chapter, 1, '应进入第二章');
  assert.equal(w.bgArenaId, data.waves.chapters[1].arena, '背景配色随章切换');
  assert.equal(ev.chapter, 1, '要通知装配层显示章节横幅');
  assert.ok(w.stats.hp > 3, '跨章应治疗');
  assert.ok(w.loopBoost > 0, '跨章给收口带强化作为喘息');
  assert.ok(w.chapterFx > 0, '横幅计时应启动');
});

test('终局 Boss 在一局真实可达的时间内登场', () => {
  // 600s 的终点在平均存活 60s 时等于不存在；现在必须在 10 分钟以内
  assert.ok(data.waves.bossAt <= 600 && data.waves.bossAt >= 300, `终局 Boss 时间点 ${data.waves.bossAt}`);
  const lastMini = data.waves.miniBosses.at(-1).at;
  assert.ok(lastMini < data.waves.bossAt, '小 Boss 必须先于终局 Boss');
  assert.equal(data.waves.chapters.length, 3, '三章结构');
});

test('教学关闭敌潮且不会死亡', () => {
  const w = playing();
  startTutorial(w);
  assert.equal(w.arena.rateMul, 0, '教学不刷敌潮');
  assert.equal(w.tut.i, 0);
  // 直接撞第一步的靶机：教学允许试错，不该把玩家打死
  const f = w.enemies.f;
  w.craft.x = f.x[0]; w.craft.y = f.y[0];
  w.invuln = 0;
  for (let k = 0; k < 6; k++) stepWorld(w, DT, NO_INPUT);
  assert.equal(w.session.state, STATE.PLAYING, '教学中不应进入死亡结算');
  assert.ok(w.stats.hp > 90, '教学用高血池避免中断');
});

test('教学第一步：真实闭合一次光带即推进到清弹步', () => {
  const w = playing();
  startTutorial(w);
  stepTutorial(w, { loop: null });          // 触发布置靶机
  assert.equal(w.enemies.count, 4, '第一步四台靶机');
  const c = w.craft;
  // 绕靶机群画大圈（靶机分布在半径 175 上，圈半径取 230 保证收口带覆盖）
  const loopEv = fly(w, circle(c.x, c.y, 230, 40));
  assert.ok(loopEv, '应当确实闭合引爆');
  const tr = stepTutorial(w, { loop: loopEv });
  assert.ok(tr && tr.advanced && tr.step === 1, '闭合后应推进到第二步');
  assert.equal(w.enemies.count, 0, '上一步靶机不该带入下一步');
});

test('教学防软锁：靶子被提前打死会重生，不会卡死在某一步', () => {
  const w = playing();
  startTutorial(w);
  stepTutorial(w, { loop: null });
  assert.equal(w.enemies.count, 4);
  sweepAll(w);
  assert.equal(w.enemies.count, 0, '靶机被提前清掉');
  stepTutorial(w, { loop: null });              // 目标未达成 + 无靶 = 重新布置
  assert.equal(w.enemies.count, 4, '必须补靶，否则第一步永远完不成');
});

test('教学第二步：守护圈清掉 3 发敌弹即可推进', () => {
  const w = playing();
  startTutorial(w);
  stepTutorial(w, { loop: null });              // 布置第一步并记录基线
  w.session.loopCount++;                        // 之后才达成第一步（基线必须在这之前记录）
  let tr0 = stepTutorial(w, { loop: null });
  assert.equal(tr0.step, 1, '先进入第二步');
  stepTutorial(w, { loop: null });              // 布置第二步炮艇
  assert.ok(w.enemies.count > 0);
  // 直接放三发敌弹在机体周围，模拟飞来的弹幕（比等炮艇开火更确定）
  const c = w.craft;
  for (let k = 0; k < 3; k++) {
    const i = w.ebullets.spawn();
    const f = w.ebullets.f;
    f.x[i] = c.x + 60 + k * 30; f.y[i] = c.y; f.px[i] = f.x[i]; f.py[i] = f.y[i];
    f.vx[i] = 0; f.vy[i] = 0; f.r[i] = 8; f.life[i] = 30;
  }
  const ev = fly(w, circle(c.x, c.y, 200, 40));
  assert.ok(ev, '应当闭合');
  assert.ok(w.session.bulletsCleared >= 3, `应清掉 3 发，实际 ${w.session.bulletsCleared}`);
  const tr = stepTutorial(w, { loop: ev });
  assert.ok(tr && tr.advanced && tr.step === 2, '清弹达标后进入破甲步');
});

test('教学三步全部完成会标记 done', () => {
  const w = playing();
  startTutorial(w);
  stepTutorial(w, { loop: null });
  w.session.loopCount++;                       // 第一步达成
  let tr = stepTutorial(w, { loop: null });
  assert.equal(tr.step, 1);
  stepTutorial(w, { loop: null });             // 布置第二步
  w.session.bulletsCleared += 3;
  tr = stepTutorial(w, { loop: null });
  assert.equal(tr.step, 2, '清弹 3 发后进入破甲步');
  stepTutorial(w, { loop: null });             // 布置第三步重甲
  assert.ok(w.enemies.count > 0, '第三步应有重甲靶');
  w.session.kills++;
  tr = stepTutorial(w, { loop: null });
  assert.ok(tr && tr.done, '击破重甲后教学完成');
});

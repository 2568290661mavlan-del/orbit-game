import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, spawnEnemy, stepWorld, STATE } from '../src/core/sim.mjs';
import { fireVolley } from '../src/core/weapons.mjs';
import { loadData, NO_INPUT, DT } from './helpers.mjs';

const data = loadData();

function playing(seed = 7) {
  const w = createWorld(data, seed);
  w.session.state = STATE.PLAYING;
  return w;
}

/** 静场：不刷怪、不自动开火，用来精确观察单个实体 */
function quiet(seed = 7) {
  const w = playing(seed);
  w.arena = { ...w.arena, rateMul: 0 };
  w.fireCd = 999;
  w.opened = true;               // 抑制开场波，保证只有测试自己放的实体
  return w;
}

function putGem(w, x, y, value = 1) {
  const i = w.gems.spawn();
  const gf = w.gems.f;
  gf.x[i] = x; gf.y[i] = y; gf.px[i] = x; gf.py[i] = y;
  gf.vx[i] = 0; gf.vy[i] = 0; gf.pull[i] = 0; gf.value[i] = value; gf.life[i] = 22;
  return i;
}

test('子弹飞离视野即消失，绝不从另一侧绕回来', () => {
  const w = quiet();
  w.stats.speed = 0;                     // 定住机体与摄像机，视野固定
  w.craft.x = 500; w.craft.y = 500;
  w.cam.x = 500; w.cam.y = 500;
  w.craft.aim = 0;
  fireVolley(w);
  assert.equal(w.bullets.count, 1);
  for (let k = 0; k < 120; k++) stepWorld(w, DT, NO_INPUT);
  assert.equal(w.bullets.count, 0, '飞出视野后必须被回收');
});

test('子弹出界后不会在对侧重新出现', () => {
  const w = quiet();
  w.stats.speed = 0;
  w.craft.x = 500; w.craft.y = 500;
  w.cam.x = 500; w.cam.y = 500;
  w.craft.aim = 0;
  fireVolley(w);
  for (let k = 0; k < 60; k++) {
    stepWorld(w, DT, NO_INPUT);
    for (let i = 0; i < w.bullets.count; i++) {
      assert.ok(w.bullets.f.x[i] >= 500, '子弹只能朝枪口方向走，不许出现在身后');
    }
  }
});

test('敌弹同样飞离视野即消失', () => {
  const w = playing();
  w.stats.speed = 0;
  w.craft.x = 500; w.craft.y = 500;
  w.cam.x = 500; w.cam.y = 500;
  const i = spawnEnemy(w, 'shooter', 400, 400);
  w.enemies.f.speed[i] = 0;
  const m = data.tuning.view.bulletMargin;
  let saw = false;
  for (let k = 0; k < 600; k++) {
    stepWorld(w, DT, NO_INPUT);
    for (let j = 0; j < w.ebullets.count; j++) {
      saw = true;
      assert.ok(Math.abs(w.ebullets.f.x[j] - w.cam.x) <= w.W / 2 + m + 1);
      assert.ok(Math.abs(w.ebullets.f.y[j] - w.cam.y) <= w.H / 2 + m + 1);
    }
  }
  assert.ok(saw, '射手应当开过火');
});

test('宝石进入拾取半径后不会瞬间消失，有可见飞行过程', () => {
  const w = quiet();
  w.craft.x = 500; w.craft.y = 500;
  const i = putGem(w, 500 + w.stats.pickupRadius * 0.8, 500);
  const gf = w.gems.f;
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.gems.count, 1, '第一帧不该直接被吃掉');
  assert.ok(gf.pull[i] > 0, '应进入被吸附状态');
  assert.ok(gf.vx[i] < 0, '应朝玩家方向加速');
});

test('宝石吸附有速度上限，不会瞬移', () => {
  const w = quiet();
  w.craft.x = 500; w.craft.y = 500;
  const i = putGem(w, 620, 500);
  const gf = w.gems.f;
  for (let k = 0; k < 20; k++) {
    stepWorld(w, DT, NO_INPUT);
    if (w.gems.count === 0) break;
    assert.ok(Math.hypot(gf.vx[i], gf.vy[i]) <= data.tuning.gem.maxSpeed + 1e-3);
  }
});

test('拾取范围天赋越大，吸附启动越早', () => {
  const mk = (pr) => {
    const w = quiet();
    w.stats.pickupRadius = pr;
    w.craft.x = 500; w.craft.y = 500;
    const i = putGem(w, 760, 500);
    stepWorld(w, DT, NO_INPUT);
    return w.gems.f.pull[i];
  };
  assert.equal(mk(130), 0, '默认范围外不吸');
  assert.ok(mk(300) > 0, '点了牵引场之后应当开始吸');
});

test('宝石最终被收集并计入经验与事件', () => {
  const w = quiet();
  w.stats.speed = 0;             // 定住机体，排除环绕接缝干扰，只看吸附本身
  w.craft.x = 500; w.craft.y = 500;
  putGem(w, 560, 500, 5);
  let gems = 0;
  for (let k = 0; k < 180 && w.gems.count > 0; k++) gems += stepWorld(w, DT, NO_INPUT).gems;
  assert.equal(w.gems.count, 0);
  assert.equal(gems, 1);
  assert.ok(w.session.xp > 0 || w.session.level > 1, '经验应入账（可能已直接升级）');
});

test('一旦被吸附就锁定追踪：机体恒速飞离也照样追上来', () => {
  const w = quiet();
  w.craft.x = 500; w.craft.y = 700; w.craft.heading = -Math.PI / 2;
  putGem(w, 500, 640, 3);        // 先在半径内触发吸附
  stepWorld(w, DT, NO_INPUT);
  assert.ok(w.gems.f.pull[0] > 0);
  let got = 0;
  for (let k = 0; k < 240 && w.gems.count > 0; k++) got += stepWorld(w, DT, NO_INPUT).gems;
  assert.equal(got, 1, '锁定后不应漏掉');
});

test('拾取会产生火花粒子（kind 3）', () => {
  const w = quiet();
  w.stats.speed = 0;
  w.craft.x = 500; w.craft.y = 500;
  putGem(w, 530, 500);
  for (let k = 0; k < 60 && w.gems.count > 0; k++) stepWorld(w, DT, NO_INPUT);
  let found = false;
  for (let k = 0; k < w.parts.count; k++) if (w.parts.f.kind[k] === 3) found = true;
  assert.ok(found, '应有拾取火花');
});

test('仿真保存上一步坐标，供渲染插值使用', () => {
  const w = playing();
  spawnEnemy(w, 'charger', 300, 300);
  const x0 = w.enemies.f.x[0];
  stepWorld(w, DT, NO_INPUT);
  assert.equal(w.enemies.f.px[0], x0);
  assert.notEqual(w.enemies.f.x[0], w.enemies.f.px[0]);
  assert.equal(w.craft.px !== w.craft.x || w.craft.py !== w.craft.y, true);
});

test('新生成实体的 prev 等于自身，插值不会从原点拉出条纹', () => {
  const w = playing();
  const i = spawnEnemy(w, 'charger', 900, 400);
  assert.equal(w.enemies.f.px[i], w.enemies.f.x[i]);
  assert.equal(w.enemies.f.py[i], w.enemies.f.y[i]);
  w.craft.aim = 0;
  fireVolley(w);
  assert.equal(w.bullets.f.px[0], w.bullets.f.x[0]);
});

test('事件对象与配置缓冲被复用，步进零临时分配', () => {
  const w = playing();
  const ev1 = stepWorld(w, DT, NO_INPUT);
  const cfg1 = w.cfgBuf;
  const ev2 = stepWorld(w, DT, NO_INPUT);
  assert.equal(ev1, ev2, 'ev 必须是同一个对象');
  assert.equal(cfg1, w.cfgBuf);
});

test('交换删除后 prev 坐标跟着搬家，不会串位', () => {
  const w = quiet();
  spawnEnemy(w, 'charger', 300, 300);
  spawnEnemy(w, 'charger', 800, 800);
  stepWorld(w, DT, NO_INPUT);
  const x1 = w.enemies.f.x[1];   // 1 号实体这一步结束时的位置
  w.enemies.f.hp[0] = 0;
  stepWorld(w, DT, NO_INPUT);
  // 0 号槽现在住着原来的 1 号实体，其 prev 必须是它自己上一步的位置
  assert.ok(Math.abs(w.enemies.f.px[0] - x1) < 1e-3, `${w.enemies.f.px[0]} vs ${x1}`);
});
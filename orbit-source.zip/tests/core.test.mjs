import test from 'node:test';
import assert from 'node:assert/strict';
import { wrapAngle, angleDelta, approachAngle, wrapPos, TAU } from '../src/core/mathx.mjs';
import { makeRng } from '../src/core/rng.mjs';
import { createStore, sweep } from '../src/core/store.mjs';
import { createHash } from '../src/core/spatialHash.mjs';
import { circleOverlap, mitigate, hurtCraft, xpToNext } from '../src/core/combat.mjs';

test('wrapAngle 把任意角规约到 [-PI, PI)', () => {
  for (const a of [-100, -7, 0, 3.2, 20, 1234.5]) {
    const w = wrapAngle(a);
    assert.ok(w >= -Math.PI && w < Math.PI, `${a} -> ${w}`);
  }
});

test('angleDelta 走最短路径而非绕远', () => {
  assert.ok(Math.abs(angleDelta(3.0, -3.0) - (TAU - 6)) < 1e-9);
  assert.ok(Math.abs(angleDelta(0, 1) - 1) < 1e-9);
});

test('approachAngle 受最大步长限制', () => {
  assert.equal(approachAngle(0, Math.PI / 2, 0.05), 0.05);
  assert.ok(Math.abs(approachAngle(0, 0.01, 0.05) - 0.01) < 1e-12);
});

test('wrapPos 环形世界回绕正确', () => {
  assert.equal(wrapPos(-1, 100), 99);
  assert.equal(wrapPos(101, 100), 1);
});

test('同 seed 的 RNG 序列完全一致', () => {
  const a = makeRng(12345);
  const b = makeRng(12345);
  for (let i = 0; i < 200; i++) assert.equal(a.next(), b.next());
});

test('weighted 不会抽到权重为 0 的项', () => {
  const rng = makeRng(7);
  for (let i = 0; i < 300; i++) {
    const k = rng.weighted({ a: 0, b: 5, c: 0 });
    assert.equal(k, 'b');
  }
  assert.equal(rng.weighted({ a: 0 }), null);
});

test('store 容量满时拒绝生成而不是崩溃', () => {
  const s = createStore(3, ['v']);
  assert.equal(s.spawn(), 0);
  assert.equal(s.spawn(), 1);
  assert.equal(s.spawn(), 2);
  assert.equal(s.spawn(), -1);
  assert.equal(s.full, true);
});

test('store 交换删除把末尾元素补到空位', () => {
  const s = createStore(4, ['v']);
  for (const v of [10, 20, 30]) { const i = s.spawn(); s.f.v[i] = v; }
  s.kill(0);
  assert.equal(s.count, 2);
  assert.equal(s.f.v[0], 30);
  assert.equal(s.f.v[1], 20);
});

test('sweep 边遍历边删除不会漏元素', () => {
  const s = createStore(8, ['v']);
  for (const v of [1, 2, 3, 4, 5, 6]) { const i = s.spawn(); s.f.v[i] = v; }
  sweep(s, (i) => s.f.v[i] % 2 === 0);
  const left = [];
  for (let i = 0; i < s.count; i++) left.push(s.f.v[i]);
  assert.deepEqual(left.sort((a, b) => a - b), [1, 3, 5]);
});

test('空间哈希只返回邻近格内的实体', () => {
  const h = createHash(64);
  h.insert(10, 10, 0);
  h.insert(900, 900, 1);
  const out = [];
  h.query(10, 10, 8, out);
  assert.deepEqual(out, [0]);
});

test('空间哈希 clear 后可复用且无残留', () => {
  const h = createHash(64);
  h.insert(10, 10, 0);
  h.clear();
  const out = [];
  h.query(10, 10, 8, out);
  assert.equal(out.length, 0);
  assert.equal(h.bucketCount, 0);
});

test('圆形碰撞在相切时判定为命中', () => {
  assert.equal(circleOverlap(0, 0, 5, 10, 0, 5), true);
  assert.equal(circleOverlap(0, 0, 5, 10.01, 0, 5), false);
});

test('减伤有 0.75 上限，叠不成无敌', () => {
  assert.equal(mitigate(10, 0.9), 2.5);
  assert.equal(mitigate(10, 0), 10);
  assert.equal(mitigate(10, -1), 10);
});

test('无敌帧内不扣血', () => {
  const ctx = { hp: 3, invuln: 0.5, reduction: 0 };
  assert.equal(hurtCraft(ctx, 1), 0);
  assert.equal(ctx.hp, 3);
  ctx.invuln = 0;
  assert.equal(hurtCraft(ctx, 1), 1);
  assert.equal(ctx.hp, 2);
});

test('升级经验曲线单调递增', () => {
  let prev = 0;
  for (let lv = 1; lv <= 25; lv++) {
    const cur = xpToNext(lv);
    assert.ok(cur > prev, `level ${lv}`);
    prev = cur;
  }
});
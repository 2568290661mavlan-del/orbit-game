# 素材来源与许可登记

## 当前状态：美术零第三方 · 音频使用 CC0 素材

- **美术**：全部由代码在 Canvas 上程序化绘制（几何体、辉光、渐变、粒子、星云、星场），**无任何外部图片文件**。
- **字体**：使用操作系统自带字体，不分发字体文件。
- **音频**：自 P2-b 起引入 **Kenney** 的 CC0 音效包（原始 `.ogg` 存于 `assets/audio/`，构建时内联为 base64）。
  低频底噪层仍由 WebAudio 实时合成，无对应文件。

CC0 1.0 允许个人、教育与**商业**使用，无需署名。本项目仍逐条登记出处，便于审计。

## 音频素材逐条登记

引入日期：**2026-11-25**。作者：**Kenney（www.kenney.nl）**。许可：**CC0 1.0**（<http://creativecommons.org/publicdomain/zero/1.0/>）。署名要求：**无（自愿）**。商用：**允许**。

来源包 1：**Sci-fi Sounds 1.0**
- 落地页：<https://kenney.nl/assets/sci-fi-sounds>
- 实际下载：<https://opengameart.org/sites/default/files/sci-fi_sounds.zip>（5,875,104 bytes）
- 包内原始许可证已归档：`assets/audio/LICENSE-kenney-scifi.txt`

来源包 2：**Interface Sounds 1.0**
- 落地页：<https://kenney.nl/assets/interface-sounds>
- 实际下载：<https://opengameart.org/sites/default/files/kenney_interfaceSounds.zip>
- 包内原始许可证已归档：`assets/audio/LICENSE-kenney-interface.txt`

| 本项目文件 | 包内原始文件 | 来源包 | 用途 |
|---|---|---|---|
| `assets/audio/shoot.ogg` | `laserSmall_000.ogg` | Sci-fi Sounds | 玩家开火 |
| `assets/audio/hit.ogg` | `impactMetal_004.ogg` | Sci-fi Sounds | 子弹命中 |
| `assets/audio/kill.ogg` | `explosionCrunch_000.ogg` | Sci-fi Sounds | 击杀（连锁越高音高越高） |
| `assets/audio/burst.ogg` | `forceField_000.ogg` | Sci-fi Sounds | 回旋爆发 |
| `assets/audio/boom.ogg` | `lowFrequency_explosion_000.ogg` | Sci-fi Sounds | 爆发/死亡的低频叠加层 |
| `assets/audio/hurt.ogg` | `impactMetal_002.ogg` | Sci-fi Sounds | 玩家受击 |
| `assets/audio/dead.ogg` | `explosionCrunch_001.ogg` | Sci-fi Sounds | 玩家解体 |
| `assets/audio/ui.ogg` | `click_002.ogg` | Interface Sounds | 界面点击 |
| `assets/audio/level.ogg` | `confirmation_001.ogg` | Interface Sounds | 升级 |
| `assets/audio/win.ogg` | `confirmation_004.ogg` | Interface Sounds | 胜利 |
| `assets/audio/gem.ogg` | `select_002.ogg` | Interface Sounds | 拾取经验 |

合计 11 个文件、174.4 KB，构建时全部内联进 `build/index.html`，**产物不发起任何外部请求**。

**修改说明**：未对音频波形做任何剪辑或转码，仅在播放时调整 `playbackRate`（随机 ±3%，击杀按连锁升半音）与增益。

## 开发期依赖（不随产物分发）
| 名称 | 许可 | 用途 | 是否进入 build/ |
|---|---|---|---|
| esbuild | MIT | 开发期打包 | 否（仅其输出产物进入） |
| Node.js 内置 test runner | Node.js 许可 | 单元测试 | 否 |

## 登记规则
每条必须填全：文件名 / 作者 / 来源 URL / 许可类型（CC0 或 CC-BY）/ 是否需署名 / 商用是否允许 / 引入日期。
**授权不明 = 禁止入库**，不接受「网上找的」「应该免费」。
## 贴图（P2-j 新增）

来源包：**Space Shooter Redux** by Kenney Vleugels（www.kenney.nl），**CC0**，可商用、署名非强制。
- 落地页：https://kenney.nl/assets/space-shooter-redux （页面标注 Creative Commons CC0）
- 镜像页：https://opengameart.org/content/space-shooter-redux
- 实际下载：https://opengameart.org/sites/default/files/SpaceShooterRedux.zip （1,108,776 bytes）
- 授权原文归档：`assets/sprites/LICENSE-spaceShooterRedux.txt`；原始 zip 留存于 `assets/_src/SpaceShooterRedux.zip`

| 本地文件 | 包内原始路径 | 用途 |
|---|---|---|
| craft.png | PNG/playerShip1_blue.png | 玩家机体 |
| charger.png | PNG/Enemies/enemyRed1.png | 冲锋艇 |
| curver.png | PNG/Enemies/enemyBlue2.png | 弧线艇（装甲） |
| splitter.png | PNG/Enemies/enemyGreen3.png | 分裂艇（装甲） |
| shooter.png | PNG/Enemies/enemyBlack4.png | 炮艇 |
| tank.png | PNG/Enemies/enemyBlack5.png | 重装舰（装甲） |
| bomber.png | PNG/Enemies/enemyRed4.png | 自爆艇 |
| escort.png | PNG/Enemies/enemyBlue5.png | 护卫艇 |
| boss.png | PNG/Enemies/enemyBlack3.png | 旗舰与阶段小 Boss |
| bullet.png | PNG/Lasers/laserBlue02.png | 玩家弹（16 方向烘焙） |
| ebullet.png | PNG/Lasers/laserRed02.png | 敌方弹（16 方向烘焙） |

未修改原始图像内容，仅在烘焙期加辉光并旋转对齐航向。
**色盲模式不使用贴图**，仍走程序几何体 + Okabe-Ito 配色，保证形状/颜色双编码。

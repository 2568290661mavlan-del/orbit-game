// 装配层：主循环、状态切换、设置、音频、压测与 QA 场景入口。
import tuning from '../data/tuning.json';
import enemies from '../data/enemies.json';
import upgrades from '../data/upgrades.json';
import combos from '../data/combos.json';
import waves from '../data/waves.json';
import arenas from '../data/arenas.json';
import zh from '../data/i18n/zh.json';
import en from '../data/i18n/en.json';
import { createWorld, resetWorld, spawnEnemy, stepWorld, STATE } from './core/sim.mjs';
import { confirmChoice, summarize } from './core/session.mjs';
import { applyUpgrade, applyCombos } from './core/upgrades.mjs';
import { createRenderer } from './render/renderer.mjs';
import { createBloom } from './render/bloom.mjs';
import { createInput } from './platform/input.mjs';
import { createPerf } from './platform/perf.mjs';
import { createI18n } from './platform/i18n.mjs';
import { createUI } from './platform/ui.mjs';
import { createAudio } from './platform/audio.mjs';
import { loadSettings, saveSettings, applySettings } from './platform/settings.mjs';
import { pilotInput } from './platform/autopilot.mjs';
import { startTutorial, stepTutorial } from './core/tutorial.mjs';
import { writeCheckpoint, readCheckpoint, clearCheckpoints } from './platform/save.mjs';

const DATA = { tuning, enemies, upgrades, waves, arenas, combos };
const FIXED = tuning.fixedDt;

function boot() {
  const frame = document.getElementById('frame');
  const canvas = document.getElementById('game');
  canvas.width = tuning.worldW;
  canvas.height = tuning.worldH;

  const params = new URLSearchParams(location.search);
  const settings = loadSettings();
  if (params.get('lang')) settings.lang = params.get('lang');
  if (params.get('scale')) settings.uiScale = Number(params.get('scale'));
  if (params.get('aim')) settings.aim = params.get('aim');

  const i18n = createI18n({ zh, en }, settings.lang);
  // 首次启动自动进教学；学过之后不再打扰。QA 可用 ?tutorial=1 强制开启
  let tutorialArmed = params.get('tutorial') === '1';
  if (!params.get('auto') && !params.get('bench') && !tutorialArmed) {
    try { tutorialArmed = !localStorage.getItem('orbit.tutDone'); } catch { tutorialArmed = false; }
  }
  const ui = createUI(frame, i18n);
  const world = createWorld(DATA, (Math.random() * 1e9) | 0, params.get('arena') || 'dawn');
  // 场景画到离屏 2D 画布，可见画布交给 WebGL 辉光合成器。
  // 拿不到 WebGL 时 bloom 内部自动退回 drawImage，等价于旧版渲染。
  const scene = document.createElement('canvas');
  scene.width = canvas.width; scene.height = canvas.height;
  const renderer = createRenderer(scene, world);
  const bloom = createBloom(canvas, scene);
  if (params.get('bloom') === '0') bloom.setEnabled(false);
  const input = createInput(window);
  // 按键重映射持久化：玩家改过的键，下次打开还在
  try {
    const kb = JSON.parse(localStorage.getItem('orbit.keys.v1') || 'null');
    if (kb) for (const [a, codes] of Object.entries(kb)) {
      if (input.bindings[a] && Array.isArray(codes)) input.rebind(a, codes);
    }
  } catch { /* 忽略 */ }
  const audio = createAudio(globalThis.__ORBIT_SFX || null);
  const perf = createPerf(600);
  const workPerf = createPerf(600);
  const runtime = { world, renderer, audio, i18n, ui };
  applySettings(settings, runtime);

  let acc = 0;
  let last = performance.now();
  let hudTick = 0;
  let shownState = null;
  let settingsOpen = false;
  let saveTimer = 0;

  const unlock = () => audio.unlock();
  window.addEventListener('keydown', unlock, { once: true });
  window.addEventListener('mousedown', unlock, { once: true });

  function startRun() {
    resetWorld(world, (Math.random() * 1e9) | 0, world.arenaId);
    applySettings(settings, runtime);
    world.tut = null;
    if (tutorialArmed) {
      tutorialArmed = false;
      startTutorial(world);
      ui.setTutorial(i18n.t('tut.1'));
    } else ui.setTutorial(null);
    perf.reset();
    shownState = null;
    saveTimer = 0;
    if (!world.tut) writeCheckpoint(world);   // 开局即有一个可回滚的锚点
  }

  /** 从检查点恢复：同种子 + 同升级重建，敌人按当前章节重新刷 */
  function restoreRun(sv) {
    if (!sv) return;
    resetWorld(world, sv.seed, sv.arenaId);
    applySettings(settings, runtime);
    world.tut = null;
    ui.setTutorial(null);
    const s = world.session;
    s.owned = {};
    for (const [id, n] of Object.entries(sv.owned || {})) {
      for (let k = 0; k < n; k++) if (upgrades[id]) applyUpgrade(world.stats, { id, ...upgrades[id] }, s.owned);
    }
    applyCombos(world.stats, s.owned, combos, s.combos);
    s.t = sv.t; s.xp = sv.xp; s.xpNext = sv.xpNext; s.level = sv.level; s.kills = sv.kills;
    world.chapter = sv.chapter;
    world.bgArenaId = (waves.chapters[sv.chapter] || {}).arena || world.arenaId;
    world.stats.hp = Math.max(1, Math.min(world.stats.maxHp, sv.hp));
    world.opened = true;
    s.state = STATE.PLAYING;
    world.chapterWord = i18n.t('menu.resumed');
    world.chapterFx = 2.4;
    perf.reset();
    shownState = null;
  }

  /** 教学完成或跳过：记录已学标记，整局重置进入正式对局 */
  function finishTutorial() {
    tutorialArmed = false;
    try { localStorage.setItem('orbit.tutDone', '1'); } catch { /* 隐私模式下静默 */ }
    startRun();
    world.chapterWord = i18n.t('tut.done');
    world.chapterFx = 3.2;
  }

  function advanceTutorial(ev) {
    if (!world.tut || world.tut.done) return;
    const tr = stepTutorial(world, ev);
    if (!tr) return;
    if (tr.advanced) { audio.play('level'); ui.setTutorial(i18n.t(`tut.${tr.step + 1}`)); }
    if (tr.done) finishTutorial();
  }

  function pick(id) {
    applyUpgrade(world.stats, { id, ...upgrades[id] }, world.session.owned);
    const fired = applyCombos(world.stats, world.session.owned, combos, world.session.combos);
    if (fired.length) audio.play('level');
    confirmChoice(world.session, id);
    audio.play('ui');
    shownState = null;
  }

  function changeSetting(key, value) {
    settings[key] = value;
    saveSettings(settings);
    applySettings(settings, runtime);
    audio.play('ui');
    shownState = null;
  }

  function openSettings() { settingsOpen = true; shownState = null; audio.play('ui'); }
  function closeSettings() { settingsOpen = false; shownState = null; audio.play('ui'); }

  function syncPanel() {
    const st = settingsOpen ? 'settings' : world.session.state;
    if (st === shownState) return;
    shownState = st;
    if (settingsOpen) ui.showSettings(settings, changeSetting, closeSettings, {
      bindings: input.bindings,
      onRebind(action, code) {
        input.rebind(action, [code]);
        try { localStorage.setItem('orbit.keys.v1', JSON.stringify(input.bindings)); } catch { /* 忽略 */ }
      },
      onResetKeys() {
        input.resetBindings();
        try { localStorage.removeItem('orbit.keys.v1'); } catch { /* 忽略 */ }
        shownState = null;
      },
    });
    else if (st === STATE.MENU) ui.showMenu({ cur: readCheckpoint('cur'), prev: readCheckpoint('prev') });
    else if (st === STATE.LEVELUP) ui.showChoices(world.session.choices, world.session.owned, pick, { defs: upgrades, stats: world.stats, combos, applied: world.session.combos });
    else if (st === STATE.DEAD) ui.showSummary(summarize(world.session), false);
    else if (st === STATE.WIN) ui.showSummary(summarize(world.session), true);
    else if (st === STATE.PAUSED) ui.showPause(openSettings);
    else ui.hidePanel();
  }

  const pointerBuf = { x: 0, y: 0 };
  function updatePointer() {
    if (settings.aim !== 'mouse' || !input.mouse.active) { world.pointer = null; return; }
    const r = canvas.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return;
    // 屏幕 → 世界：加上摄像机偏移，无限地图下鼠标必须换算到世界坐标
    pointerBuf.x = ((input.mouse.x - r.left) / r.width) * world.W + world.cam.x - world.W / 2;
    pointerBuf.y = ((input.mouse.y - r.top) / r.height) * world.H + world.cam.y - world.H / 2;
    world.pointer = pointerBuf;
  }

  function handleKeys() {
    if (input.justPressed('settings')) {
      if (settingsOpen) closeSettings(); else openSettings();
      return;
    }
    if (settingsOpen) return;
    const st = world.session.state;
    if (st === STATE.MENU) {
      if (input.justPressed('continueRun')) { restoreRun(readCheckpoint('cur')); return; }
      if (input.justPressed('rollback')) { restoreRun(readCheckpoint('prev')); return; }
      if (input.justPressed('tutorial')) { tutorialArmed = true; startRun(); return; }
      if (input.justPressed('confirm') || input.anyPressed()) startRun();
      return;
    }
    if (world.tut && !world.tut.done && input.justPressed('tutorial')) { finishTutorial(); return; }
    if (st === STATE.DEAD || st === STATE.WIN) {
      if (input.justPressed('restart') || input.justPressed('confirm')) startRun();
      return;
    }
    if (st === STATE.LEVELUP) {
      const keys = ['choice1', 'choice2', 'choice3', 'choice4'];
      for (let k = 0; k < world.session.choices.length && k < keys.length; k++) {
        if (input.justPressed(keys[k])) { pick(world.session.choices[k]); return; }
      }
      return;
    }
    // R 切换破甲/守护：很多玩家不会「一直按住 Shift」，切换式才是可发现的默认操作
    if ((st === STATE.PLAYING || st === STATE.PAUSED) && input.justPressed('stanceToggle')) {
      world.stanceLock = !world.stanceLock;
      audio.play('ui');
      world.floats.push({ x: world.craft.x, y: world.craft.y - 34, t: 0.9, max: 0.9, n: 0, cleared: 0, stanceSwap: true });
    }
    if (input.justPressed('pause')) {
      world.session.state = st === STATE.PAUSED ? STATE.PLAYING : STATE.PAUSED;
      shownState = null;
    }
  }

  function playEvents(ev) {
    if (!ev) return;
    if (ev.shots > 0) audio.play('shoot');
    if (ev.hits > 0) audio.play('hit');
    if (ev.kills > 0) audio.play('kill', { chain: world.session.chain });
    if (ev.gems > 0) audio.play('gem');
    if (ev.burst) audio.play('burst');
    if (ev.loop) audio.play(ev.loop.breaking ? 'loopbreak' : 'loop', { caught: ev.loop.caught });
    if (ev.chapter >= 0) {
      world.chapterWord = i18n.t(`chapter.${ev.chapter}`);
      audio.play('level');
      writeCheckpoint(world);      // 跨章即存档：这是「回滚到上一章」的锚点
    }
    if (ev.mini) audio.play('burst');
    if (ev.hurt) audio.play('hurt');
    if (ev.leveled > 0) audio.play('level');
    if (ev.died) audio.play('dead');
    if (ev.win) audio.play('win');
  }

  function frameLoop(now) {
    const t0 = performance.now();
    const frameMs = now - last;
    let delta = frameMs / 1000;
    last = now;
    if (delta > 0.25) delta = 0.25;
    acc += delta;

    input.poll();
    world.stance = (world.stanceLock || input.stanceHeld()) ? 'break' : 'guard';
    updatePointer();
    handleKeys();

    let steps = 0;
    while (acc >= FIXED && steps < 5) {
      if (!settingsOpen) {
        const ev = stepWorld(world, FIXED, input.axis);
        playEvents(ev);
        advanceTutorial(ev);
      }
      acc -= FIXED;
      steps++;
    }
    if (acc > FIXED * 5) acc = 0;

    // 定时检查点：跨章存一次，每 60 秒再兜底存一次，回滚槽始终保留上一个锚点
    if (world.session.state === STATE.PLAYING && !world.tut) {
      saveTimer += delta;
      if (saveTimer >= 60) { saveTimer = 0; writeCheckpoint(world); }
    }

    // alpha = 距离下一次仿真的进度，渲染插值消除固定步长与刷新率不整除造成的抖动
    renderer.draw(world, acc / FIXED, now);
    bloom.render();
    syncPanel();

    hudTick += delta;
    if (hudTick > 0.1) {
      hudTick = 0;
      ui.setHud(world, i18n.t(`set.aim.${settings.aim}`));
      const p = perf.stats();
      const wp = workPerf.stats();
      const ents = world.enemies.count + world.bullets.count + world.ebullets.count + world.gems.count;
      ui.setPerf(`${p.fps.toFixed(0)} FPS | 1% low ${p.low1.toFixed(0)} | ${wp.avgMs.toFixed(2)}ms | ${ents} ent`);
      audio.setIntensity(Math.min(1, world.enemies.count / 160));
    }
    perf.push(frameMs);
    workPerf.push(performance.now() - t0);
    input.endFrame();
    requestAnimationFrame(frameLoop);
  }

  // QA 调试钩子：可在不依赖帧率的环境里确定性推进仿真并验证 UI 流转。
  window.__orbit = { world, settings, start: startRun, pick, changeSetting, restoreRun, readCheckpoint };

  // 真实 sprite 是异步解码的：等它到位再进主循环，保证 QA 截图也是最终美术
  loadSprites().then((imgs) => {
  renderer.setImages(imgs);

  if (params.get('bench')) {
    runBench({ world, renderer, perf, ui, params, bloom });
  } else {
    const auto = Number(params.get('auto')) || 0;
    if (auto > 0) {
      startRun();
      // QA：预置已购改装 / 指定三选一，用于确定性验收前置依赖与组合提示（不参与正常对局）
      const own = (params.get('own') || '').split(',').filter(Boolean);
      const offer = (params.get('offer') || '').split(',').filter((id) => upgrades[id]);
      for (const id of own) if (upgrades[id]) applyUpgrade(world.stats, { id, ...upgrades[id] }, world.session.owned);
      const n = Math.round(auto / FIXED);
      const pilot = params.get('pilot') === '1';
      const hold = params.get('hold') === '1';
      let tutQaDone = false;
      for (let k = 0; k < n; k++) {
        if (world.session.state === STATE.LEVELUP) {
          if (offer.length) world.session.choices = offer;
          if (hold) break;
          pick(world.session.choices[0]);
        }
        if (world.session.state !== STATE.PLAYING) break;
        if (params.get('stance') === 'break') world.stance = 'break';
        stepWorld(world, FIXED, pilot ? pilotInput(world) : { x: 0, y: 0 });
        if (world.tut && !world.tut.done) {
          const tr = stepTutorial(world, world.ev);
          if (tr && tr.advanced) ui.setTutorial(i18n.t(`tut.${tr.step + 1}`));
          if (tr && tr.done) { ui.setTutorial(null); tutQaDone = true; break; }
        }
      }
      renderer.draw(world, 1, performance.now());
      bloom.render();
      syncPanel();
      ui.setHud(world, i18n.t(`set.aim.${settings.aim}`));
      document.title = `AUTO ${auto}s state=${world.session.state} t=${world.session.t.toFixed(1)} kills=${world.session.kills} lv=${world.session.level}${tutQaDone ? ' TUT_DONE' : ''}${world.tut ? ` tut=${world.tut.i}` : ''}`;
    } else if (params.get('settings') === '1') {
      openSettings();
      syncPanel();
    } else if (params.get('audio') === '1') {
      // 音频自检：解锁后报告成功解码的采样数，用于确认 CC0 素材真的进了产物
      unlock();
      setTimeout(() => { document.title = `SFX decoded=${audio.sampleCount} vol=${audio.volume}`; }, 900);
      world.session.state = STATE.MENU;
    } else {
      world.session.state = STATE.MENU;
    }
    requestAnimationFrame(frameLoop);
  }
  });
}

/** 解码内联的 CC0 贴图；任何一张失败都只是退回程序几何体，不影响可玩 */
function loadSprites() {
  const src = window.__ORBIT_SPRITES || {};
  const names = Object.keys(src);
  if (!names.length) return Promise.resolve(null);
  return Promise.all(names.map((n) => new Promise((res) => {
    const im = new Image();
    im.onload = () => res([n, im]);
    im.onerror = () => res([n, null]);
    im.src = src[n];
  }))).then((pairs) => Object.fromEntries(pairs.filter((p) => p[1])));
}

/**
 * 压测：n 实体、dur 秒、throttle 倍 CPU 节流。
 * 节流 = 每帧按实测主线程耗时 busy-wait (throttle-1) 倍，等价主线程慢 N 倍。
 * 局限：不模拟更慢的 GPU 光栅化路径，真实集显仍需复测。
 */
function runBench({ world, renderer, perf, ui, params, bloom }) {
  const n = Number(params.get('n')) || 500;
  const dur = Number(params.get('dur')) || 8;
  const throttle = Math.max(1, Number(params.get('throttle')) || 1);
  resetWorld(world, 20261125, params.get('arena') || 'dawn');
  world.stats.maxHp = 1e6;
  world.stats.hp = 1e6;
  for (let k = 0; k < n; k++) {
    spawnEnemy(world, k % 9 === 0 ? 'tank' : 'charger', (k * 137) % world.W, (k * 89) % world.H);
  }
  let warm = 0;
  let elapsed = 0;
  let last = performance.now();
  let phase = 0;
  perf.reset();
  const workPerf = createPerf(600);

  function tick(now) {
    const t0 = performance.now();
    let delta = (now - last) / 1000;
    last = now;
    if (delta > 0.25) delta = 0.25;
    phase += delta;
    const input = { x: Math.cos(phase * 1.2), y: Math.sin(phase * 1.2) };
    let acc = delta;
    let steps = 0;
    while (acc >= FIXED && steps < 5) { stepWorld(world, FIXED, input); acc -= FIXED; steps++; }
    if (world.session.state === STATE.LEVELUP) confirmChoice(world.session, world.session.choices[0]);
    let guard = 0;
    while (world.enemies.count < n && guard++ < 200) {
      spawnEnemy(world, guard % 9 === 0 ? 'tank' : 'charger', (guard * 137 + phase * 31) % world.W, (guard * 89 + phase * 17) % world.H);
    }
    renderer.draw(world, acc / FIXED, now);
    bloom.render();
    const work = performance.now() - t0;
    if (throttle > 1) {
      const burnUntil = performance.now() + work * (throttle - 1);
      while (performance.now() < burnUntil) { /* calibrated CPU throttle */ }
    }
    warm++;
    if (warm > 60) { elapsed += delta; perf.push(delta * 1000); workPerf.push(work); }
    if (elapsed < dur) { requestAnimationFrame(tick); return; }
    const p = perf.stats();
    const wp = workPerf.stats();
    const ents = world.enemies.count + world.bullets.count + world.ebullets.count + world.gems.count + world.parts.count;
    const info = {
      entities: ents, enemies: world.enemies.count, throttle: `${throttle}x`, frames: perf.count,
      avgFPS: p.fps.toFixed(1), low1FPS: p.low1.toFixed(1),
      workMs: wp.avgMs.toFixed(2), workWorstMs: wp.worstMs.toFixed(2),
      headroom: `${(16.67 / Math.max(0.01, wp.avgMs)).toFixed(1)}x`,
      heapMB: performance.memory ? (performance.memory.usedJSHeapSize / 1048576).toFixed(1) : 'n/a',
    };
    ui.showBench(info);
    ui.setPerf(`${p.fps.toFixed(0)} FPS | 1% low ${p.low1.toFixed(0)} | ${ents} ent`);
    document.title = `BENCH n=${ents} thr=${throttle} fps=${p.fps.toFixed(1)} low1=${p.low1.toFixed(1)}`;
    window.__benchResult = info;
  }
  requestAnimationFrame(tick);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
// 输入：键盘 + 手柄，绑定表可重映射（P2 接 UI）。只输出一个方向向量。
export const DEFAULT_BINDINGS = {
  up: ['KeyW', 'ArrowUp'],
  down: ['KeyS', 'ArrowDown'],
  left: ['KeyA', 'ArrowLeft'],
  right: ['KeyD', 'ArrowRight'],
  confirm: ['Space', 'Enter'],
  restart: ['KeyR'],
  pause: ['Escape', 'KeyP'],
  choice1: ['Digit1'],
  choice2: ['Digit2'],
  choice3: ['Digit3'],
  choice4: ['Digit4'],
  settings: ['KeyO'],
  tutorial: ['KeyT'],
  stance: ['ShiftLeft', 'ShiftRight'],   // 按住 = 临时破甲
  stanceToggle: ['KeyR'],               // 按一下 = 切换破甲/守护（游戏中）；结算界面 R 仍是重开
  continueRun: ['KeyC'],                // 主菜单：从检查点继续
  rollback: ['KeyV'],                   // 主菜单：回滚到上一个检查点
};

export function createInput(target = window) {
  const held = new Set();
  const pressed = new Set();
  let bindings = JSON.parse(JSON.stringify(DEFAULT_BINDINGS));
  let padIndex = null;
  const axis = { x: 0, y: 0 };

  function onKeyDown(e) {
    if (!held.has(e.code)) pressed.add(e.code);
    held.add(e.code);
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  }
  function onKeyUp(e) { held.delete(e.code); }
  function onBlur() { held.clear(); }
  function onPad(e) { padIndex = e.gamepad.index; }
  const mouse = { x: 0, y: 0, active: false, right: false };
  function onMouse(e) { mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true; }
  function onDown(e) { if (e.button === 2) mouse.right = true; }
  function onUp(e) { if (e.button === 2) mouse.right = false; }
  function onMenu(e) { e.preventDefault(); }

  target.addEventListener('mousemove', onMouse);
  target.addEventListener('mousedown', onDown);
  target.addEventListener('mouseup', onUp);
  target.addEventListener('contextmenu', onMenu);

  target.addEventListener('keydown', onKeyDown);
  target.addEventListener('keyup', onKeyUp);
  target.addEventListener('blur', onBlur);
  target.addEventListener('gamepadconnected', onPad);

  function isDown(action) {
    for (const code of bindings[action] || []) if (held.has(code)) return true;
    return false;
  }

  return {
    axis,
    mouse,
    get bindings() { return bindings; },
    rebind(action, codes) { bindings[action] = codes.slice(); },
    resetBindings() { bindings = JSON.parse(JSON.stringify(DEFAULT_BINDINGS)); },
    /** 每帧调用：合并键盘与手柄，输出归一化方向 */
    poll() {
      let x = (isDown('right') ? 1 : 0) - (isDown('left') ? 1 : 0);
      let y = (isDown('down') ? 1 : 0) - (isDown('up') ? 1 : 0);
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      const pad = padIndex != null ? pads[padIndex] : Array.from(pads).find((p) => p);
      if (pad) {
        const px = pad.axes[0] || 0;
        const py = pad.axes[1] || 0;
        if (Math.hypot(px, py) > 0.22) { x = px; y = py; }
        if (pad.buttons[12]?.pressed) y = -1;
        if (pad.buttons[13]?.pressed) y = 1;
        if (pad.buttons[14]?.pressed) x = -1;
        if (pad.buttons[15]?.pressed) x = 1;
      }
      const m = Math.hypot(x, y);
      if (m > 1) { x /= m; y /= m; }
      axis.x = x; axis.y = y;
      return axis;
    },
    /** 破甲姿态：按住 Shift 或鼠标右键。做成「按住」而不是「切换」，避免变成例行按键 */
    stanceHeld() { return isDown('stance') || mouse.right; },
    /** 本帧刚按下（用于重开/确认，避免长按重复触发） */
    justPressed(action) {
      for (const code of bindings[action] || []) {
        if (pressed.has(code)) { pressed.delete(code); return true; }
      }
      return false;
    },
    anyPressed() {
      const any = pressed.size > 0;
      pressed.clear();
      return any;
    },
    endFrame() { pressed.clear(); },
    dispose() {
      target.removeEventListener('keydown', onKeyDown);
      target.removeEventListener('keyup', onKeyUp);
      target.removeEventListener('blur', onBlur);
      target.removeEventListener('gamepadconnected', onPad);
      target.removeEventListener('mousemove', onMouse);
      target.removeEventListener('mousedown', onDown);
      target.removeEventListener('mouseup', onUp);
      target.removeEventListener('contextmenu', onMenu);
    },
  };
}
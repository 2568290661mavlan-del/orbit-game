// 设置：localStorage 持久化，file:// 下若不可用则退回内存，绝不因此崩溃。
const KEY = 'orbit.settings.v1';

export const DEFAULTS = {
  lang: 'zh',
  aim: 'mouse',        // mouse | auto | move
  volume: 0.6,
  uiScale: 1,
  colorblind: false,
  assistReduction: 0,  // 0 | 0.5 | 1
  enemySpeedMul: 1,    // 1 | 0.75
  shake: true,
  loop: true,          // 闭环引爆开关（核心动词，可关掉退回纯枪械玩法）
  mode: 'normal',      // easy=无限弹药 | normal=标准耗能 | hard=弹药消耗 ×1.8
};

export function loadSettings() {
  const s = { ...DEFAULTS };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      for (const k of Object.keys(DEFAULTS)) {
        if (saved[k] !== undefined && typeof saved[k] === typeof DEFAULTS[k]) s[k] = saved[k];
      }
    }
  } catch { /* 隐私模式 / file:// 限制：用默认值继续 */ }
  return s;
}

export function saveSettings(s) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
    return true;
  } catch {
    return false;
  }
}

/** 难度只改弹药经济：简单无限子弹，普通标准，困难消耗 ×1.8 */
export function shotCostFor(base, mode) {
  return base * (mode === 'easy' ? 0 : mode === 'hard' ? 1.8 : 1);
}

/** 把设置作用到运行时对象上。返回是否需要重建调色板。 */
export function applySettings(s, { world, renderer, audio, i18n, ui }) {
  world.aimMode = s.aim;
  world.assistReduction = s.assistReduction;
  world.enemySpeedMul = s.enemySpeedMul;
  world.shakeEnabled = s.shake;
  world.loopEnabled = s.loop;
  // 难度只改弹药经济，不改敌人血量——「简单」不该等于「怪变纸片」
  world.mode = s.mode;
  world.stats.shotCost = shotCostFor(world.data.tuning.base.shotCost, s.mode);
  audio.setVolume(s.volume);
  i18n.setLang(s.lang);
  world.loopWord = i18n.t('loop.caught');
  world.clearWord = i18n.t('loop.cleared');
  world.snapWord = i18n.t('loop.snap');
  world.smallWord = i18n.t('loop.small');
  world.xpWord = i18n.t('hud.xp');
  world.breakWord = i18n.t('stance.break');
  world.guardWord = i18n.t('stance.guard');
  world.boostWord = i18n.t('loop.boost');
  ui.setScale(s.uiScale);
  renderer.setColorblind(s.colorblind);
  return s;
}
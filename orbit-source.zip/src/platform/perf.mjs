// 帧率采样：平均 FPS 与 1% low（最差 1% 帧的等效帧率）。
// 1% low 才是手感真相，平均值会骗人。
export function createPerf(windowSize = 600) {
  const samples = new Float64Array(windowSize);
  let n = 0;
  let head = 0;
  let sum = 0;
  const sorted = new Float64Array(windowSize);

  return {
    push(ms) {
      if (n === windowSize) sum -= samples[head];
      else n++;
      samples[head] = ms;
      sum += ms;
      head = (head + 1) % windowSize;
    },
    get count() { return n; },
    stats() {
      if (n === 0) return { fps: 0, low1: 0, avgMs: 0, worstMs: 0 };
      const avg = sum / n;
      for (let i = 0; i < n; i++) sorted[i] = samples[i];
      const view = sorted.subarray(0, n);
      view.sort();
      const k = Math.max(1, Math.ceil(n * 0.01));
      let lowSum = 0;
      for (let i = 0; i < k; i++) lowSum += view[n - 1 - i];
      const lowMs = lowSum / k;
      return {
        fps: 1000 / avg,
        low1: 1000 / lowMs,
        avgMs: avg,
        worstMs: view[n - 1],
      };
    },
    reset() { n = 0; head = 0; sum = 0; },
  };
}
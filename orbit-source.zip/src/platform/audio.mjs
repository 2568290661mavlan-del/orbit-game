// 音频：优先播放 Kenney CC0 采样（assets/audio，出处见 assets/LICENSE.md）；
// 采样缺失时退回程序化合成，保证 Node 单测与无素材环境仍可运行。
// AudioContext 必须在首次用户手势后创建，否则浏览器自动播放策略会拒绝。
const MIN_GAP = { shoot: 0.05, hit: 0.03, kill: 0.03, gem: 0.045 };
const GAIN = {
  shoot: 0.26, hit: 0.20, kill: 0.34, burst: 0.5, hurt: 0.5,
  dead: 0.7, level: 0.45, win: 0.6, ui: 0.3, gem: 0.15, loop: 0.55, loopbreak: 0.6,
};
const MAX_VOICES = 24;
const ALIAS = { loop: 'burst', loopbreak: 'kill' };   // 守护=立场波升调；破甲=金属碎裂降调，听觉即可区分姿态

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function createAudio(samples = null) {
  let ac = null;
  let master = null;
  let drone = null;
  let droneGain = null;
  let noiseBuf = null;
  let volume = 0.6;
  let voices = 0;
  const buffers = Object.create(null);
  const last = Object.create(null);

  function ensure() {
    if (ac) return true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ac = new AC();
    master = ac.createGain();
    master.gain.value = volume;
    master.connect(ac.destination);

    const len = Math.floor(ac.sampleRate * 0.4);
    noiseBuf = ac.createBuffer(1, len, ac.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    // 低频底噪层：随战场强度起伏，制造压迫感（这一层保留程序化，采样不适合做长底噪）
    drone = ac.createOscillator();
    drone.type = 'sawtooth';
    drone.frequency.value = 55;
    const lp = ac.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 220;
    droneGain = ac.createGain();
    droneGain.gain.value = 0;
    drone.connect(lp); lp.connect(droneGain); droneGain.connect(master);
    drone.start();

    if (samples) {
      for (const k of Object.keys(samples)) {
        const bytes = b64ToBytes(samples[k]);
        ac.decodeAudioData(bytes.buffer).then((buf) => { buffers[k] = buf; }).catch(() => {});
      }
    }
    return true;
  }

  function tone(type, f0, f1, dur, gain, delay = 0) {
    const t = ac.currentTime + delay;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function noise(dur, gain, freq, delay = 0) {
    const t = ac.currentTime + delay;
    const s = ac.createBufferSource();
    s.buffer = noiseBuf;
    const bp = ac.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = freq;
    const g = ac.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(g); g.connect(master);
    s.start(t); s.stop(t + dur + 0.02);
  }

  /** 播放采样：轻微随机音高避免机关枪式重复听感 */
  function sample(name, rate, gain) {
    const buf = buffers[ALIAS[name] || name];
    if (!buf || voices >= MAX_VOICES) return false;
    const s = ac.createBufferSource();
    s.buffer = buf;
    s.playbackRate.value = rate;
    const g = ac.createGain();
    g.gain.value = gain;
    s.connect(g); g.connect(master);
    voices++;
    s.onended = () => { voices--; };
    s.start();
    return true;
  }

  function synth(name, opt) {
    switch (name) {
      case 'shoot': tone('triangle', 900, 620, 0.05, 0.05); break;
      case 'hit': noise(0.035, 0.05, 2600); break;
      case 'gem': tone('triangle', 1400, 1900, 0.04, 0.03); break;
      case 'kill': {
        const step = Math.min(18, opt.chain || 0);
        const f = 380 * Math.pow(2, step / 12);
        tone('square', f, f * 0.55, 0.11, 0.07);
        break;
      }
      case 'burst':
        tone('sawtooth', 160, 880, 0.18, 0.10);
        tone('sawtooth', 880, 120, 0.30, 0.08, 0.16);
        noise(0.28, 0.07, 900);
        break;
      case 'hurt': tone('sine', 150, 58, 0.32, 0.16); noise(0.22, 0.12, 320); break;
      case 'level':
        tone('triangle', 523, 523, 0.10, 0.09);
        tone('triangle', 659, 659, 0.10, 0.09, 0.09);
        tone('triangle', 784, 784, 0.16, 0.10, 0.18);
        break;
      case 'dead': tone('sawtooth', 320, 55, 0.9, 0.16); noise(0.7, 0.10, 200); break;
      case 'win':
        tone('triangle', 523, 523, 0.5, 0.09);
        tone('triangle', 659, 659, 0.5, 0.09, 0.05);
        tone('triangle', 784, 784, 0.6, 0.10, 0.10);
        tone('triangle', 1046, 1046, 0.7, 0.10, 0.16);
        break;
      case 'ui': tone('square', 1200, 900, 0.03, 0.04); break;
      default: break;
    }
  }

  return {
    unlock() { if (ensure() && ac.state === 'suspended') ac.resume(); },
    setVolume(v) {
      volume = Math.max(0, Math.min(1, v));
      if (master) master.gain.value = volume;
    },
    get volume() { return volume; },
    get sampleCount() { return Object.keys(buffers).length; },
    setIntensity(x) {
      if (!droneGain) return;
      const k = Math.max(0, Math.min(1, x));
      droneGain.gain.setTargetAtTime(0.015 + k * 0.05, ac.currentTime, 0.4);
      drone.frequency.setTargetAtTime(48 + k * 22, ac.currentTime, 0.6);
    },
    play(name, opt = {}) {
      if (!ac || volume <= 0) return;
      const gap = MIN_GAP[name];
      const now = ac.currentTime;
      if (gap) {
        if (last[name] && now - last[name] < gap) return;
        last[name] = now;
      }
      const g = GAIN[name] ?? 0.3;
      let rate = 0.97 + Math.random() * 0.06;
      if (name === 'kill') rate = Math.pow(2, Math.min(12, opt.chain || 0) / 12) * (0.98 + Math.random() * 0.04);
      if (name === 'gem') rate = 1.0 + Math.random() * 0.3;
      if (name === 'dead' || name === 'win' || name === 'level') rate = 1;
      if (name === 'loop') rate = 0.72 + Math.min(12, opt.caught || 0) * 0.045;
      if (name === 'loopbreak') rate = 0.55 + Math.min(12, opt.caught || 0) * 0.02;
      if (sample(name, rate, g)) {
        // 爆发与死亡叠一层低频，让「大事件」有身体感
        if (name === 'burst' || name === 'dead' || name === 'loop' || name === 'loopbreak') sample('boom', 0.9 + Math.random() * 0.1, g * 0.8);
        return;
      }
      synth(name, opt);
    },
  };
}
// 检查点存档：localStorage，双槽（当前 + 上一章）用于回滚。
// 只保存「可重建的信息」：种子、章节、时间、已选升级、经验与船体。
// 恢复时按相同种子与升级重建世界，敌人重新刷——等价于「从这一波重新来过」，
// 不做逐实体快照（那会把存档变成最容易坏的系统）。
const CUR = 'orbit.run.cur.v1';
const PREV = 'orbit.run.prev.v1';

export function snapshotRun(w) {
  const s = w.session;
  return {
    v: 1,
    seed: w.seed,
    arenaId: w.arenaId,
    chapter: w.chapter,
    t: Math.floor(s.t),
    owned: { ...s.owned },
    hp: w.stats.hp,
    xp: s.xp, xpNext: s.xpNext, level: s.level, kills: s.kills,
  };
}

export function writeCheckpoint(w) {
  try {
    const prev = localStorage.getItem(CUR);
    if (prev) localStorage.setItem(PREV, prev);
    localStorage.setItem(CUR, JSON.stringify(snapshotRun(w)));
    return true;
  } catch { return false; }   // 隐私模式 / file:// 限制：没存档也不能崩
}

export function readCheckpoint(which = 'cur') {
  try {
    const raw = localStorage.getItem(which === 'prev' ? PREV : CUR);
    if (!raw) return null;
    const sv = JSON.parse(raw);
    if (!sv || sv.v !== 1 || typeof sv.seed !== 'number') return null;
    return sv;
  } catch { return null; }
}

export function clearCheckpoints() {
  try { localStorage.removeItem(CUR); localStorage.removeItem(PREV); } catch { /* 忽略 */ }
}

// 文本全部外置。代码里不允许出现任何面向玩家的字面文案。
export function createI18n(packs, lang = 'zh') {
  let cur = packs[lang] ? lang : 'zh';
  return {
    get lang() { return cur; },
    setLang(l) { if (packs[l]) cur = l; },
    langs() { return Object.keys(packs); },
    t(key, vars) {
      let s = packs[cur][key];
      if (s === undefined) s = packs.zh[key];
      if (s === undefined) return key; // 缺键时暴露 key，方便 QA 发现而不是静默空白
      if (vars) for (const k in vars) s = s.replace(`{${k}}`, String(vars[k]));
      return s;
    },
  };
}
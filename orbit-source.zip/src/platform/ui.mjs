// DOM 覆盖层 UI。全部文案走 i18n，全部节点用 textContent 写入（无 innerHTML 注入面）。
import { pendingCombo } from '../core/upgrades.mjs';

function el(tag, cls, parent) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (parent) parent.appendChild(n);
  return n;
}

function fmtTime(t) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function createUI(frame, i18n) {
  const hud = el('div', 'hud', frame);
  // HUD 图形化：血量用格、回旋用条、姿态用徽章。只有时间/击杀/等级保留小数字。
  const hl = el('div', 'hside', hud);
  const hr = el('div', 'hside', hud);
  const chip = (parent, cls) => el('div', 'chip' + (cls ? ' ' + cls : ''), parent);
  const timeC = chip(hl), killC = chip(hl), lvC = chip(hl), chainC = chip(hl, 'chain');
  const stanceC = chip(hr, 'stance');
  const orbitBox = el('div', 'gauge', hr);
  const orbitFill = el('i', '', orbitBox);
  const hullBox = el('div', 'hull', hr);
  let pips = [];
  const setText = (node, txt) => { if (node.__t !== txt) { node.textContent = txt; node.__t = txt; } };
  const perf = el('div', 'perf', frame);
  const panel = el('div', 'panel hidden', frame);
  const tutbar = el('div', 'tutbar hidden', frame);
  let onChoice = null;

  function row(label, value) {
    const r = el('div', 'row', panel);
    el('span', 'k', r).textContent = label;
    el('span', 'v', r).textContent = value;
    return r;
  }

  function clearPanel() {
    panel.classList.remove('settings');
    while (panel.firstChild) panel.removeChild(panel.firstChild);
  }

  return {
    setScale(s) { frame.style.setProperty('--ui-scale', String(s)); },
    setPerf(text) { perf.textContent = text; },
    /** 教学条：不暂停游戏、不遮挡战场，只给当前这一步要做的事 */
    setTutorial(text) {
      if (!text) { tutbar.classList.add('hidden'); tutbar.textContent = ''; return; }
      tutbar.textContent = `${text}   ·   ${i18n.t('tut.skip')}`;
      tutbar.classList.remove('hidden');
    },
    setHud(w) {
      const s = w.session;
      setText(timeC, fmtTime(s.t));
      setText(killC, `✦ ${s.kills}`);
      setText(lvC, `Lv ${s.level}`);
      setText(chainC, `×${s.chain}`);
      chainC.classList.toggle('on', s.chain >= 2);

      // 船体：一格一血，低血变红。比「10/10」少一次心算。
      const max = Math.round(w.stats.maxHp), hp = Math.ceil(w.stats.hp);
      if (pips.length !== max) {
        hullBox.textContent = ''; pips = [];
        for (let i = 0; i < max; i++) pips.push(el('i', 'pip', hullBox));
      }
      for (let i = 0; i < max; i++) {
        pips[i].className = 'pip' + (i < hp ? (hp <= 3 ? ' on low' : ' on') : '');
      }

      // 回旋蓄能：满槽变金；强化生效期间显示剩余时间，让「充能换来了什么」看得见
      if (w.loopBoost > 0) {
        orbitFill.style.width = `${Math.round((w.loopBoost / w.data.tuning.loop.boostTime) * 100)}%`;
        orbitBox.classList.add('full');
      } else {
        const ok = Math.max(0, Math.min(1, w.craft.orbit / w.stats.orbitThreshold));
        orbitFill.style.width = `${Math.round(ok * 100)}%`;
        orbitBox.classList.toggle('full', ok >= 1);
      }

      const breaking = w.stance === 'break';
      setText(stanceC, i18n.t(breaking ? 'stance.break' : 'stance.guard'));
      stanceC.classList.toggle('break', breaking);
    },
    hidePanel() { panel.classList.add('hidden'); clearPanel(); },

    showMenu(save) {
      clearPanel();
      panel.classList.remove('hidden');
      el('h1', 'title', panel).textContent = i18n.t('app.title');
      el('p', 'tag', panel).textContent = i18n.t('menu.tag');
      el('p', 'hint', panel).textContent = i18n.t('menu.hint');
      el('p', 'cta', panel).textContent = i18n.t('menu.start');
      if (save && save.cur) {
        const m = Math.floor(save.cur.t / 60), sec = String(save.cur.t % 60).padStart(2, '0');
        el('p', 'cta', panel).textContent =
          `${i18n.t('menu.continue')}（${i18n.t(`chapter.${save.cur.chapter}`)} ${m}:${sec}）`;
        if (save.prev) el('p', 'hint', panel).textContent = i18n.t('menu.rollback');
      }
      el('p', 'hint', panel).textContent = i18n.t('menu.settings');
    },

    /** 设置面板：枚举用按钮组，数值用滑杆，全部即时生效 */
    showSettings(s, onChange, onBack, keyOps) {
      clearPanel();
      panel.classList.add('settings');   // 内容比屏幕高时从顶部排，不能居中裁掉第一行
      panel.classList.remove('hidden');
      el('h2', 'title', panel).textContent = i18n.t('set.title');

      const group = (labelKey, options, cur, pick) => {
        const r = el('div', 'srow', panel);
        el('span', 'k', r).textContent = i18n.t(labelKey);
        const box = el('div', 'opts', r);
        for (const o of options) {
          const b = el('button', 'opt' + (o.v === cur ? ' on' : ''), box);
          b.type = 'button';
          b.textContent = o.label;
          b.addEventListener('click', () => { pick(o.v); });
        }
      };
      const slider = (labelKey, min, max, step, cur, pick) => {
        const r = el('div', 'srow', panel);
        el('span', 'k', r).textContent = i18n.t(labelKey);
        const box = el('div', 'opts', r);
        const inp = el('input', 'range', box);
        inp.type = 'range'; inp.min = String(min); inp.max = String(max);
        inp.step = String(step); inp.value = String(cur);
        const out = el('span', 'val', box);
        out.textContent = String(cur);
        inp.addEventListener('input', () => {
          out.textContent = inp.value;
          pick(Number(inp.value));
        });
      };

      group('set.lang', [{ v: 'zh', label: '中文' }, { v: 'en', label: 'English' }], s.lang, (v) => onChange('lang', v));
      group('set.mode', [
        { v: 'easy', label: i18n.t('set.mode.easy') },
        { v: 'normal', label: i18n.t('set.mode.normal') },
        { v: 'hard', label: i18n.t('set.mode.hard') },
      ], s.mode, (v) => onChange('mode', v));
      group('set.aim', [
        { v: 'mouse', label: i18n.t('set.aim.mouse') },
        { v: 'auto', label: i18n.t('set.aim.auto') },
        { v: 'move', label: i18n.t('set.aim.move') },
      ], s.aim, (v) => onChange('aim', v));
      el('p', 'hint', panel).textContent = i18n.t('set.aimhint');
      slider('set.volume', 0, 1, 0.05, s.volume, (v) => onChange('volume', v));
      slider('set.scale', 1, 1.5, 0.05, s.uiScale, (v) => onChange('uiScale', v));
      group('set.cb', [{ v: false, label: i18n.t('set.off') }, { v: true, label: i18n.t('set.on') }], s.colorblind, (v) => onChange('colorblind', v));
      group('set.shake', [{ v: true, label: i18n.t('set.on') }, { v: false, label: i18n.t('set.off') }], s.shake, (v) => onChange('shake', v));
      group('set.assist', [
        { v: 0, label: i18n.t('set.assist.0') },
        { v: 0.5, label: i18n.t('set.assist.50') },
        { v: 1, label: i18n.t('set.assist.100') },
      ], s.assistReduction, (v) => onChange('assistReduction', v));
      group('set.espeed', [{ v: 1, label: '100%' }, { v: 0.75, label: '75%' }], s.enemySpeedMul, (v) => onChange('enemySpeedMul', v));
      // 闭环引爆是核心玩法，不是可选功能；开关只作为操作受限时的辅助手段放在这里
      group('set.loopAssist', [{ v: true, label: i18n.t('set.on') }, { v: false, label: i18n.t('set.off') }], s.loop, (v) => onChange('loop', v));
      el('p', 'hint', panel).textContent = i18n.t('set.loopAssistHint');

      // 按键重映射：点按钮后按新键即生效，立即写入 localStorage
      if (keyOps) {
        el('p', 'hint', panel).textContent = i18n.t('set.keys');
        for (const action of ['up', 'down', 'left', 'right', 'stanceToggle', 'pause']) {
          const r = el('div', 'srow', panel);
          el('span', 'k', r).textContent = i18n.t(`key.${action}`);
          const b = el('button', 'opt', r);
          b.type = 'button';
          b.textContent = (keyOps.bindings[action] || [])[0] || '—';
          b.addEventListener('click', () => {
            b.textContent = i18n.t('set.rebind');
            const h = (e) => {
              e.preventDefault(); e.stopPropagation();
              window.removeEventListener('keydown', h, true);
              keyOps.onRebind(action, e.code);
              b.textContent = e.code;
            };
            window.addEventListener('keydown', h, true);
          });
        }
        const rst = el('button', 'opt', panel);
        rst.type = 'button';
        rst.textContent = i18n.t('set.resetKeys');
        rst.addEventListener('click', keyOps.onResetKeys);
      }

      const back = el('button', 'choice back', panel);
      back.type = 'button';
      el('span', 'name', back).textContent = i18n.t('set.back');
      back.addEventListener('click', onBack);
    },

    showChoices(choices, owned, handler, info) {
      clearPanel();
      panel.classList.remove('hidden');
      onChoice = handler;
      el('h2', 'title', panel).textContent = i18n.t('levelup.title');
      el('p', 'hint', panel).textContent = i18n.t('levelup.hint');
      const list = el('div', 'choices', panel);
      choices.forEach((id, idx) => {
        const b = el('button', 'choice', list);
        b.type = 'button';
        el('span', 'num', b).textContent = String(idx + 1);
        const box = el('span', 'box', b);
        const have = owned[id] || 0;
        const def = info && info.defs[id];
        if (def && def.icon) el('span', 'icon', box).textContent = def.icon;
        el('span', 'name', box).textContent = i18n.t(`up.${id}`) + (have ? ` ×${have + 1}` : '');
        el('span', 'desc', box).textContent = i18n.t(`up.${id}.d`);
        // 数值前后对比：玩家要看得见「提升多少」，而不是只读一句形容词
        if (def && info.stats) {
          const parts = def.effects.map((e) => {
            const cur = info.stats[e.stat];
            if (typeof cur !== 'number') return null;
            const next = e.op === 'mul' ? cur * e.value : cur + e.value;
            const f = (v) => (Math.abs(v) >= 100 ? Math.round(v) : Math.round(v * 100) / 100);
            return `${i18n.t(`stat.${e.stat}`)} ${f(cur)} → ${f(next)}`;
          }).filter(Boolean);
          if (parts.length) el('span', 'delta', box).textContent = parts.join('   ');
        }
        if (def && info.combos) {
          const cid = pendingCombo(id, owned, info.combos, info.applied || {});
          if (cid) el('span', 'combo', box).textContent = `${i18n.t('up.combo')} ${i18n.t(`combo.${cid}`)}`;
        }
        b.addEventListener('click', () => onChoice && onChoice(id));
      });
    },

    showSummary(sum, win) {
      clearPanel();
      panel.classList.remove('hidden');
      el('h1', win ? 'title win' : 'title lose', panel).textContent =
        i18n.t(win ? 'win.title' : 'dead.title');
      row(i18n.t('sum.survived'), fmtTime(sum.survived));
      row(i18n.t('sum.kills'), String(sum.kills));
      row(i18n.t('sum.level'), String(sum.level));
      row(i18n.t('sum.chain'), String(sum.maxChain));
      row(i18n.t('sum.loop'), `${sum.loopCount} / ${sum.loopCaught} / ${sum.loopBest}`);
      row(i18n.t('sum.cleared'), String(sum.bulletsCleared));
      row(i18n.t('sum.mini'), String(sum.miniKilled));
      row(i18n.t('sum.cause'), sum.lastHitBy ? i18n.t(`enemy.${sum.lastHitBy}`) : '—');
      const path = sum.upgradePath.map((p) => i18n.t(`up.${p.id}`)).join(' › ');
      row(i18n.t('sum.path'), path || '—');
      el('p', 'cta', panel).textContent = i18n.t('sum.restart');
    },

    showPause(onSettings) {
      clearPanel();
      panel.classList.remove('hidden');
      el('h2', 'title', panel).textContent = i18n.t('pause.title');
      el('p', 'hint', panel).textContent = i18n.t('pause.hint');
      if (onSettings) {
        const b = el('button', 'choice back', panel);
        b.type = 'button';
        el('span', 'name', b).textContent = i18n.t('set.title');
        b.addEventListener('click', onSettings);
      }
    },

    showBench(info) {
      clearPanel();
      panel.classList.remove('hidden');
      el('h2', 'title', panel).textContent = i18n.t('bench.title');
      for (const k of Object.keys(info)) row(k, String(info[k]));
    },
  };
}
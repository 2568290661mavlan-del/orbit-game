// QA 自动驾驶：不是玩家 AI，只用来在无头/低帧环境里跑通 progression 与 UI 流转。
// 策略体现核心设计：枪管持续输出，走位负责「绕着怪群画一个圈」把整包敌人套进去引爆。
// 注意：探针必须会主动套圈，否则测出来的只是躲圈，闭环命中率会被严重低估。

/** 找怪群重心与外包半径：只统计机体附近 600 内的敌人 */
function pack(w) {
  const ef = w.enemies.f;
  let sx = 0, sy = 0, n = 0;
  for (let i = 0; i < w.enemies.count; i++) {
    const dx = ef.x[i] - w.craft.x, dy = ef.y[i] - w.craft.y;
    if (dx * dx + dy * dy > 600 * 600) continue;
    sx += ef.x[i]; sy += ef.y[i]; n++;
  }
  if (!n) return null;
  const cx = sx / n, cy = sy / n;
  let far = 0;
  for (let i = 0; i < w.enemies.count; i++) {
    const dx = ef.x[i] - cx, dy = ef.y[i] - cy;
    const d = dx * dx + dy * dy;
    if (d < 600 * 600 && d > far) far = d;
  }
  return { cx, cy, n, r: Math.sqrt(far) };
}

// 画圈必须「认一个死圆心」：怪群重心会跟着玩家跑，边追边画只会画成螺旋，永远闭不上。
const anchors = new WeakMap();

export function pilotInput(w) {
  const ef = w.enemies.f;
  // 姿态决策：附近有大块头装甲目标就切破甲，否则保持守护（清弹 + 回能）
  let bigArmored = false;
  for (let i = 0; i < w.enemies.count; i++) {
    if (ef.r[i] < 30) continue;
    const dx = ef.x[i] - w.craft.x, dy = ef.y[i] - w.craft.y;
    if (dx * dx + dy * dy < 620 * 620) { bigArmored = true; break; }
  }
  w.stance = bigArmored ? 'break' : 'guard';
  let eBest = 1e18, ex = 0, ey = 0;
  for (let i = 0; i < w.enemies.count; i++) {
    const dx = ef.x[i] - w.craft.x, dy = ef.y[i] - w.craft.y;
    const d = dx * dx + dy * dy;
    if (d < eBest) { eBest = d; ex = dx; ey = dy; }
  }

  const P = pack(w);
  const loopOn = w.loopEnabled !== false && w.data.tuning.loop.enabled;
  // 先保命：贴脸时一律切线躲避，不能为了画圈把自己送进怪堆
  if (eBest < 115 * 115) return { x: -ey, y: ex };
  // 有 3 个以上敌人聚在附近，就绕着它们的重心画圆——这是闭环引爆的正确用法
  if (P && P.n >= 3 && loopOn) {
    let a = anchors.get(w);
    const drift = a ? Math.hypot(w.craft.x - a.x, w.craft.y - a.y) : 0;
    if (!a || w.loop.n <= 1 || drift > 900) {
      a = { x: P.cx, y: P.cy, r: Math.max(160, Math.min(320, P.r * 1.35)) };
      anchors.set(w, a);
    }
    const rx = w.craft.x - a.x, ry = w.craft.y - a.y;
    const d = Math.hypot(rx, ry) || 1;
    const ux = rx / d, uy = ry / d;
    const err = (a.r - d) / a.r;         // 偏内就往外推，偏外就往里收
    return { x: -uy + ux * err * 2.2, y: ux + uy * err * 2.2 };
  }

  if (eBest < 1e18) {
    // 贴脸且没法套圈时切线绕行：既躲伤害，也顺手蓄回旋槽
    if (eBest < 130 * 130) return { x: -ey, y: ex };
    return { x: ex, y: ey };
  }

  const gf = w.gems.f;
  let gBest = 1e18, gx = 0, gy = 0;
  for (let i = 0; i < w.gems.count; i++) {
    const dx = gf.x[i] - w.craft.x, dy = gf.y[i] - w.craft.y;
    const d = dx * dx + dy * dy;
    if (d < gBest) { gBest = d; gx = dx; gy = dy; }
  }
  if (gBest < 1e18) return { x: gx, y: gy };
  return { x: 1, y: 0 };
}
// 预渲染精灵图集：把矢量绘制成本一次性付清，运行期只做 drawImage。
// 渐变 / 辉光只允许出现在这里（烘焙期），渲染循环里一律禁止。
// 形状与颜色双编码 → 色盲玩家靠形状也能区分敌人。
function makeCanvas(w, h) {
  if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

// Okabe-Ito 色盲安全配色
export const CB_COLORS = {
  charger: '#d55e00', curver: '#e69f00', splitter: '#cc79a7', shooter: '#56b4e9',
  tank: '#999999', bomber: '#f0e442', escort: '#009e73', boss: '#0072b2',
};

function rgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function mix(hex, target, k) {
  const [r, g, b] = rgb(hex);
  const f = (v) => Math.round(v + (target - v) * k);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
function alpha(hex, a) {
  const [r, g, b] = rgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
const light = (hex, k) => mix(hex, 255, k);
const dark = (hex, k) => mix(hex, 0, k);

function polygon(ctx, cx, cy, r, sides, rot) {
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const a = rot + (i / sides) * Math.PI * 2;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function halo(ctx, cx, cy, r0, r1, hex, a) {
  const g = ctx.createRadialGradient(cx, cy, r0, cx, cy, r1);
  g.addColorStop(0, alpha(hex, a));
  g.addColorStop(0.55, alpha(hex, a * 0.35));
  g.addColorStop(1, alpha(hex, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, r1, 0, Math.PI * 2);
  ctx.fill();
}

const SHAPES = { tri: 3, square: 4, diamond: 4, hex: 6 };
const ROT = { tri: -Math.PI / 2, square: Math.PI / 4, diamond: 0, hex: 0 };

/** 敌人：外辉光 + 立体渐变体 + 内核 + 亮边 + 暗描边 */
function enemySprite(d, color) {
  const pad = Math.ceil(d.r * 0.7) + 4;
  const size = Math.ceil(d.r * 2 + pad * 2);
  const c = makeCanvas(size, size);
  const ctx = c.getContext('2d');
  const m = size / 2;
  const sides = SHAPES[d.shape] || 4;
  const rot = ROT[d.shape] || 0;

  halo(ctx, m, m, d.r * 0.5, m, color, 0.42);

  const g = ctx.createLinearGradient(m - d.r, m - d.r, m + d.r, m + d.r);
  g.addColorStop(0, light(color, 0.42));
  g.addColorStop(0.5, color);
  g.addColorStop(1, dark(color, 0.45));
  polygon(ctx, m, m, d.r, sides, rot);
  ctx.fillStyle = g;
  ctx.fill();

  polygon(ctx, m, m, d.r * 0.46, sides, rot);
  ctx.fillStyle = alpha('#ffffff', 0.28);
  ctx.fill();

  polygon(ctx, m, m, d.r - 1, sides, rot);
  ctx.lineWidth = 2;
  ctx.strokeStyle = light(color, 0.65);
  ctx.stroke();

  polygon(ctx, m, m, d.r + 1, sides, rot);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = 'rgba(4,6,14,0.75)';
  ctx.stroke();
  return { canvas: c, half: m };
}

/** 玩家艇：白色 dart + 青色座舱 + 翼条，永远能从敌群里认出来 */
function craftSprite() {
  const cs = 64;
  const c = makeCanvas(cs, cs);
  const g = c.getContext('2d');
  const m = cs / 2;
  halo(g, m, m, 6, m, '#6fe3ff', 0.5);

  g.beginPath();
  g.moveTo(cs - 6, m);
  g.lineTo(16, 9);
  g.lineTo(24, m);
  g.lineTo(16, cs - 9);
  g.closePath();
  const body = g.createLinearGradient(16, 9, cs - 6, cs - 9);
  body.addColorStop(0, '#ffffff');
  body.addColorStop(0.55, '#dff3ff');
  body.addColorStop(1, '#7fa8c9');
  g.fillStyle = body;
  g.fill();
  g.lineWidth = 2.5;
  g.strokeStyle = '#0a1020';
  g.stroke();

  // 翼条
  g.strokeStyle = '#4fd2ff';
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(22, 15); g.lineTo(38, m - 5);
  g.moveTo(22, cs - 15); g.lineTo(38, m + 5);
  g.stroke();

  // 座舱
  g.beginPath();
  g.ellipse(40, m, 7, 4.2, 0, 0, Math.PI * 2);
  g.fillStyle = '#0d2b3d';
  g.fill();
  g.lineWidth = 1.5;
  g.strokeStyle = '#8ef0ff';
  g.stroke();
  return { canvas: c, half: m };
}

/** 尾焰：单独精灵，按航向旋转后画在艇尾 */
function flameSprite() {
  const w = 34, h = 22;
  const c = makeCanvas(w, h);
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(w, h / 2, 0, h / 2);
  grad.addColorStop(0, 'rgba(255,255,255,0.95)');
  grad.addColorStop(0.35, 'rgba(120,225,255,0.75)');
  grad.addColorStop(1, 'rgba(60,140,255,0)');
  g.fillStyle = grad;
  g.beginPath();
  g.moveTo(w, h / 2 - 5);
  g.quadraticCurveTo(w * 0.35, h / 2, w, h / 2 + 5);
  g.lineTo(0, h / 2);
  g.closePath();
  g.fill();
  return { canvas: c, half: h / 2, len: w };
}

/** 经验宝石：刻面菱形 + 绿色辉光 */
function gemSprite() {
  const s = 30;
  const c = makeCanvas(s, s);
  const g = c.getContext('2d');
  const m = s / 2;
  halo(g, m, m, 2, m, '#7ef9c6', 0.55);
  g.beginPath();
  g.moveTo(m, 5); g.lineTo(s - 7, m); g.lineTo(m, s - 5); g.lineTo(7, m);
  g.closePath();
  const grad = g.createLinearGradient(7, 5, s - 7, s - 5);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.45, '#7ef9c6');
  grad.addColorStop(1, '#1c8f6a');
  g.fillStyle = grad;
  g.fill();
  g.lineWidth = 1.4;
  g.strokeStyle = 'rgba(4,20,16,0.7)';
  g.stroke();
  g.beginPath();
  g.moveTo(m, 5); g.lineTo(m, s - 5);
  g.moveTo(7, m); g.lineTo(s - 7, m);
  g.strokeStyle = 'rgba(255,255,255,0.45)';
  g.lineWidth = 1;
  g.stroke();
  return { canvas: c, half: m };
}

/** 弹道：烘焙 16 个角度，运行期按角度取帧，避免逐子弹 setTransform */
export const DIR_STEPS = 16;
function bulletFrames(hex, len, thick) {
  const size = Math.ceil(len + thick * 3);
  const frames = [];
  for (let k = 0; k < DIR_STEPS; k++) {
    const c = makeCanvas(size, size);
    const g = c.getContext('2d');
    const m = size / 2;
    g.translate(m, m);
    g.rotate((k / DIR_STEPS) * Math.PI * 2);
    halo(g, 0, 0, 1, thick * 2.2, hex, 0.5);
    const grad = g.createLinearGradient(-len / 2, 0, len / 2, 0);
    grad.addColorStop(0, alpha(hex, 0.15));
    grad.addColorStop(0.6, hex);
    grad.addColorStop(1, '#ffffff');
    g.fillStyle = grad;
    g.beginPath();
    g.ellipse(0, 0, len / 2, thick / 2, 0, 0, Math.PI * 2);
    g.fill();
    frames.push({ canvas: c, half: m });
  }
  return frames;
}

/** 粒子软点：比硬方块更像火花 */
function sparkSprite(hex) {
  const s = 16;
  const c = makeCanvas(s, s);
  const g = c.getContext('2d');
  halo(g, s / 2, s / 2, 0.5, s / 2, hex, 0.95);
  return { canvas: c, half: s / 2 };
}

export const PART_COLORS = ['#ffd9a0', '#ffffff', '#9fe8ff', '#7ef9c6', '#c9a7ff'];

/**
 * 真实 sprite（CC0 Kenney）：烘焙辉光 + 统一朝向。
 * 素材玩家机头朝上、敌机机头朝下，而本作的航向基准是 +X，所以两者旋转方向相反。
 * 与程序几何体走同一条烘焙路径，运行期仍然只是一次 drawImage。
 */
function imageSprite(img, r, glowColor, rot, scale = 2.4) {
  const pad = Math.ceil(r * 0.8) + 6;
  const size = Math.ceil(r * 2 + pad * 2);
  const c = makeCanvas(size, size);
  const g = c.getContext('2d');
  const m = size / 2;
  halo(g, m, m, r * 0.35, m, glowColor, 0.5);
  const d = r * scale;
  g.translate(m, m);
  g.rotate(rot);
  g.drawImage(img, -d / 2, -d / 2, d, d);
  return { canvas: c, half: m };
}

/** 用真实激光贴图烘焙 16 方向帧，替换程序化椭圆弹 */
function bulletImageFrames(img, hex, len) {
  const size = Math.ceil(len * 2.2);
  const frames = [];
  for (let k = 0; k < DIR_STEPS; k++) {
    const c = makeCanvas(size, size);
    const g = c.getContext('2d');
    const m = size / 2;
    g.translate(m, m);
    g.rotate((k / DIR_STEPS) * Math.PI * 2);
    halo(g, 0, 0, 1, len * 0.7, hex, 0.55);
    g.rotate(Math.PI / 2);
    g.drawImage(img, -len * 0.75, -len * 0.75, len * 1.5, len * 1.5);
    frames.push({ canvas: c, half: m });
  }
  return frames;
}

export function buildAtlas(defs, colorblind = false, images = null) {
  const sprites = Object.create(null);
  for (const d of defs) {
    const color = colorblind ? (CB_COLORS[d.id] || d.color) : d.color;
    // 色盲模式继续用程序几何体：形状 + Okabe-Ito 配色双编码，不能被贴图颜色覆盖
    sprites[d.id] = (!colorblind && images && images[d.id])
      ? imageSprite(images[d.id], d.r, color, -Math.PI / 2, d.id === 'boss' ? 3.2 : 2.9)
      : enemySprite(d, color);
  }
  sprites.craft = images && images.craft && !colorblind
    ? imageSprite(images.craft, 22, '#6fe3ff', Math.PI / 2, 2.6)
    : craftSprite();
  sprites.flame = flameSprite();
  sprites.gem = gemSprite();
  sprites.bullet = images && images.bullet
    ? bulletImageFrames(images.bullet, '#ffe9a8', 22) : bulletFrames('#ffe9a8', 22, 9);
  sprites.ebullet = images && images.ebullet
    ? bulletImageFrames(images.ebullet, '#ff7bd5', 18) : bulletFrames('#ff7bd5', 16, 14);
  sprites.spark = PART_COLORS.map(sparkSprite);
  return sprites;
}
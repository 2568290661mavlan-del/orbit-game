// 背景烘焙：无缝网格瓦片 + 无缝星场瓦片 + 屏幕空间星云与暗角。
// 无限地图靠「瓦片平铺 + 视差」实现，运行期只有约 26 次 drawImage。
function makeCanvas(w, h) {
  if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

function rgbOf(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function blob(ctx, x, y, r, hex, a) {
  const [R, G, B] = rgbOf(hex);
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${R},${G},${B},${a})`);
  g.addColorStop(0.5, `rgba(${R},${G},${B},${a * 0.35})`);
  g.addColorStop(1, `rgba(${R},${G},${B},0)`);
  ctx.fillStyle = g;
  ctx.fillRect(x - r, y - r, r * 2, r * 2);
}

function lcg(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

const TILE = 640;   // 80 的整数倍 → 网格接缝对齐

/** 无缝网格瓦片：细线 + 每 4 格一条亮线 */
function gridTile(arena) {
  const c = makeCanvas(TILE, TILE);
  const ctx = c.getContext('2d');
  ctx.lineWidth = 1;
  ctx.strokeStyle = arena.grid;
  ctx.globalAlpha = 0.45;
  ctx.beginPath();
  for (let x = 0; x < TILE; x += 80) { ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, TILE); }
  for (let y = 0; y < TILE; y += 80) { ctx.moveTo(0, y + 0.5); ctx.lineTo(TILE, y + 0.5); }
  ctx.stroke();
  ctx.globalAlpha = 0.85;
  ctx.beginPath();
  ctx.moveTo(0.5, 0); ctx.lineTo(0.5, TILE);
  ctx.moveTo(0, 0.5); ctx.lineTo(TILE, 0.5);
  ctx.stroke();
  ctx.globalAlpha = 1;
  return c;
}

/** 无缝星场瓦片：星星避开边缘，平铺时不会出现半颗 */
function starTile() {
  const c = makeCanvas(TILE, TILE);
  const g = c.getContext('2d');
  const rnd = lcg(0x5eed);
  for (let i = 0; i < 110; i++) {
    const x = 4 + rnd() * (TILE - 8);
    const y = 4 + rnd() * (TILE - 8);
    const t = rnd();
    const r = t > 0.94 ? 1.9 : t > 0.7 ? 1.25 : 0.8;
    g.fillStyle = `rgba(${200 + ((t * 55) | 0)},${220 + ((t * 35) | 0)},255,${0.18 + t * 0.55})`;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  return c;
}

/**
 * 远景剪影层：巨大行星 + 光环、远方巨构残骸、小行星群。
 * 画面「空」的根因不是星星不够多，而是没有大形状对比和远近层次。
 * 这一层视差只有 0.12，几乎不动，负责给画面一个「远方」。
 * 所有形状避开瓦片边缘，保证平铺无缝。
 */
function farTile(arena) {
  const S = TILE * 2;
  const c = makeCanvas(S, S);
  const g = c.getContext('2d');
  const [R, G, B] = rgbOf(arena.accent);

  // 行星：暗盘 + 受光边缘，不用纯圆，避免「贴纸感」
  const px = S * 0.30, py = S * 0.32, pr = 168;
  const grad = g.createRadialGradient(px - pr * 0.4, py - pr * 0.45, pr * 0.1, px, py, pr);
  grad.addColorStop(0, `rgba(${R},${G},${B},0.20)`);
  grad.addColorStop(0.7, `rgba(${R},${G},${B},0.07)`);
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grad;
  g.beginPath(); g.arc(px, py, pr, 0, Math.PI * 2); g.fill();
  g.strokeStyle = `rgba(${R},${G},${B},0.22)`;
  g.lineWidth = 1.6;
  g.beginPath(); g.arc(px, py, pr * 0.98, -2.3, -0.5); g.stroke();
  // 行星环：两条椭圆，制造尺度感
  g.save();
  g.translate(px, py); g.rotate(-0.42);
  for (const [rr, al] of [[1.55, 0.16], [1.78, 0.09]]) {
    g.beginPath(); g.ellipse(0, 0, pr * rr, pr * rr * 0.22, 0, 0, Math.PI * 2);
    g.strokeStyle = `rgba(${R},${G},${B},${al})`; g.lineWidth = 3; g.stroke();
  }
  g.restore();

  // 远方巨构残骸：折线多边形剪影，轮廓比细节重要
  const rnd = lcg(0xfa12);
  for (let k = 0; k < 3; k++) {
    const bx = S * (0.62 + k * 0.11), by = S * (0.66 + (k % 2) * 0.12);
    const sc = 0.8 + rnd() * 0.7;
    g.save(); g.translate(bx, by); g.rotate(rnd() * 1.2 - 0.6); g.scale(sc, sc);
    g.beginPath();
    g.moveTo(-70, -12); g.lineTo(-18, -12); g.lineTo(-18, -34); g.lineTo(6, -34);
    g.lineTo(6, -8); g.lineTo(64, -8); g.lineTo(64, 10); g.lineTo(10, 10);
    g.lineTo(10, 30); g.lineTo(-14, 30); g.lineTo(-14, 12); g.lineTo(-70, 12);
    g.closePath();
    g.fillStyle = `rgba(${R},${G},${B},0.10)`; g.fill();
    g.strokeStyle = `rgba(${R},${G},${B},0.16)`; g.lineWidth = 1.2; g.stroke();
    g.restore();
  }

  // 小行星群：不规则多边形，散布但不靠近边缘
  for (let k = 0; k < 9; k++) {
    const ax = 120 + rnd() * (S - 240), ay = 120 + rnd() * (S - 240);
    const ar = 8 + rnd() * 22;
    g.beginPath();
    for (let v = 0; v < 7; v++) {
      const a = (v / 7) * Math.PI * 2;
      const rr = ar * (0.7 + rnd() * 0.5);
      const x = ax + Math.cos(a) * rr, y = ay + Math.sin(a) * rr;
      if (v === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.closePath();
    g.fillStyle = `rgba(${R},${G},${B},0.12)`; g.fill();
  }
  return c;
}

export function buildBackground(w, h, arena) {
  // 星云：屏幕空间的环境色，低透明度，不随摄像机 1:1 移动
  const nebula = makeCanvas(w, h);
  const nc = nebula.getContext('2d');
  blob(nc, w * 0.24, h * 0.30, h * 0.72, arena.accent, 0.13);
  blob(nc, w * 0.78, h * 0.72, h * 0.66, arena.grid, 0.20);
  blob(nc, w * 0.55, h * 0.12, h * 0.45, arena.accent, 0.08);

  // 暗角：最后盖在实体之上，把注意力压回画面中心
  const vignette = makeCanvas(w, h);
  const vc = vignette.getContext('2d');
  const vig = vc.createRadialGradient(w / 2, h / 2, h * 0.34, w / 2, h / 2, h * 0.95);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,0.6)');
  vc.fillStyle = vig;
  vc.fillRect(0, 0, w, h);

  return { grid: gridTile(arena), stars: starTile(), far: farTile(arena), nebula, vignette };
}

/** 无缝平铺：off 为摄像机在该层的位移（视差已乘好） */
export function tileDraw(ctx, img, offX, offY, W, H) {
  const tw = img.width, th = img.height;
  const sx = -(((offX % tw) + tw) % tw);
  const sy = -(((offY % th) + th) % th);
  for (let y = sy; y < H; y += th) {
    for (let x = sx; x < W; x += tw) ctx.drawImage(img, x, y);
  }
}
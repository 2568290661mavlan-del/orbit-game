// WebGL 辉光合成器：把 Canvas2D 的场景当作纹理，做亮部提取 + 可分离高斯模糊 + 加法叠回。
// 关键约束：**不改任何现有渲染逻辑**。场景照旧画在离屏 2D 画布上，这里只负责最后一道合成。
// 拿不到 WebGL 就退回普通 drawImage，画面等于旧版，不会因为显卡差异而打不开游戏。
const VS = 'attribute vec2 p;varying vec2 uv;void main(){uv=p*0.5+0.5;gl_Position=vec4(p,0.,1.);}';

const FS_BRIGHT = `precision mediump float;varying vec2 uv;uniform sampler2D tex;uniform float th;
void main(){vec3 c=texture2D(tex,uv).rgb;
float l=dot(c,vec3(0.2126,0.7152,0.0722));
float k=smoothstep(th,th+0.35,l);
gl_FragColor=vec4(c*k,1.);}`;

const FS_BLUR = `precision mediump float;varying vec2 uv;uniform sampler2D tex;uniform vec2 dir;
void main(){vec3 s=texture2D(tex,uv).rgb*0.227027;
s+=texture2D(tex,uv+dir*1.3846).rgb*0.316216;
s+=texture2D(tex,uv-dir*1.3846).rgb*0.316216;
s+=texture2D(tex,uv+dir*3.2308).rgb*0.070270;
s+=texture2D(tex,uv-dir*3.2308).rgb*0.070270;
gl_FragColor=vec4(s,1.);}`;

const FS_COMP = `precision mediump float;varying vec2 uv;
uniform sampler2D tex;uniform sampler2D glow;uniform float strength;
void main(){vec3 base=texture2D(tex,uv).rgb;
vec3 b=texture2D(glow,uv).rgb;
vec3 c=base+b*strength;
// 轻微提亮中间调并做软压肩，避免加法叠加把亮部烧成死白
c=c/(1.0+c*0.12);
c=pow(c,vec3(0.92));
vec2 d=uv-0.5;
float vig=1.0-dot(d,d)*0.55;
gl_FragColor=vec4(c*vig,1.);}`;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

function program(gl, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, VS));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.bindAttribLocation(p, 0, 'p');
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {};
  const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
  return { p, u };
}

export function createBloom(view, scene) {
  let gl = null;
  try {
    gl = view.getContext('webgl', { alpha: false, antialias: false, depth: false, stencil: false, powerPreference: 'high-performance' });
  } catch { gl = null; }
  if (!gl) {
    const ctx2d = view.getContext('2d', { alpha: false });
    return { enabled: false, backend: 'canvas2d', setEnabled() {}, render() { ctx2d.drawImage(scene, 0, 0); } };
  }

  const W = scene.width, H = scene.height;
  const bw = Math.max(1, W >> 2), bh = Math.max(1, H >> 2);
  let strength = 0.75, on = true;

  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.disable(gl.DEPTH_TEST);
  gl.disable(gl.BLEND);

  function makeTex(w, h) {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    if (w) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    return t;
  }
  function target(w, h) {
    const tex = makeTex(w, h);
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    return { tex, fbo, w, h };
  }

  const sceneTex = makeTex(0, 0);
  const A = target(bw, bh), B = target(bw, bh);
  const pBright = program(gl, FS_BRIGHT), pBlur = program(gl, FS_BLUR), pComp = program(gl, FS_COMP);

  function pass(prog, dst, setup) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, dst ? dst.fbo : null);
    gl.viewport(0, 0, dst ? dst.w : W, dst ? dst.h : H);
    gl.useProgram(prog.p);
    setup(prog.u);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  function bind(unit, tex, loc) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.uniform1i(loc, unit);
  }

  function render() {
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, sceneTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scene);
    if (on) {
      pass(pBright, A, (u) => { bind(0, sceneTex, u.tex); gl.uniform1f(u.th, 0.62); });
      pass(pBlur, B, (u) => { bind(0, A.tex, u.tex); gl.uniform2f(u.dir, 1 / bw, 0); });
      pass(pBlur, A, (u) => { bind(0, B.tex, u.tex); gl.uniform2f(u.dir, 0, 1 / bh); });
      pass(pBlur, B, (u) => { bind(0, A.tex, u.tex); gl.uniform2f(u.dir, 2.2 / bw, 0); });
      pass(pBlur, A, (u) => { bind(0, B.tex, u.tex); gl.uniform2f(u.dir, 0, 2.2 / bh); });
    }
    pass(pComp, null, (u) => {
      bind(0, sceneTex, u.tex);
      bind(1, A.tex, u.glow);
      gl.uniform1f(u.strength, on ? strength : 0);
    });
  }

  return {
    enabled: true,
    backend: 'webgl',
    setEnabled(v) { on = !!v; },
    setStrength(v) { strength = v; },
    render,
  };
}

// Canvas2D 批渲染器。渐变/辉光只在图集烘焙期出现，运行期只做 drawImage 与批量路径。
// 无限地图：摄像机跟随 + 背景瓦片视差 + 视野外实体剔除。
// 固定 60Hz 仿真 + 渲染插值（alpha），消除「帧率没掉但画面发抖」的时间走样。
import { buildAtlas, DIR_STEPS } from './atlas.mjs';
import { buildBackground, tileDraw } from './backdrop.mjs';

const TAU = Math.PI * 2;
const TRAIL = 18;
const pos = { x: 0, y: 0 };

function lerpPos(f, i, a) {
  const x = f.x[i], y = f.y[i];
  pos.x = f.px[i] + (x - f.px[i]) * a;
  pos.y = f.py[i] + (y - f.py[i]) * a;
  return pos;
}

function lerpAngle(a0, a1, k) {
  let d = a1 - a0;
  while (d > Math.PI) d -= TAU;
  while (d < -Math.PI) d += TAU;
  return a0 + d * k;
}

function dirFrame(vx, vy) {
  let k = Math.round((Math.atan2(vy, vx) / TAU) * DIR_STEPS);
  k %= DIR_STEPS;
  return k < 0 ? k + DIR_STEPS : k;
}

export function createRenderer(canvas, world) {
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
  let cb = false;
  let hitGrad = null, hitW = 0, hitH = 0;
  let sprites = buildAtlas(world.defs, cb);
  let bg = buildBackground(world.W, world.H, world.arena);
  let bgArena = world.arenaId;
  const trail = new Float32Array(TRAIL * 2);
  let trailN = 0;
  let trailHead = 0;

  function setColorblind(on) {
    if (cb === !!on) return;   // 未变化就不重建图集
    cb = !!on;
    sprites = buildAtlas(world.defs, cb, images);
  }

  /** 真实 sprite 加载完成后重建图集（素材是异步解码的） */
  let images = null;
  function setImages(imgs) {
    images = imgs;
    sprites = buildAtlas(world.defs, cb, images);
  }

  function pushTrail(x, y) {
    trail[trailHead * 2] = x;
    trail[trailHead * 2 + 1] = y;
    trailHead = (trailHead + 1) % TRAIL;
    if (trailN < TRAIL) trailN++;
  }

  function draw(w, alpha = 1) {
    const wantBg = w.bgArenaId || w.arenaId;
    if (wantBg !== bgArena) {
      bg = buildBackground(w.W, w.H, w.data.arenas[wantBg]);
      bgArena = wantBg;
    }
    const W = w.W, H = w.H;
    const a = alpha < 0 ? 0 : alpha > 1 ? 1 : alpha;
    const camX = w.cam.px + (w.cam.x - w.cam.px) * a;
    const camY = w.cam.py + (w.cam.y - w.cam.py) * a;
    const sh = w.shakeEnabled === false ? 0 : w.shake;
    const ox = W / 2 - camX + (sh > 0 ? (Math.random() - 0.5) * sh : 0);
    const oy = H / 2 - camY + (sh > 0 ? (Math.random() - 0.5) * sh : 0);

    // 视野剔除边界（世界坐标）
    const L = camX - W / 2 - 90, R = camX + W / 2 + 90;
    const T = camY - H / 2 - 90, B = camY + H / 2 + 90;
    const vis = (x, y) => x > L && x < R && y > T && y < B;

    // —— 背景：底色 + 星云 + 星场（慢视差）+ 网格（1:1）——
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = w.arena.bg;
    ctx.fillRect(0, 0, W, H);
    ctx.drawImage(bg.nebula, 0, 0);
    if (bg.far) tileDraw(ctx, bg.far, camX * 0.12, camY * 0.12, W, H);   // 远景剪影：几乎不动的「远方」
    tileDraw(ctx, bg.stars, camX * 0.35, camY * 0.35, W, H);
    tileDraw(ctx, bg.grid, camX, camY, W, H);
    ctx.setTransform(1, 0, 0, 1, ox, oy);

    // —— 经验宝石：被吸附时拉出轨迹线 ——
    const gf = w.gems.f;
    const gem = sprites.gem;
    ctx.strokeStyle = 'rgba(126,249,198,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    let pulled = 0;
    for (let i = 0; i < w.gems.count; i++) {
      if (gf.pull[i] <= 0) continue;
      const p = lerpPos(gf, i, a);
      if (!vis(p.x, p.y)) continue;
      ctx.moveTo(p.x - gf.vx[i] * 0.035, p.y - gf.vy[i] * 0.035);
      ctx.lineTo(p.x, p.y);
      pulled++;
    }
    if (pulled) ctx.stroke();
    for (let i = 0; i < w.gems.count; i++) {
      const p = lerpPos(gf, i, a);
      if (!vis(p.x, p.y)) continue;
      if (gf.kind[i] === 1) {
        // 能量球：清弹转化与破甲拆甲的掉落，和经验宝石一眼分开
        const r = 7 * (gf.pull[i] > 0 ? 1.3 : 1);
        ctx.beginPath(); ctx.arc(p.x, p.y, r * 1.9, 0, TAU);
        ctx.fillStyle = 'rgba(79,214,255,0.18)'; ctx.fill();
        ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU);
        ctx.fillStyle = '#4fd6ff'; ctx.fill();
        ctx.beginPath(); ctx.arc(p.x - r * 0.25, p.y - r * 0.25, r * 0.42, 0, TAU);
        ctx.fillStyle = '#eaffff'; ctx.fill();
        continue;
      }
      const d = gem.half * 2 * (gf.pull[i] > 0 ? 1.25 : 1);
      ctx.drawImage(gem.canvas, p.x - d / 2, p.y - d / 2, d, d);
    }

    // —— 轨迹光带：本作独占动词的可视化，玩家要能看见自己画的圈 ——
    const LP = w.loop;
    if (LP.n > 1) {
      const brk = w.stance === 'break';
      // 光带按年龄分三段渐隐：让「线会消失」变成可预期的事，而不是突然断掉
      const seg = [[0, Math.floor(LP.n * 0.4), 0.16], [Math.floor(LP.n * 0.4), Math.floor(LP.n * 0.75), 0.34], [Math.floor(LP.n * 0.75), LP.n, 0.62]];
      ctx.lineWidth = brk ? 6 : 4;
      for (const [a, b, al] of seg) {
        if (b - a < 1) continue;
        ctx.strokeStyle = brk ? `rgba(255,179,71,${al})` : `rgba(201,167,255,${al})`;
        ctx.beginPath();
        ctx.moveTo(LP.xs[a], LP.ys[a]);
        for (let i = a + 1; i < b; i++) ctx.lineTo(LP.xs[i], LP.ys[i]);
        if (b >= LP.n) ctx.lineTo(w.craft.x, w.craft.y);
        ctx.stroke();
      }
      // 闭合提示：靠近可闭合的历史点时画吸附虚线 + 高亮靶环，
      // 玩家不该靠猜「什么时候算闭合」。
      const cfgL = w.data.tuning.loop;
      let bi = -1, bd = 1e18;
      for (let i = 0; i <= LP.n - cfgL.minPoints; i++) {
        const dx = w.craft.x - LP.xs[i], dy = w.craft.y - LP.ys[i];
        const d2 = dx * dx + dy * dy;
        if (d2 < bd) { bd = d2; bi = i; }
      }
      if (bi >= 0 && bd < (cfgL.closeDist * 3) ** 2) {
        const near = bd <= cfgL.closeDist * cfgL.closeDist;
        ctx.setLineDash([9, 7]);
        ctx.strokeStyle = near ? '#7ef9c6' : 'rgba(126,249,198,0.4)';
        ctx.lineWidth = near ? 3 : 2;
        ctx.beginPath();
        ctx.moveTo(w.craft.x, w.craft.y);
        ctx.lineTo(LP.xs[bi], LP.ys[bi]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.arc(LP.xs[bi], LP.ys[bi], near ? 22 : 14, 0, TAU);
        ctx.stroke();
      }
    }
    // —— 闭环引爆：填充 + 亮边，随时间淡出 ——
    if (w.loopFx && w.loopPoly) {
      const k = w.loopFx.t / w.loopFx.max;
      const P = w.loopPoly;
      ctx.beginPath();
      ctx.moveTo(P.xs[0], P.ys[0]);
      for (let i = 1; i < P.n; i++) ctx.lineTo(P.xs[i], P.ys[i]);
      ctx.closePath();
      ctx.fillStyle = w.loopFx.breaking ? `rgba(255,179,71,${0.3 * k})` : `rgba(201,167,255,${0.3 * k})`;
      ctx.fill();
      ctx.strokeStyle = w.loopFx.breaking ? `rgba(255,196,120,${0.85 * k})` : `rgba(216,190,255,${0.8 * k})`;
      ctx.lineWidth = 2 + 5 * k;
      ctx.stroke();
      // 冲击波：守护是平滑立场环，破甲是锯齿碎裂环——不只换颜色，形状也不一样
      const grow = 1 - k;
      const rr = w.loopFx.r * (0.35 + 0.65 * grow);
      ctx.beginPath();
      if (w.loopFx.breaking) {
        for (let s = 0; s <= 28; s++) {
          const ang = (s / 28) * TAU;
          const rad = s % 2 ? rr * 0.78 : rr;
          const px = w.loopFx.cx + Math.cos(ang) * rad, py = w.loopFx.cy + Math.sin(ang) * rad;
          if (s === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
      } else {
        ctx.arc(w.loopFx.cx, w.loopFx.cy, rr, 0, TAU);
      }
      ctx.strokeStyle = w.loopFx.breaking ? `rgba(255,179,71,${0.7 * k})` : `rgba(201,167,255,${0.65 * k})`;
      ctx.lineWidth = 2 + 7 * k;
      ctx.stroke();
    }

    // —— 能量环：枪吃能量，只有套圈能回能。必须一眼看见「还剩多少子弹」——
    const ek = Math.max(0, Math.min(1, w.stats.energy / w.stats.energyMax));
    ctx.beginPath();
    ctx.arc(w.craft.x, w.craft.y, 27, -Math.PI / 2, -Math.PI / 2 + TAU * ek);
    ctx.strokeStyle = ek < 0.25 ? '#ff5d5d' : '#7ef9c6';
    ctx.lineWidth = 3;
    ctx.stroke();

    // 回旋强化期间：机体外套一圈金环。玩家不用读文字也知道「现在有 buff」
    if (w.loopBoost > 0) {
      const pulse = 1 + Math.sin(performance.now() / 90) * 0.05;
      ctx.beginPath();
      ctx.arc(w.craft.x, w.craft.y, 40 * pulse, 0, TAU);
      ctx.strokeStyle = 'rgba(255,225,77,0.75)';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }

    // —— 套住数量飘字：让玩家开始关心「我这圈框了几只」——
    for (const fl of w.floats) {
      const k = fl.t / fl.max;
      ctx.globalAlpha = Math.min(1, k * 1.6);
      ctx.fillStyle = fl.boost ? '#ffe14d'
        : fl.stanceSwap ? (w.stance === 'break' ? '#ffb347' : '#c9a7ff')
        : fl.fail ? '#8fa3c0' : fl.snap ? '#ff6b8a' : (fl.n >= 8 ? '#ffe14d' : (fl.n > 0 ? '#e6d5ff' : '#7ef9c6'));
      ctx.font = `700 ${20 + Math.min(16, Math.max(fl.n, fl.cleared) * 1.6)}px system-ui, sans-serif`;
      ctx.textAlign = 'center';
      const label = fl.boost ? (w.boostWord || '回旋强化')
        : fl.stanceSwap ? (w.stance === 'break' ? (w.breakWord || '破甲') : (w.guardWord || '守护'))
        : fl.fail ? (w.smallWord || '圈太小')
        : fl.snap ? (w.snapWord || '断带')
        : fl.n > 0 ? `${fl.breaking ? (w.breakWord || '破甲') : (w.loopWord || '套住')} ${fl.n} · ${fl.dmg || 0}`
          : `${w.clearWord || '清弹'} ${fl.cleared}`;
      ctx.fillText(label, fl.x, fl.y - (1 - k) * 46);
      ctx.globalAlpha = 1;
    }

    // —— 敌人 ——
    const ef = w.enemies.f;
    for (let i = 0; i < w.enemies.count; i++) {
      const p = lerpPos(ef, i, a);
      if (!vis(p.x, p.y)) continue;
      const s = sprites[w.defs[ef.kind[i]].id];
      ctx.drawImage(s.canvas, p.x - s.half, p.y - s.half);
    }
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.75;
    for (let i = 0; i < w.enemies.count; i++) {
      if (ef.flash[i] <= 0) continue;
      const p = lerpPos(ef, i, a);
      if (!vis(p.x, p.y)) continue;
      ctx.beginPath();
      ctx.arc(p.x, p.y, ef.r[i] * 0.92, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // —— 子弹：按速度方向取烘焙帧 ——
    const bf = w.bullets.f;
    for (let i = 0; i < w.bullets.count; i++) {
      const p = lerpPos(bf, i, a);
      if (!vis(p.x, p.y)) continue;
      const s = sprites.bullet[dirFrame(bf.vx[i], bf.vy[i])];
      ctx.drawImage(s.canvas, p.x - s.half, p.y - s.half);
    }
    const qf = w.ebullets.f;
    for (let i = 0; i < w.ebullets.count; i++) {
      const p = lerpPos(qf, i, a);
      if (!vis(p.x, p.y)) continue;
      const s = sprites.ebullet[dirFrame(qf.vx[i], qf.vy[i])];
      ctx.drawImage(s.canvas, p.x - s.half, p.y - s.half);
    }

    // —— 粒子 ——
    const pf = w.parts.f;
    for (let i = 0; i < w.parts.count; i++) {
      const p = lerpPos(pf, i, a);
      if (!vis(p.x, p.y)) continue;
      const s = sprites.spark[pf.kind[i] | 0] || sprites.spark[0];
      const k = pf.life[i] / pf.max[i];
      const d = 5 + k * 11;
      ctx.drawImage(s.canvas, p.x - d / 2, p.y - d / 2, d, d);
    }

    const c = w.craft;
    const cx = c.px + (c.x - c.px) * a;
    const cy = c.py + (c.y - c.py) * a;

    // —— 回旋爆发冲击波 ——
    if (w.burstFx > 0) {
      const k = w.burstFx / 0.35;
      ctx.strokeStyle = w.arena.accent;
      ctx.lineWidth = 7 * k + 1;
      ctx.globalAlpha = 0.35 + k * 0.65;
      ctx.beginPath();
      ctx.arc(cx, cy, w.stats.burstRadius * (1.1 - k * 0.35), 0, TAU);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // —— 尾迹 + 尾焰 + 玩家艇 ——
    const head = lerpAngle(c.pheading, c.heading, a);
    const aim = lerpAngle(c.paim, c.aim, a);
    pushTrail(cx, cy);
    const sp0 = sprites.spark[2];
    for (let k = 0; k < trailN; k++) {
      const idx = (trailHead - 1 - k + TRAIL * 2) % TRAIL;
      const fade = 1 - k / TRAIL;
      const d = 3 + fade * 9;
      ctx.globalAlpha = fade * 0.32;
      ctx.drawImage(sp0.canvas, trail[idx * 2] - d / 2, trail[idx * 2 + 1] - d / 2, d, d);
    }
    ctx.globalAlpha = 1;

    const cos = Math.cos(head), sin = Math.sin(head);
    const fl = sprites.flame;
    ctx.setTransform(cos, sin, -sin, cos, cx + ox, cy + oy);
    ctx.drawImage(fl.canvas, -18 - fl.len, -fl.half);
    const cs = sprites.craft;
    ctx.drawImage(cs.canvas, -cs.half, -cs.half);
    ctx.setTransform(1, 0, 0, 1, ox, oy);

    // —— 枪口指向 ——
    const ax = Math.cos(aim), ay = Math.sin(aim);
    ctx.strokeStyle = w.arena.accent;
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.moveTo(cx + ax * 24, cy + ay * 24);
    ctx.lineTo(cx + ax * 58, cy + ay * 58);
    ctx.stroke();
    ctx.globalAlpha = 1;

    // —— 鼠标准星 ——
    if (w.aimMode === 'mouse' && w.pointer) {
      const p = w.pointer;
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(p.x - 13, p.y); ctx.lineTo(p.x - 5, p.y);
      ctx.moveTo(p.x + 5, p.y); ctx.lineTo(p.x + 13, p.y);
      ctx.moveTo(p.x, p.y - 13); ctx.lineTo(p.x, p.y - 5);
      ctx.moveTo(p.x, p.y + 5); ctx.lineTo(p.x, p.y + 13);
      ctx.stroke();
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, TAU);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // —— 屏幕空间收尾：暗角 + 受击闪屏 ——
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(bg.vignette, 0, 0);
    if (w.hitFx > 0) {
      // 受击反馈只在画面边缘发红。原来整屏 25% 红覆盖会把战场糊住，
      // 玩家实测反馈「受击瞬间没法玩」——代码里并没有减速，是这层遮挡造成的读屏中断。
      const k = w.hitFx / 0.3;
      if (!hitGrad || hitW !== W || hitH !== H) {
        hitGrad = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.28, W / 2, H / 2, Math.max(W, H) * 0.62);
        hitGrad.addColorStop(0, 'rgba(255,60,60,0)');
        hitGrad.addColorStop(1, 'rgba(255,60,60,1)');
        hitW = W; hitH = H;
      }
      ctx.globalAlpha = 0.34 * k;
      ctx.fillStyle = hitGrad;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    // 姿态标识由 HUD 徽章负责（破甲橙色 / 守护紫色），不再在画布上重复写一遍大字

    // 章节横幅：给单局一个可见的中期目标
    if (w.chapterFx > 0 && w.chapterWord) {
      ctx.globalAlpha = Math.min(1, w.chapterFx / 1.2);
      ctx.textAlign = 'center';
      ctx.font = '800 46px system-ui, sans-serif';
      ctx.fillStyle = '#e9f0ff';
      ctx.fillText(w.chapterWord, W / 2, H * 0.3);
      ctx.globalAlpha = 1;
    }

    // 屏幕最上沿：经验条（紫）与能量条（青）。
    // 能量条必须常驻——枪靠能量开火，「为什么突然不打了」要能在屏幕上直接读到答案。
    const ses = w.session;
    if (ses && ses.state !== 'menu') {
      const xp = Math.max(0, Math.min(1, ses.xp / Math.max(1, ses.xpNext)));
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      ctx.fillRect(0, 0, W, 7);
      ctx.fillStyle = '#c9a7ff';
      ctx.fillRect(0, 0, W * xp, 7);

      const en = Math.max(0, Math.min(1, w.stats.energy / Math.max(1, w.stats.energyMax)));
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(0, H - 6, W, 6);
      ctx.fillStyle = en < 0.25 ? '#ff6b8a' : '#7ef9c6';
      ctx.fillRect(0, H - 6, W * en, 6);
    }
  }

  return { draw, ctx, setColorblind, setImages };
}
// 瞄准系统：把「移动」和「枪口」解耦。
// 三种模式：mouse（上限最高）/ auto（辅助，设置里可开）/ move（纯键盘无障碍）。
import { angleDelta, wrapAngle } from './mathx.mjs';

export const AIM_MODES = ['mouse', 'auto', 'move'];

/** 无限地图：方向差就是普通差值 */
function delta(from, to) {
  return to - from;
}

/** 选最近敌人 */
export function pickTarget(w, maxRange = 1100) {
  const f = w.enemies.f;
  let best = maxRange * maxRange;
  let bx = 0; let by = 0; let found = false;
  for (let i = 0; i < w.enemies.count; i++) {
    const dx = delta(w.craft.x, f.x[i]);
    const dy = delta(w.craft.y, f.y[i]);
    const d = dx * dx + dy * dy;
    if (d < best) { best = d; bx = dx; by = dy; found = true; }
  }
  return found ? { x: bx, y: by } : null;
}

/**
 * 解算本帧枪口角度，写入 craft.aim。
 * @param pointer {x,y} 世界坐标下的鼠标位置
 * @returns 本帧枪口相对上帧转过的角度（用于手感反馈）
 */
export function resolveAim(w, mode, pointer, dt) {
  const c = w.craft;
  const prev = c.aim;
  let target = c.heading;

  if (mode === 'mouse' && pointer) {
    const dx = pointer.x - c.x;
    const dy = pointer.y - c.y;
    if (dx * dx + dy * dy > 4) target = Math.atan2(dy, dx);
  } else if (mode === 'auto') {
    const t = pickTarget(w);
    if (t) target = Math.atan2(t.y, t.x);
  }

  if (mode === 'auto') {
    // 自动瞄准给一点转速上限，避免瞬间吸附导致「没有手感」
    const step = 9.0 * dt;
    const d = angleDelta(c.aim, target);
    c.aim = wrapAngle(c.aim + Math.max(-step, Math.min(step, d)));
  } else {
    c.aim = wrapAngle(target);
  }
  return angleDelta(prev, c.aim);
}
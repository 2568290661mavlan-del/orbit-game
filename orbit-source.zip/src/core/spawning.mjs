// 敌潮装配：生成预算、开场波、阶段性小 Boss。从 sim 拆出来，保证单文件行数门禁。
import { TAU } from './mathx.mjs';
import { spawnRate, takeSpawnBudget, pickEnemyKind } from './waves.mjs';

export function spawnEnemy(w, kindId, x, y, rush = 0, hpMul = 1, rMul = 1, mini = 0) {
  const ki = w.kindIndex[kindId];
  if (ki === undefined) return -1;
  const d = w.defs[ki];
  const i = w.enemies.spawn();
  if (i < 0) return -1;
  const f = w.enemies.f;
  f.x[i] = x; f.y[i] = y;
  f.px[i] = x; f.py[i] = y;
  f.hp[i] = d.hp * hpMul; f.r[i] = d.r * rMul; f.speed[i] = d.speed; f.kind[i] = ki;
  f.timer[i] = 0; f.phase[i] = w.rng.range(0, TAU);
  f.ai[i] = w.aiCode[d.ai] ?? 0;
  f.fireEvery[i] = (d.fireEvery || 1.8) * (mini ? 0.55 : 1);   // 小 Boss 打得更密，清弹才有价值
  f.flash[i] = 0; f.kx[i] = 0; f.ky[i] = 0;
  f.rush[i] = rush;
  f.snare[i] = 0; f.snx[i] = x; f.sny[i] = y;
  f.mini[i] = mini;
  return i;
}

/** 无限地图：在视野外一圈生成敌人，玩家看不到「凭空冒出来」 */
export function spawnRing(w, kindId, rush = 0, hpMul = 1, rMul = 1, mini = 0) {
  const r = w.data.tuning.view.spawnRing;
  const a = w.rng.range(0, TAU);
  return spawnEnemy(w, kindId, w.craft.x + Math.cos(a) * r, w.craft.y + Math.sin(a) * r, rush, hpMul, rMul, mini);
}

function currentMix(w) {
  const tl = w.data.waves.timeline;
  let seg = tl[0];
  for (const s of tl) { if (s.start <= w.session.t) seg = s; else break; }
  return seg.mix;
}

/** 推进本步的生成。返回本步是否有小 Boss 登场（供音效与提示用） */
export function stepSpawns(w, dt) {
  const s = w.session;
  const view = w.data.tuning.view;
  const rate = spawnRate(s.t, w.data.waves.timeline) * w.arena.rateMul;
  const n = takeSpawnBudget(w.spawnAcc, rate, dt);
  const mix = currentMix(w);
  // 开场波：无限地图里敌人从视野外走来，不预置一波会让前 20 秒无事可做
  if (!w.opened) {
    w.opened = true;
    for (let k = 0; k < view.opening; k++) spawnRing(w, pickEnemyKind(w.rng, mix), view.rushTime);
  }
  for (let k = 0; k < n; k++) spawnRing(w, pickEnemyKind(w.rng, mix));

  // 阶段性小 Boss：给单局一个「撑到下一个」的目标。复用 boss AI，缩血缩体积，
  // 带装甲所以枪几乎打不动，必须切破甲姿态用圈拆——这是姿态存在的理由。
  let miniNow = false;
  const minis = w.data.waves.miniBosses || [];
  for (let k = 0; k < minis.length; k++) {
    if (s.miniDone[k] || s.t < minis[k].at) continue;
    s.miniDone[k] = true;
    spawnRing(w, w.data.waves.bossKind, view.rushTime, minis[k].hpMul, minis[k].rMul, 1);
    miniNow = true;
  }
  if (!s.bossSpawned && s.t >= w.data.waves.bossAt) {
    s.bossSpawned = true;
    spawnRing(w, w.data.waves.bossKind);
  }
  return miniNow;
}
// 升级：抽取 + 效果叠加。全部效果由 data/upgrades.json 的 op 描述，代码不认识具体道具。
/**
 * 无放回加权抽取 n 个可选升级。
 * - 已满层的不再出现
 * - luck 提升稀有项权重（rarity 越高获益越大）
 */
export function rollChoices(rng, defs, owned, n, luck = 0) {
  const weights = Object.create(null);
  for (const id in defs) {
    const d = defs[id];
    const have = owned[id] || 0;
    if (have >= d.maxStacks) continue;
    // 前置依赖：没点到基础项就不出高级项，升级从此有树形结构而不是扁平抽奖
    if (d.req) {
      let ok = true;
      for (const k in d.req) if ((owned[k] || 0) < d.req[k]) { ok = false; break; }
      if (!ok) continue;
    }
    const rarity = d.rarity || 1;
    weights[id] = d.weight * (1 + luck * (rarity - 1));
  }
  const out = [];
  const avail = { ...weights };
  for (let k = 0; k < n; k++) {
    const id = rng.weighted(avail);
    if (id == null) break;
    out.push(id);
    delete avail[id];
  }
  return out;
}

/** 把一条升级效果作用到 stats 上。返回是否生效。 */
export function applyUpgrade(stats, def, owned) {
  const have = owned[def.id] || 0;
  if (have >= def.maxStacks) return false;
  for (const e of def.effects) {
    const cur = stats[e.stat];
    if (typeof cur !== 'number') continue;
    stats[e.stat] = e.op === 'mul' ? cur * e.value : cur + e.value;
  }
  if (def.heal) stats.hp = Math.min(stats.maxHp, stats.hp + def.heal);
  owned[def.id] = have + 1;
  return true;
}

/**
 * 组合化学反应：同时拥有指定两项即触发一次性额外加成。
 * 用组合造深度，而不是往 20 项硬上限里再塞道具。
 * @returns {string[]} 本次新触发的组合 id
 */
export function applyCombos(stats, owned, combos, applied) {
  const fired = [];
  for (const id in combos) {
    if (applied[id]) continue;
    const c = combos[id];
    if (!c.need.every((k) => (owned[k] || 0) > 0)) continue;
    for (const e of c.effects) {
      const cur = stats[e.stat];
      if (typeof cur !== 'number') continue;
      stats[e.stat] = e.op === 'mul' ? cur * e.value : cur + e.value;
    }
    applied[id] = true;
    fired.push(id);
  }
  return fired;
}

/** 选一项后会不会立刻凑出组合？用于在三选一卡片上提前告诉玩家 */
export function pendingCombo(id, owned, combos, applied) {
  for (const cid in combos) {
    if (applied[cid]) continue;
    const need = combos[cid].need;
    if (!need.includes(id)) continue;
    if (need.every((k) => k === id || (owned[k] || 0) > 0)) return cid;
  }
  return null;
}

/** 从数据表构造初始属性（含基础值），保证换数值不改代码 */
export function buildStats(base) {
  const s = { ...base };
  s.hp = base.maxHp;
  return s;
}
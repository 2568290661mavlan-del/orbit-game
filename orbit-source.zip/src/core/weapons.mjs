// 武器：自动开火。朝向即枪口方向，玩家没有开火键。
// 回旋槽的「自动爆发伤害」已在 P2-f 删除——它是与套圈同源的第二个移动核弹，独占了 73% 输出。
// 这里只保留齐射与弹药耦合；burstRadius 仍被渲染层用作蓄满时的提示环。
import { TAU } from './mathx.mjs';

/** 沿当前朝向打出一轮齐射 */
export function fireVolley(w) {
  const s = w.stats;
  const n = Math.max(1, Math.round(s.bulletCount));
  const spread = s.spread;
  for (let k = 0; k < n; k++) {
    const off = n === 1 ? 0 : (k - (n - 1) / 2) * spread;
    const a = w.craft.aim + off;
    const i = w.bullets.spawn();
    if (i < 0) return;
    const f = w.bullets.f;
    f.x[i] = w.craft.x;
    f.y[i] = w.craft.y;
    f.px[i] = f.x[i];
    f.py[i] = f.y[i];
    f.vx[i] = Math.cos(a) * s.bulletSpeed;
    f.vy[i] = Math.sin(a) * s.bulletSpeed;
    f.r[i] = s.bulletRadius;
    f.dmg[i] = s.bulletDamage;
    f.pierce[i] = s.pierce;
    f.life[i] = s.bulletLife;
  }
}

/** 推进开火冷却，返回本帧应开火次数（长卡顿后最多补 3 次，避免爆发式补帧） */
export function tickFire(w, dt) {
  w.fireCd -= dt;
  let shots = 0;
  const interval = 1 / Math.max(0.1, w.stats.fireRate);
  while (w.fireCd <= 0 && shots < 3) {
    // 弹药耦合：枪吃能量，能量只能靠套圈回。不画圈就没子弹，走位与输出被强行绑在一起。
    if (w.stats.energy < w.stats.shotCost) { w.fireCd = 0; break; }
    w.stats.energy -= w.stats.shotCost;
    w.fireCd += interval;
    shots++;
  }
  if (w.fireCd < -interval) w.fireCd = 0;
  return shots;
}

export const BURST_RING_TAU = TAU;
// 确定性随机数：同一 seed 必须产生完全相同的序列，用于可复现单局与单测。
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeRng(seed) {
  const next = mulberry32(seed);
  return {
    next,
    /** [0, n) 整数 */
    int(n) {
      return Math.floor(next() * n);
    },
    /** [lo, hi) 浮点 */
    range(lo, hi) {
      return lo + next() * (hi - lo);
    },
    pick(arr) {
      return arr[Math.floor(next() * arr.length)];
    },
    /** 按权重表取键：weights = { key: weight } */
    weighted(weights) {
      let total = 0;
      for (const k in weights) total += weights[k];
      if (total <= 0) return null;
      let r = next() * total;
      for (const k in weights) {
        r -= weights[k];
        if (r < 0) return k;
      }
      return Object.keys(weights).pop();
    },
  };
}
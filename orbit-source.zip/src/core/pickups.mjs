// 经验宝石：掉落、吸附飞行、拾取与超距回收。
// 设计要点：机体恒速 230px/s，宝石从静止加速追不上，所以「进过一次半径就锁定追踪」，
// 否则玩家直线飞过一片经验会漏捡一大半，还得掉头，手感很差。
import { grantXp } from './session.mjs';
import { spark } from './fx.mjs';

export function dropGem(w, x, y, value, kind = 0) {
  const i = w.gems.spawn();
  if (i < 0) return;
  const f = w.gems.f;
  f.x[i] = x; f.y[i] = y; f.px[i] = x; f.py[i] = y;
  f.vx[i] = 0; f.vy[i] = 0; f.pull[i] = 0;
  f.value[i] = value; f.life[i] = 22;
  f.kind[i] = kind;   // 0 = 经验宝石，1 = 能量球（清弹转化 / 破甲拆甲掉落）
  // 能量球一出现就锁定追踪：既看得见「子弹变成了能量」，又不会因为要去捡而断火力
  f.pull[i] = kind === 1 ? 1 : 0;
}

export function stepGems(w, dt, ev, sweep) {
  const gf = w.gems.f;
  const gm = w.data.tuning.gem;
  const gemCull2 = w.data.tuning.view.gemCull ** 2;
  const pr = w.stats.pickupRadius;
  sweep(w.gems, (i) => {
    gf.life[i] -= dt;
    let dx = w.craft.x - gf.x[i];
    let dy = w.craft.y - gf.y[i];
    let d = Math.hypot(dx, dy) || 1e-6;
    if (d < pr || gf.pull[i] > 0) {
      const near = d < pr ? 1 - d / pr : 1;
      const pull = gm.accel * (0.35 + 0.65 * near);
      gf.vx[i] += (dx / d) * pull * dt;
      gf.vy[i] += (dy / d) * pull * dt;
      const sp = Math.hypot(gf.vx[i], gf.vy[i]);
      if (sp > gm.maxSpeed) { const k = gm.maxSpeed / sp; gf.vx[i] *= k; gf.vy[i] *= k; }
      gf.pull[i] = 1;
    } else {
      gf.vx[i] *= gm.idleDrag; gf.vy[i] *= gm.idleDrag;
      gf.pull[i] = 0;
    }
    gf.x[i] += gf.vx[i] * dt;
    gf.y[i] += gf.vy[i] * dt;
    dx = w.craft.x - gf.x[i]; dy = w.craft.y - gf.y[i];
    d = Math.hypot(dx, dy);
    if (d < gm.collectR + w.craftR) {
      if (gf.kind[i] === 1) {
        w.stats.energy = Math.min(w.stats.energyMax, w.stats.energy + gf.value[i]);
      } else {
        ev.leveled += grantXp(w.session, gf.value[i]);
      }
      ev.gems++;
      spark(w, gf.x[i], gf.y[i], 3, gf.kind[i] === 1 ? 4 : 3, 120);
      return true;
    }
    return gf.life[i] <= 0 || (dx * dx + dy * dy > gemCull2 && gf.pull[i] <= 0);
  });
}
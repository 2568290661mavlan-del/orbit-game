// 数学工具：角度、插值、距离。全部纯函数，无副作用。
export const TAU = Math.PI * 2;

export function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

/** 把角度规约到 [-PI, PI) */
export function wrapAngle(a) {
  let x = (a + Math.PI) % TAU;
  if (x < 0) x += TAU;
  return x - Math.PI;
}

/** from → to 的最短有符号角差，值域 [-PI, PI) */
export function angleDelta(from, to) {
  return wrapAngle(to - from);
}

/** 以最大步长 maxStep 把当前角逼近目标角，返回本步实际转过的角度 */
export function approachAngle(current, target, maxStep) {
  const d = angleDelta(current, target);
  return clamp(d, -maxStep, maxStep);
}

export function dist2(ax, ay, bx, by) {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

/** 环形世界的坐标回绕 */
export function wrapPos(v, size) {
  let x = v % size;
  if (x < 0) x += size;
  return x;
}
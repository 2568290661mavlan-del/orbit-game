// 敌人行为。8 种，全部由 data/enemies.json 的 ai 字段选择，代码不认名字只认行为。
// 无限地图：坐标不再环绕，方向差就是普通差值。
import { TAU } from './mathx.mjs';

function moveToward(e, tx, ty, speed, dt, bias = 0) {
  const a = Math.atan2(ty - e.y, tx - e.x) + bias;
  e.x += Math.cos(a) * speed * dt;
  e.y += Math.sin(a) * speed * dt;
}

/**
 * 推进一步敌人。
 * @param e {x,y,hp,r,speed,timer,phase,ai,...}
 * @param ctx {cx,cy,bossX,bossY,hasBoss,fire(x,y,ang,speed)}
 */
export function stepEnemy(e, ctx, dt) {
  const { cx, cy } = ctx;
  e.timer += dt;
  switch (e.ai) {
    case 'curve': {
      // 弧线包抄：偏置随时间摆动，逼玩家画弧线而不是直线风筝
      const bias = Math.sin(e.timer * 1.7 + e.phase) * 0.75;
      moveToward(e, cx, cy, e.speed, dt, bias);
      break;
    }
    case 'keepDistance': {
      const dx = cx - e.x;
      const dy = cy - e.y;
      const d = Math.hypot(dx, dy) || 1;
      const want = 280;
      const push = d < want - 40 ? -1 : d > want + 40 ? 1 : 0;
      const a = Math.atan2(dy, dx);
      const strafe = a + Math.PI / 2;
      e.x += (Math.cos(a) * push + Math.cos(strafe) * 0.6) * e.speed * dt;
      e.y += (Math.sin(a) * push + Math.sin(strafe) * 0.6) * e.speed * dt;
      if (e.timer >= e.fireEvery) {
        e.timer = 0;
        ctx.fire(e.x, e.y, a, 240);
      }
      break;
    }
    case 'orbit': {
      const tx = ctx.hasBoss ? ctx.bossX : cx;
      const ty = ctx.hasBoss ? ctx.bossY : cy;
      const dx = tx - e.x;
      const dy = ty - e.y;
      const d = Math.hypot(dx, dy) || 1;
      const want = ctx.hasBoss ? 120 : 200;
      const a = Math.atan2(dy, dx);
      const radial = d > want ? 1 : -1;
      const tang = a + Math.PI / 2;
      e.x += (Math.cos(a) * radial * 0.8 + Math.cos(tang)) * e.speed * dt;
      e.y += (Math.sin(a) * radial * 0.8 + Math.sin(tang)) * e.speed * dt;
      break;
    }
    case 'boss': {
      moveToward(e, cx, cy, e.speed, dt);
      if (e.timer >= e.fireEvery) {
        e.timer = 0;
        const n = 12;
        for (let k = 0; k < n; k++) {
          ctx.fire(e.x, e.y, (k / n) * TAU + e.phase, 190);
        }
        e.phase += 0.22;
      }
      break;
    }
    default: {
      // chase / bomber / splitter 共用直线追击，差异体现在死亡与接触效果上
      moveToward(e, cx, cy, e.speed, dt);
      break;
    }
  }
}
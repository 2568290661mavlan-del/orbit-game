// 打击感底层：粒子发射与屏幕震动。与仿真解耦，便于单独调参与测试。
import { TAU } from './mathx.mjs';

/** 粒子：kind 0=击杀碎屑 1=命中火花 2=爆发环屑 3=拾取火花 */
export function spark(w, x, y, n, kind, speed) {
  const f = w.parts.f;
  for (let k = 0; k < n; k++) {
    const i = w.parts.spawn();
    if (i < 0) return;
    const a = w.rng.range(0, TAU);
    const s = w.rng.range(speed * 0.4, speed);
    f.x[i] = x; f.y[i] = y;
    f.px[i] = x; f.py[i] = y;
    f.vx[i] = Math.cos(a) * s; f.vy[i] = Math.sin(a) * s;
    f.max[i] = kind === 2 ? 0.5 : 0.32;
    f.life[i] = f.max[i];
    f.kind[i] = kind;
  }
}

export function addShake(w, amount) {
  w.shake = Math.min(14, w.shake + amount);
}

/** 粒子积分：阻尼 + 寿命 */
export function stepParts(w, dt, sweep) {
  const pf = w.parts.f;
  sweep(w.parts, (i) => {
    pf.x[i] += pf.vx[i] * dt;
    pf.y[i] += pf.vy[i] * dt;
    pf.vx[i] *= 0.92; pf.vy[i] *= 0.92;
    pf.life[i] -= dt;
    return pf.life[i] <= 0;
  });
}
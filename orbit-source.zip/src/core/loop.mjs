// 闭环引爆：飞行轨迹留下光带，首尾闭合即引爆圈住的一切。
// 这是本作的独占动词——枪管持续输出，走位管爆发清场。
// 纯几何，无 DOM，可单测。采样间隔与圈面积上限都在 data/tuning.json。
import { spark, addShake } from './fx.mjs';
import { sweep } from './store.mjs';
import { dropGem } from './pickups.mjs';

/** 线段相交（含端点容差），用于判定轨迹自交 */
function segHit(ax, ay, bx, by, cx, cy, dx, dy) {
  const d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
  const d2 = (bx - ax) * (dy - ay) - (by - ay) * (cx - ax);
  const d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx);
  const d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx);
  return ((d1 > 0) !== (d2 > 0)) && ((d3 > 0) !== (d4 > 0));
}

/** 射线法：点是否在多边形内 */
export function pointInPoly(px, py, xs, ys, n) {
  let inside = false;
  for (let i = 0, j = n - 1; i < n; j = i++) {
    const xi = xs[i], yi = ys[i], xj = xs[j], yj = ys[j];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi + 1e-12) + xi) inside = !inside;
  }
  return inside;
}

/** 鞋带公式：多边形面积 */
export function polyArea(xs, ys, n) {
  let a = 0;
  for (let i = 0, j = n - 1; i < n; j = i++) a += (xs[j] + xs[i]) * (ys[j] - ys[i]);
  return Math.abs(a) * 0.5;
}

export function createLoop(cap) {
  return { xs: new Float32Array(cap), ys: new Float32Array(cap), n: 0, cap, cool: 0 };
}

export function resetLoop(L) { L.n = 0; L.cool = 0; }

/**
 * 受击断带：丢掉最老的一段，保留最近的轨迹。
 * 全部清零会造成「断带 → 没圈 → 没能量 → 枪停火」的死亡螺旋；
 * 按比例丢失则让「大圈风险高、小圈活得下来」成为真正的取舍。
 */
export function cutLoop(L, keep = 0.4) {
  const keepN = Math.floor(L.n * keep);
  if (keepN <= 0) { L.n = 0; return; }
  L.xs.copyWithin(0, L.n - keepN, L.n);
  L.ys.copyWithin(0, L.n - keepN, L.n);
  L.n = keepN;
}

function push(L, x, y) {
  if (L.n >= L.cap) {
    // 满了就丢最老的点，保持轨迹长度恒定（等价于「光带有时效」）
    L.xs.copyWithin(0, 1); L.ys.copyWithin(0, 1);
    L.n = L.cap - 1;
  }
  L.xs[L.n] = x; L.ys[L.n] = y; L.n++;
}

/**
 * 推进闭环判定。返回本步引爆信息或 null。
 * @returns {{area:number, cx:number, cy:number, hits:number}|null}
 */
export function stepLoop(w, dt) {
  const cfg = w.data.tuning.loop;
  const L = w.loop;
  if (!cfg.enabled || w.loopEnabled === false) return null;
  if (L.cool > 0) L.cool -= dt;

  const c = w.craft;
  if (L.n === 0) { push(L, c.x, c.y); return null; }
  const lx = L.xs[L.n - 1], ly = L.ys[L.n - 1];
  if (Math.hypot(c.x - lx, c.y - ly) < cfg.sampleDist) return null;

  // 闭合判定有两条：① 回到历史轨迹点附近（首尾重合，严格相交测不出共端点）
  //                ② 新线段与历史线段真交叉（画了个 8 字之类的自交）
  if (L.n >= cfg.minPoints && L.cool <= 0) {
    for (let i = 0; i <= L.n - cfg.minPoints; i++) {
      if (Math.hypot(c.x - L.xs[i], c.y - L.ys[i]) <= cfg.closeDist) {
        return closeAt(w, L, i, cfg, c.x, c.y);
      }
    }
    for (let i = 0; i < L.n - 3; i++) {
      if (segHit(lx, ly, c.x, c.y, L.xs[i], L.ys[i], L.xs[i + 1], L.ys[i + 1])) {
        return closeAt(w, L, i, cfg, c.x, c.y);
      }
    }
  }
  push(L, c.x, c.y);
  return null;
}

function closeAt(w, L, i, cfg, px, py) {
  const n = L.n - i;
  const xs = L.xs.slice(i, L.n);
  const ys = L.ys.slice(i, L.n);
  const area = polyArea(xs, ys, n);
  resetLoop(L);
  L.cool = cfg.cooldown * (w.stats.loopCooldown || 1);
  push(L, px, py);
  // 大圈不再被判死：杀伤由「套住几只」决定、收口带有上限，
  // 面积上限只会惩罚玩家最爽的那一圈，而且连句解释都没有。
  // 只拒绝「误触级」的小圈，并且必须告诉玩家为什么没炸。
  if (area < cfg.minArea) {
    w.floats.push({ x: px, y: py, t: 0.8, max: 0.8, n: 0, cleared: 0, fail: 'small' });
    if (w.floats.length > 8) w.floats.shift();
    return null;
  }
  return detonate(w, xs, ys, n, area, cfg);
}

/** 点到线段距离平方：套索收口的判定带 */
function distSeg2(px, py, ax, ay, bx, by) {
  const vx = bx - ax, vy = by - ay;
  const len2 = vx * vx + vy * vy;
  let t = len2 > 0 ? (px - ax) * vx + (py - ay) * vy : 0;
  if (len2 > 0) t /= len2;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  const dx = px - (ax + vx * t), dy = py - (ay + vy * t);
  return dx * dx + dy * dy;
}

function detonate(w, xs, ys, n, area, cfg) {
  let cx = 0, cy = 0;
  for (let i = 0; i < n; i++) { cx += xs[i]; cy += ys[i]; }
  cx /= n; cy /= n;

  const breaking = w.stance === 'break';
  const band = (cfg.snareBand + (w.stats.loopBand || 0)) * (w.loopBoost > 0 ? cfg.boostMul : 1);
  const band2 = band * band;
  const inLoop = (x, y) => {
    if (pointInPoly(x, y, xs, ys, n)) return true;
    for (let k = 0, j = n - 1; k < n; j = k++) {
      if (distSeg2(x, y, xs[j], ys[j], xs[k], ys[k]) <= band2) return true;
    }
    return false;
  };

  // 守护姿态：圈是唯一的清弹手段。清掉的每发弹都变成一颗能量球掉在场上，
  // 看得见「子弹 → 能量」的转化，而不是只跳一个数字。
  let cleared = 0;
  if (!breaking) {
    const qf = w.ebullets.f;
    sweep(w.ebullets, (i) => {
      if (!inLoop(qf.x[i], qf.y[i])) return false;
      spark(w, qf.x[i], qf.y[i], 3, 3, 200);
      dropGem(w, qf.x[i], qf.y[i], cfg.clearRefill, 1);
      cleared++;
      return true;
    });
    w.session.bulletsCleared += cleared;
  }

  const f = w.enemies.f;
  const caught = [];
  for (let i = 0; i < w.enemies.count; i++) if (inLoop(f.x[i], f.y[i])) caught.push(i);
  if (!caught.length && !cleared) { w.loopMiss++; return null; }

  // 伤害由「套住几只」决定，面积只决定视觉冲击半径。
  // 姿态取舍：守护清弹回能但拆不动甲；破甲伤害翻数倍且无视装甲，但不清弹不回能。
  const N = caught.length;
  const base = w.stats.loopDamage * (0.6 + 0.4 * Math.min(1, N / cfg.caughtRef));
  const dmg = breaking ? base * cfg.breakMul : base;
  for (const i of caught) {
    const armored = w.defs[f.kind[i]].armor !== undefined;
    const mul = breaking || !armored ? 1 : cfg.guardArmorMul;
    f.hp[i] -= dmg * mul;
    w.dmg.loop += dmg * mul;
    f.flash[i] = 0.12;
    if (breaking) {
      // 破甲不留收口拖拽。击退只作用于装甲目标：把普通怪也炸散会让下一圈套不到多只，
      // 实测每圈套住从 4.45 掉到 3.85——为了手感把核心动词削弱，不划算。
      f.snare[i] = 0;
      if (armored) {
        const dx = f.x[i] - cx, dy = f.y[i] - cy;
        const d = Math.hypot(dx, dy) || 1;
        f.kx[i] += (dx / d) * cfg.breakKnock;
        f.ky[i] += (dy / d) * cfg.breakKnock;
        spark(w, f.x[i], f.y[i], 7, 0, 280);            // 甲片四溅
        // 拆甲击杀掉能量核心：破甲不回能，但会给你一颗要冒险去捡的大补
        if (f.hp[i] <= 0) dropGem(w, f.x[i], f.y[i], cfg.coreEnergy, 1);
      }
    } else {
      f.snare[i] = cfg.snareTime;
      f.snx[i] = cx; f.sny[i] = cy;
    }
  }
  if (!breaking) {
    w.stats.energy = Math.min(w.stats.energyMax,
      w.stats.energy + w.stats.loopRefillBase + w.stats.loopRefill * N);
  }

  const R = Math.min(1200, Math.sqrt(area / Math.PI) * cfg.blastMul);
  for (let i = 0; i < n; i += 2) spark(w, xs[i], ys[i], 2, breaking ? 0 : 4, 180);
  spark(w, cx, cy, 14, breaking ? 0 : 4, 320);
  addShake(w, 4 + Math.min(6, N * 0.6));
  w.loopFx = { t: cfg.fxTime, max: cfg.fxTime, r: R, cx, cy, n: N, breaking };
  w.loopPoly = { xs: Array.from(xs), ys: Array.from(ys), n };
  w.floats.push({ x: cx, y: cy, t: 0.9, max: 0.9, n: N, cleared, breaking, dmg: Math.round(dmg * N) });
  if (w.floats.length > 8) w.floats.shift();
  return { area, cx, cy, hits: N, caught: N, cleared, breaking, r: R };
}
// 空间哈希：把 O(n²) 碰撞降成近似 O(n)。桶数组复用，帧内零分配。
export function createHash(cellSize = 64) {
  const buckets = new Map();
  const free = [];

  // 无限地图：坐标可正可负且会一路增长。±32768 格 × 80px ≈ ±262 万 px，
  // 足够 30 分钟恒速飞行（约 41 万 px）；乘积 4.29e9 仍在双精度安全整数内，零分配无碰撞。
  function key(cx, cy) {
    return (cx + 32768) * 65536 + (cy + 32768);
  }

  return {
    cellSize,
    clear() {
      for (const arr of buckets.values()) {
        arr.length = 0;
        free.push(arr);
      }
      buckets.clear();
    },
    insert(x, y, idx) {
      const k = key(Math.floor(x / cellSize), Math.floor(y / cellSize));
      let arr = buckets.get(k);
      if (!arr) {
        arr = free.pop() || [];
        buckets.set(k, arr);
      }
      arr.push(idx);
    },
    /** 查询以 (x,y) 为心、半径 r 的 AABB 覆盖格内的全部实体下标，写入 out（复用数组） */
    query(x, y, r, out) {
      out.length = 0;
      const x0 = Math.floor((x - r) / cellSize);
      const x1 = Math.floor((x + r) / cellSize);
      const y0 = Math.floor((y - r) / cellSize);
      const y1 = Math.floor((y + r) / cellSize);
      for (let cy = y0; cy <= y1; cy++) {
        for (let cx = x0; cx <= x1; cx++) {
          const arr = buckets.get(key(cx, cy));
          if (!arr) continue;
          for (let i = 0; i < arr.length; i++) out.push(arr[i]);
        }
      }
      return out;
    },
    get bucketCount() {
      return buckets.size;
    },
  };
}
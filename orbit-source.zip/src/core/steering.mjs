// 核心手感：恒速前进 + 转向角速度上限 + 回旋槽。
// 设计约束：不可停（物理上排除站桩）；朝向即枪口方向；反向抖动不刷槽。
import { TAU, approachAngle, wrapAngle } from './mathx.mjs';

export const STEER_DEFAULTS = {
  speed: 230,          // px/s，恒速
  turnRate: 3.4,       // rad/s，决定转弯半径 = speed / turnRate ≈ 68px
  orbitGain: 1.0,      // 转过的弧度 → 回旋能量的转换率
  reverseGain: 0.35,   // 反向转向时的蓄能效率（降速而非清零）
  orbitThreshold: TAU, // 累计一整圈触发一次环形爆发
  worldW: 1920,
  worldH: 1080,
  deadzone: 0.15,
};

export function createCraft(x, y, heading = 0) {
  return {
    x, y, heading,
    px: x, py: y, pheading: heading, paim: heading,   // 渲染插值用的上一步快照
    aim: heading,    // 枪口角度，与移动朝向解耦
    orbit: 0,        // 当前回旋槽能量（弧度）
    turnSign: 0,     // 当前连续转向方向，反向即清零
    totalTurn: 0,    // 本局累计转向，用于结算复盘
    bursts: 0,
  };
}

/**
 * 推进一步。axis 为输入方向向量（键盘 8 向或摇杆），无输入时保持当前朝向继续飞。
 * @returns {{turned:number, burst:boolean}}
 */
export function stepCraft(c, axisX, axisY, dt, cfg = STEER_DEFAULTS) {
  let turned = 0;
  let burst = false;
  const mag = Math.hypot(axisX, axisY);

  if (mag > cfg.deadzone) {
    const target = Math.atan2(axisY, axisX);
    turned = approachAngle(c.heading, target, cfg.turnRate * dt);
    c.heading = wrapAngle(c.heading + turned);
    c.totalTurn += Math.abs(turned);

    const sign = Math.sign(turned);
    if (sign !== 0) {
      // 画弧线蓄能最快；反向微调只降效率，不清零。
      // （清零版本实测会让玩家一换目标就丢光能量，与「转向即瞄准」冲突）
      const eff = c.turnSign !== 0 && sign !== c.turnSign ? cfg.reverseGain : 1;
      c.orbit += Math.abs(turned) * cfg.orbitGain * eff;
      c.turnSign = sign;
      if (c.orbit >= cfg.orbitThreshold) {
        c.orbit -= cfg.orbitThreshold;
        c.bursts += 1;
        burst = true;
      }
    }
  }

  // 恒速：无论有没有输入都在动。无限地图，坐标不环绕。
  c.x += Math.cos(c.heading) * cfg.speed * dt;
  c.y += Math.sin(c.heading) * cfg.speed * dt;
  return { turned, burst };
}

/** 转弯半径：难度与手感的核心可调量 */
export function turnRadius(cfg = STEER_DEFAULTS) {
  return cfg.speed / cfg.turnRate;
}
// 单局状态机与结算复盘。纯状态，无 DOM、无渲染。
import { xpToNext } from './combat.mjs';

export const STATE = {
  MENU: 'menu',
  PLAYING: 'playing',
  LEVELUP: 'levelup',
  PAUSED: 'paused',
  DEAD: 'dead',
  WIN: 'win',
};

export function createSession() {
  const s = {
    state: STATE.MENU,
    seed: 0,
    t: 0,
    kills: 0,
    level: 1,
    xp: 0,
    xpNext: xpToNext(1),
    owned: Object.create(null),
    upgradePath: [],
    chain: 0,
    chainTimer: 0,
    maxChain: 0,
    lastHitBy: null,
    lastHitAt: 0,
    outcome: null,
    choices: [],
    bossSpawned: false,
    bossKilled: false,
    loopCount: 0,
    loopCaught: 0,
    loopBest: 0,
    loopMiss: 0,
    combos: Object.create(null),
    miniDone: [],
    miniKilled: 0,
    bulletsCleared: 0,
  };
  return s;
}

export function resetRun(s, seed) {
  s.state = STATE.PLAYING;
  s.seed = seed >>> 0;
  s.t = 0;
  s.kills = 0;
  s.level = 1;
  s.xp = 0;
  s.xpNext = xpToNext(1);
  s.owned = Object.create(null);
  s.upgradePath.length = 0;
  s.chain = 0;
  s.chainTimer = 0;
  s.maxChain = 0;
  s.lastHitBy = null;
  s.lastHitAt = 0;
  s.outcome = null;
  s.choices.length = 0;
  s.bossSpawned = false;
  s.bossKilled = false;
  s.loopCount = 0; s.loopCaught = 0; s.loopBest = 0; s.loopMiss = 0;
  s.miniDone.length = 0; s.miniKilled = 0; s.bulletsCleared = 0;
  s.combos = Object.create(null);
  return s;
}

/** 连锁：窗口内连续击杀累加，超时清零。结算里用它解释「我这局打得多顺」 */
export function registerKill(s, chainWindow = 1.6) {
  s.kills++;
  s.chain++;
  s.chainTimer = chainWindow;
  if (s.chain > s.maxChain) s.maxChain = s.chain;
}

export function tickChain(s, dt) {
  if (s.chainTimer > 0) {
    s.chainTimer -= dt;
    if (s.chainTimer <= 0) {
      s.chainTimer = 0;
      s.chain = 0;
    }
  }
}

export function grantXp(s, amount) {
  s.xp += amount;
  let leveled = 0;
  while (s.xp >= s.xpNext) {
    s.xp -= s.xpNext;
    s.level++;
    s.xpNext = xpToNext(s.level);
    leveled++;
  }
  return leveled;
}

export function enterLevelUp(s, choices) {
  s.choices = choices;
  s.state = STATE.LEVELUP;
}

export function confirmChoice(s, id) {
  if (s.state !== STATE.LEVELUP) return false;
  s.upgradePath.push({ t: Math.round(s.t), id, level: s.level });
  s.choices = [];
  s.state = STATE.PLAYING;
  return true;
}

export function recordHit(s, sourceKind) {
  s.lastHitBy = sourceKind;
  s.lastHitAt = s.t;
}

export function endRun(s, outcome) {
  s.outcome = outcome;
  s.state = outcome === 'win' ? STATE.WIN : STATE.DEAD;
}

/** 结算页数据：玩家必须能回答「我为什么输」 */
export function summarize(s) {
  return {
    outcome: s.outcome,
    survived: s.t,
    kills: s.kills,
    level: s.level,
    maxChain: s.maxChain,
    lastHitBy: s.lastHitBy,
    lastHitAt: s.lastHitAt,
    upgradePath: s.upgradePath.slice(),
    loopCount: s.loopCount,
    loopCaught: s.loopCaught,
    loopBest: s.loopBest,
    miniKilled: s.miniKilled,
    bulletsCleared: s.bulletsCleared,
    seed: s.seed,
  };
}
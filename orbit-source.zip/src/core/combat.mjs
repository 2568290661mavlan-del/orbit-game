// 伤害与碰撞判定。纯函数，便于单测覆盖「失败有代价且可理解」。
import { dist2 } from './mathx.mjs';

export function circleOverlap(ax, ay, ar, bx, by, br) {
  const r = ar + br;
  return dist2(ax, ay, bx, by) <= r * r;
}

/** 减伤上限 0.75，防止叠成无敌 */
export function mitigate(amount, reduction) {
  const r = reduction < 0 ? 0 : reduction > 0.75 ? 0.75 : reduction;
  return amount * (1 - r);
}

/**
 * 玩家受击。无敌帧内返回 0（不扣血、不刷新来源）。
 * @param ctx {hp, invuln, reduction}
 * @returns 实际扣血量
 */
export function hurtCraft(ctx, amount, dt) {
  if (ctx.invuln > 0) return 0;
  const dealt = mitigate(amount, ctx.reduction);
  ctx.hp -= dealt;
  if (ctx.hp < 0) ctx.hp = 0;
  return dealt;
}

export function tickInvuln(ctx, dt, iframes) {
  if (ctx.invuln > 0) {
    ctx.invuln -= dt;
    if (ctx.invuln < 0) ctx.invuln = 0;
  }
  return ctx.invuln;
}

/** 击杀返还的经验 */
export function xpFor(baseXp, xpGain) {
  return baseXp * xpGain;
}

/** 升级所需经验：缓增曲线，保证 ~30 秒一次升级节奏 */
export function xpToNext(level, curve = 1.35, base = 5) {
  return Math.round(base * Math.pow(curve, level - 1));
}
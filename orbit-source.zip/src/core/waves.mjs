// 敌潮：完全由 data/waves.json 驱动，代码内不写死任何时间点与配比。
/** 取当前时间所处的段落（最后一个 start <= t 的段） */
export function segmentAt(t, timeline) {
  let seg = timeline[0];
  for (let i = 0; i < timeline.length; i++) {
    if (timeline[i].start <= t) seg = timeline[i];
    else break;
  }
  return seg;
}

/** 当前每秒生成数：段内线性爬升 */
export function spawnRate(t, timeline) {
  const seg = segmentAt(t, timeline);
  const ramp = seg.ramp || 0;
  return seg.rate + ramp * (t - seg.start);
}

/**
 * 累积生成配额。返回本帧应生成的个数，余量保留到下一帧（不丢配额）。
 * @param acc {value:number}
 */
export function takeSpawnBudget(acc, rate, dt, maxPerFrame = 24) {
  acc.value += rate * dt;
  let n = 0;
  while (acc.value >= 1 && n < maxPerFrame) {
    acc.value -= 1;
    n++;
  }
  if (acc.value > maxPerFrame) acc.value = maxPerFrame; // 防长卡顿后爆量
  return n;
}

export function pickEnemyKind(rng, mix) {
  return rng.weighted(mix);
}

/** Boss 登场时间由数据给出 */
export function bossTime(config) {
  return config.bossAt;
}

export function isBossPhase(t, config) {
  return t >= config.bossAt;
}
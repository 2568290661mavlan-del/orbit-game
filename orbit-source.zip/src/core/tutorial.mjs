// 交互式教学：三步，全部在真实仿真里完成，不是文字墙。
// ① 画圈闭合 ② 守护清弹 ③ 破甲拆重甲。
// 教学期间不刷敌潮、机体不会死亡；完成或跳过后整局重置，进入正式对局。
import { spawnEnemy } from './spawning.mjs';
import { resetLoop } from './loop.mjs';
import { sweep } from './store.mjs';

export const TUT_STEPS = ['loop', 'clear', 'break'];

/** 把靶机放在机体周围并定住：教学要教的是「画圈」，不是「追怪」 */
function dummy(w, kind, angle, dist, hpMul = 1) {
  const i = spawnEnemy(w, kind, w.craft.x + Math.cos(angle) * dist, w.craft.y + Math.sin(angle) * dist, 0, hpMul);
  if (i >= 0) w.enemies.f.speed[i] = 0;
  return i;
}

function setup(w, step) {
  if (step === 0) {
    for (let k = 0; k < 4; k++) dummy(w, 'charger', (k / 4) * Math.PI * 2, 175);
  } else if (step === 1) {
    // 厚血炮艇：它必须活着供弹，否则玩家把它打死就永远清不到 3 发弹
    const i = dummy(w, 'shooter', 0, 330, 20);
    if (i >= 0) w.enemies.f.fireEvery[i] = 0.9;
  } else {
    // 重甲厚血：守护姿态要刮二十几圈，破甲只要几圈，姿态选择是被迫而不是被建议
    dummy(w, 'tank', 0, 250, 6);
  }
}

export function startTutorial(w) {
  w.tut = { i: 0, spawned: false, done: false, loops0: 0, cleared0: 0, kills0: 0 };
  w.arena = { ...w.arena, rateMul: 0 };   // 教学不刷敌潮
  w.stats.maxHp = 99; w.stats.hp = 99;    // 教学不死，允许放心试错
  w.opened = true;                        // 不要开场波
  resetLoop(w.loop);
  return w.tut;
}

/** 每帧调用（ev 可为 null，表示本帧未推进仿真）。返回 {advanced?, step?, done?} */
export function stepTutorial(w, ev) {
  const T = w.tut;
  if (!T || T.done || !ev) return null;
  if (!T.spawned) {
    setup(w, T.i);
    T.spawned = true;
    T.loops0 = w.session.loopCount;
    T.cleared0 = w.session.bulletsCleared;
    T.kills0 = w.session.kills;
  }
  const s = w.session;
  const ok = T.i === 0 ? s.loopCount > T.loops0
    : T.i === 1 ? s.bulletsCleared - T.cleared0 >= 3
      : s.kills > T.kills0;
  if (!ok) {
    // 防软锁：靶子被打光了而目标还没达成，就立刻补一批。
    // 否则「先把炮艇打死」会让第二步永远不会有敌弹，教学直接卡死。
    if (w.enemies.count === 0) setup(w, T.i);   // 立刻补靶，不等下一帧
    return null;
  }

  sweep(w.enemies, () => true);   // 清掉本步靶机，不带入下一步
  resetLoop(w.loop);
  T.i++;
  T.spawned = false;
  if (T.i >= TUT_STEPS.length) { T.done = true; return { done: true }; }
  return { advanced: true, step: T.i };
}

/** 跳过：直接标记完成，由装配层开正式对局 */
export function skipTutorial(w) {
  if (w.tut) w.tut.done = true;
}

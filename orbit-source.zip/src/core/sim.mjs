// 仿真装配层：固定步长推进整个世界。不引用 DOM，可在 Node 里直接跑压测与单测。
import { createCraft, stepCraft, STEER_DEFAULTS } from './steering.mjs';
import { createStore, sweep } from './store.mjs';
import { createHash } from './spatialHash.mjs';
import { circleOverlap, mitigate, xpFor } from './combat.mjs';
import { makeRng } from './rng.mjs';
import { TAU } from './mathx.mjs';
import { stepEnemy } from './ai.mjs';
import { fireVolley, tickFire } from './weapons.mjs';
import { spawnEnemy, stepSpawns } from './spawning.mjs';
export { spawnEnemy };
import { rollChoices, buildStats } from './upgrades.mjs';
import { resolveAim } from './aiming.mjs';
import { spark, addShake, stepParts } from './fx.mjs';
import { dropGem, stepGems } from './pickups.mjs';
import { createLoop, resetLoop, stepLoop, cutLoop } from './loop.mjs';
import {
  createSession, resetRun, registerKill, tickChain, grantXp,
  enterLevelUp, recordHit, endRun, STATE,
} from './session.mjs';

const CRAFT_R = 16;
const MAX_ENEMY_R = 70;
const AI_NAMES = ['chase', 'curve', 'keepDistance', 'orbit', 'boss'];

export function createWorld(data, seed = 1, arenaId = 'dawn') {
  const kinds = Object.keys(data.enemies);
  const defs = kinds.map((k) => ({ id: k, ...data.enemies[k] }));
  const kindIndex = Object.create(null);
  kinds.forEach((k, i) => { kindIndex[k] = i; });

  const c = data.tuning.caps;
  const w = {
    data, kinds, defs, kindIndex,
    W: data.tuning.worldW, H: data.tuning.worldH,
    enemies: createStore(c.enemies, ['x', 'y', 'px', 'py', 'hp', 'r', 'speed', 'kind', 'timer', 'phase', 'ai', 'fireEvery', 'flash', 'kx', 'ky', 'rush', 'snare', 'snx', 'sny', 'mini']),
    bullets: createStore(c.bullets, ['x', 'y', 'px', 'py', 'vx', 'vy', 'r', 'dmg', 'pierce', 'life', 'cd']),
    ebullets: createStore(c.ebullets, ['x', 'y', 'px', 'py', 'vx', 'vy', 'r', 'life']),
    gems: createStore(c.gems, ['x', 'y', 'px', 'py', 'vx', 'vy', 'pull', 'value', 'life', 'kind']),
    parts: createStore(c.parts, ['x', 'y', 'px', 'py', 'vx', 'vy', 'life', 'max', 'kind']),
    hash: createHash(80),
    craft: createCraft(0, 0),
    cam: { x: 0, y: 0, px: 0, py: 0 },
    loop: createLoop(220),
    loopFx: null,
    loopPoly: null,
    loopMiss: 0,
    loopBoost: 0,
    floats: [],
    dmg: { gun: 0, loop: 0, burst: 0 },
    session: createSession(),
    stats: buildStats(data.tuning.base),
    rng: makeRng(seed),
    spawnAcc: { value: 0 },
    fireCd: 0, burstFx: 0, hitFx: 0, shake: 0,
    craftR: CRAFT_R,
    arenaId,
    aimMode: 'move',
    stance: 'guard',
    pointer: null,
    bossX: 0, bossY: 0, hasBoss: false,
    queryBuf: [],
    ev: null,
    aiCode: { chase: 0, curve: 1, keepDistance: 2, orbit: 3, boss: 4 },
  };
  resetWorld(w, seed, arenaId);
  // 复用缓冲区：把每步 5 个临时对象降到 0，消除 GC 造成的周期性微卡顿
  w.prevStores = [w.enemies, w.bullets, w.ebullets, w.gems, w.parts];
  w.evBuf = { burst: false, leveled: 0, died: false, win: false, shots: 0, kills: 0, hurt: false, hits: 0, gems: 0, loop: null, mini: false };
  w.cfgBuf = { ...STEER_DEFAULTS };
  w.ctxBuf = {
    cx: 0, cy: 0, W: w.W, H: w.H, bossX: 0, bossY: 0, hasBoss: false,
    fire: (x, y, a, sp) => enemyFire(w, x, y, a, sp),
  };
  w.eviewBuf = { x: 0, y: 0, speed: 0, timer: 0, phase: 0, ai: '', fireEvery: 0 };
  return w;
}

/** 子弹是否已飞离视野（无限地图里「场外」= 摄像机可见范围之外） */
function outOfField(x, y, w) {
  const m = w.data.tuning.view.bulletMargin;
  return Math.abs(x - w.cam.x) > w.W * 0.5 + m || Math.abs(y - w.cam.y) > w.H * 0.5 + m;
}

export function resetWorld(w, seed, arenaId = w.arenaId) {
  w.seed = seed;   // 存档要能按同一个种子重建世界
  w.enemies.clear(); w.bullets.clear(); w.ebullets.clear(); w.gems.clear(); w.parts.clear();
  w.hash.clear();
  w.arenaId = arenaId;
  w.arena = w.data.arenas[arenaId];
  const mode = w.aimMode;
  w.stats = buildStats(w.data.tuning.base);
  w.aimMode = mode;
  w.rng = makeRng(seed);
  w.spawnAcc.value = 0;
  w.fireCd = 0; w.burstFx = 0; w.hitFx = 0; w.shake = 0;
  w.invuln = 0;
  w.hasBoss = false;
  w.opened = false;
  w.chapter = 0;
  w.chapterFx = 0;
  w.bgArenaId = arenaId;
  resetLoop(w.loop);
  w.loopFx = null;
  w.loopPoly = null;
  w.loopMiss = 0;
  w.loopBoost = 0;
  w.stanceLock = false;
  w.floats.length = 0;
  w.dmg.gun = 0; w.dmg.loop = 0; w.dmg.burst = 0;
  w.craft = createCraft(w.W / 2, w.H / 2, -Math.PI / 2);
  w.cam.x = w.craft.x; w.cam.y = w.craft.y;
  w.cam.px = w.cam.x; w.cam.py = w.cam.y;
  resetRun(w.session, seed);
  return w;
}


function onEnemyDeath(w, i) {
  const f = w.enemies.f;
  const d = w.defs[f.kind[i]];
  const s = w.session;
  registerKill(s, w.data.tuning.chainWindow);
  w.ev.kills++;
  dropGem(w, f.x[i], f.y[i], xpFor(d.xp, w.stats.xpGain));
  spark(w, f.x[i], f.y[i], d.r > 28 ? 12 : 6, 0, 240);
  addShake(w, d.r > 28 ? 2.2 : 0.5);
  if (d.splitInto) {
    for (let k = 0; k < d.splitCount; k++) {
      spawnEnemy(w, d.splitInto, f.x[i] + w.rng.range(-28, 28), f.y[i] + w.rng.range(-28, 28));
    }
  }
  if (d.explodeR) {
    spark(w, f.x[i], f.y[i], 10, 2, 300);
    if (circleOverlap(w.craft.x, w.craft.y, w.craftR, f.x[i], f.y[i], d.explodeR)) {
      const dealt = hurtCraft(w, d.explodeDmg);
      if (dealt > 0) { recordHit(s, d.id); w.hitFx = 0.3; addShake(w, 2.5); w.ev.hurt = true; }
    }
  }
  if (d.ai === 'boss' && !f.mini[i]) { s.bossKilled = true; endRun(s, 'win'); addShake(w, 14); }
  if (f.mini[i]) { s.miniKilled++; addShake(w, 9); spark(w, f.x[i], f.y[i], 24, 4, 380); }
}

function enemyFire(w, x, y, ang, speed) {
  const i = w.ebullets.spawn();
  if (i < 0) return;
  const f = w.ebullets.f;
  f.x[i] = x; f.y[i] = y;
  f.px[i] = x; f.py[i] = y;
  f.vx[i] = Math.cos(ang) * speed; f.vy[i] = Math.sin(ang) * speed;
  f.r[i] = 8; f.life[i] = 4;
}

/** 渲染插值用的上一帧快照。只拷贝坐标，成本 O(n)，换来 60Hz 仿真与任意刷新率的对齐。 */
function snapshotPrev(w) {
  for (const st of w.prevStores) {
    const f = st.f;
    for (let i = 0; i < st.count; i++) { f.px[i] = f.x[i]; f.py[i] = f.y[i]; }
  }
  const c = w.craft;
  c.px = c.x; c.py = c.y; c.pheading = c.heading; c.paim = c.aim;
}

export function stepWorld(w, dt, input) {
  const s = w.session;
  if (s.state !== STATE.PLAYING) return null;
  snapshotPrev(w);
  const ev = w.evBuf;
  ev.burst = false; ev.leveled = 0; ev.died = false; ev.win = false;
  ev.shots = 0; ev.kills = 0; ev.hurt = false; ev.hits = 0; ev.gems = 0; ev.loop = null; ev.mini = false;
  ev.chapter = -1;
  w.ev = ev;
  s.t += dt;
  tickChain(s, dt);

  const cfg = w.cfgBuf;
  cfg.speed = w.stats.speed; cfg.turnRate = w.stats.turnRate;
  cfg.orbitGain = w.stats.orbitGain; cfg.orbitThreshold = w.stats.orbitThreshold;
  cfg.worldW = w.W; cfg.worldH = w.H;
  const st = stepCraft(w.craft, input.x, input.y, dt, cfg);
  // 摄像机平滑跟随：无限地图里玩家始终在画面中心附近，转向时留一点惯性
  const ck = 1 - Math.exp(-dt * w.data.tuning.view.camLerp);
  w.cam.px = w.cam.x; w.cam.py = w.cam.y;
  w.cam.x += (w.craft.x - w.cam.x) * ck;
  w.cam.y += (w.craft.y - w.cam.y) * ck;
  resolveAim(w, w.aimMode, w.pointer, dt);
  // 独占动词：轨迹闭合即引爆圈内敌人
  ev.loop = stepLoop(w, dt);
  if (w.loopFx) { w.loopFx.t -= dt; if (w.loopFx.t <= 0) { w.loopFx = null; w.loopPoly = null; } }
  // 回旋槽不再另放一个核弹（那等于第二个移动 AoE，和套圈输出同源）。
  // 蓄满一圈的收益改为：立刻解除套圈冷却，并在 6 秒内扩大套索收口带。
  if (st.burst) {
    w.loop.cool = 0;
    w.loopBoost = w.data.tuning.loop.boostTime;
    ev.burst = true;
    spark(w, w.craft.x, w.craft.y, 10, 4, 260);
    // 蓄能的收益必须当场说出来：否则玩家只看到条满了，不知道换来了什么
    w.floats.push({ x: w.craft.x, y: w.craft.y - 34, t: 1.2, max: 1.2, n: 0, cleared: 0, boost: true });
    if (w.floats.length > 8) w.floats.shift();
  }
  if (w.loopBoost > 0) w.loopBoost -= dt;
  if (w.burstFx > 0) w.burstFx -= dt;
  if (w.hitFx > 0) w.hitFx -= dt;
  if (w.shake > 0) w.shake = Math.max(0, w.shake - dt * 26);

  ev.shots = tickFire(w, dt);
  for (let k = 0; k < ev.shots; k++) fireVolley(w);

  ev.mini = stepSpawns(w, dt);

  // 章节推进：每章末尾是小 Boss，跨章给治疗与收口带强化，并切换背景配色。
  // 目的不是加内容，是把「撑过这一章」变成玩家看得见的中期目标。
  const chapters = w.data.waves.chapters || [];
  if (w.chapter + 1 < chapters.length && s.t >= chapters[w.chapter + 1].at) {
    w.chapter++;
    w.bgArenaId = chapters[w.chapter].arena;
    w.chapterFx = 3.2;
    w.loopBoost = w.data.tuning.loop.boostTime;
    w.stats.hp = Math.min(w.stats.maxHp, w.stats.hp + 2);
    ev.chapter = w.chapter;
  }
  if (w.chapterFx > 0) w.chapterFx -= dt;

  // —— 敌人 AI + 击退衰减 ——
  const ef = w.enemies.f;
  w.hasBoss = false;
  for (let i = 0; i < w.enemies.count; i++) {
    const d = w.defs[ef.kind[i]];
    if (d.ai === 'boss') { w.bossX = ef.x[i]; w.bossY = ef.y[i]; w.hasBoss = true; }
  }
  const ctx = w.ctxBuf;
  ctx.cx = w.craft.x; ctx.cy = w.craft.y;
  ctx.bossX = w.bossX; ctx.bossY = w.bossY; ctx.hasBoss = w.hasBoss;
  const eview = w.eviewBuf;
  const slow = w.enemySpeedMul || 1;
  for (let i = 0; i < w.enemies.count; i++) {
    // 入场加速：无限地图里敌人从视野外走来，开局给一段冲刺避免前 20 秒空场
    const rush = ef.rush[i] > 0 ? w.data.tuning.view.rushMul : 1;
    eview.x = ef.x[i]; eview.y = ef.y[i]; eview.speed = ef.speed[i] * slow * rush;
    if (ef.rush[i] > 0) ef.rush[i] -= dt;
    eview.timer = ef.timer[i]; eview.phase = ef.phase[i];
    eview.ai = AI_NAMES[ef.ai[i]]; eview.fireEvery = ef.fireEvery[i];
    stepEnemy(eview, ctx, dt);
    // 套索收口：被套住的敌人在 0.15 秒内被拽向圈心，AI 暂时失效
    if (ef.snare[i] > 0) {
      ef.snare[i] -= dt;
      const sx = ef.snx[i] - eview.x, sy = ef.sny[i] - eview.y;
      const sd = Math.hypot(sx, sy) || 1;
      const pull = w.data.tuning.loop.snareSpeed * dt;
      eview.x += (sx / sd) * Math.min(pull, sd);
      eview.y += (sy / sd) * Math.min(pull, sd);
    }
    ef.x[i] = eview.x + ef.kx[i] * dt;
    ef.y[i] = eview.y + ef.ky[i] * dt;
    ef.kx[i] *= 0.86; ef.ky[i] *= 0.86;
    ef.timer[i] = eview.timer; ef.phase[i] = eview.phase;
    if (ef.flash[i] > 0) ef.flash[i] -= dt;
  }

  // —— 子弹积分：出界即消失，绝不从另一侧绕回来 ——
  const bf = w.bullets.f;
  sweep(w.bullets, (i) => {
    bf.x[i] += bf.vx[i] * dt;
    bf.y[i] += bf.vy[i] * dt;
    bf.life[i] -= dt;
    if (bf.cd[i] > 0) bf.cd[i] -= dt;
    return bf.life[i] <= 0 || outOfField(bf.x[i], bf.y[i], w);
  });

  // —— 碰撞：先建哈希，只扣血不删除，保持索引稳定 ——
  w.hash.clear();
  for (let i = 0; i < w.enemies.count; i++) w.hash.insert(ef.x[i], ef.y[i], i);
  for (let b = 0; b < w.bullets.count; b++) {
    if (bf.cd[b] > 0) continue;
    const q = w.hash.query(bf.x[b], bf.y[b], bf.r[b] + MAX_ENEMY_R, w.queryBuf);
    for (let k = 0; k < q.length; k++) {
      const i = q[k];
      if (ef.hp[i] <= 0) continue;
      if (!circleOverlap(bf.x[b], bf.y[b], bf.r[b], ef.x[i], ef.y[i], ef.r[i])) continue;
      // 装甲：子弹伤害被大幅削减，闭环引爆无视装甲。圈是钥匙，不是更快的枪。
      const am = w.defs[ef.kind[i]].armor ?? 1;
      ef.hp[i] -= bf.dmg[b] * am;
      w.dmg.gun += bf.dmg[b] * am;
      ef.flash[i] = 0.09;
      ef.kx[i] += bf.vx[b] * 0.10;
      ef.ky[i] += bf.vy[b] * 0.10;
      ev.hits++;
      spark(w, bf.x[b], bf.y[b], 2, 1, 150);
      if (bf.pierce[b] > 0) { bf.pierce[b] -= 1; bf.cd[b] = 0.06; }
      else { bf.life[b] = 0; }
      break;
    }
  }
  sweep(w.bullets, (i) => bf.life[i] <= 0);

  // —— 敌人接触伤害 + 死亡结算 + 远离回收（无限地图必须回收，否则实体只增不减）——
  const cull = w.data.tuning.view.cull;
  const cull2 = cull * cull;
  sweep(w.enemies, (i) => {
    if (ef.hp[i] <= 0) { onEnemyDeath(w, i); return true; }
    const ddx = ef.x[i] - w.craft.x;
    const ddy = ef.y[i] - w.craft.y;
    if (ddx * ddx + ddy * ddy > cull2) return true;
    if (circleOverlap(w.craft.x, w.craft.y, w.craftR, ef.x[i], ef.y[i], ef.r[i])) {
      const dealt = hurtCraft(w, w.defs[ef.kind[i]].dmg);
      if (dealt > 0) { recordHit(s, w.defs[ef.kind[i]].id); w.hitFx = 0.3; addShake(w, 2.5); ev.hurt = true; }
    }
    return false;
  });

  // —— 敌弹 ——
  const qf = w.ebullets.f;
  sweep(w.ebullets, (i) => {
    qf.x[i] += qf.vx[i] * dt;
    qf.y[i] += qf.vy[i] * dt;
    qf.life[i] -= dt;
    if (outOfField(qf.x[i], qf.y[i], w)) return true;
    if (circleOverlap(w.craft.x, w.craft.y, w.craftR, qf.x[i], qf.y[i], qf.r[i])) {
      const dealt = hurtCraft(w, 1);
      if (dealt > 0) { recordHit(s, 'bullet'); w.hitFx = 0.3; addShake(w, 2); ev.hurt = true; }
      return true;
    }
    return qf.life[i] <= 0;
  });

  // —— 经验宝石：吸附飞行 / 拾取 / 超距回收 ——
  stepGems(w, dt, ev, sweep);
  if (ev.leveled > 0 && s.state === STATE.PLAYING) {
    const picks = rollChoices(w.rng, w.data.upgrades, s.owned, Math.round(w.stats.choiceCount), w.stats.luck);
    if (picks.length) enterLevelUp(s, picks);
  }

  stepParts(w, dt, sweep);

  // —— 回复与无敌帧 ——
  // 注意：hp<=0 时禁止回复，否则同一帧内会把 0 血奶成正数，玩家永远死不了。
  if (w.stats.regen > 0 && w.stats.hp > 0) {
    w.stats.hp = Math.min(w.stats.maxHp, w.stats.hp + w.stats.regen * dt);
  }
  if (w.invuln > 0) w.invuln = Math.max(0, w.invuln - dt);
  // 能量涓流：不画圈也能勉强点射，但真正的弹药来自套圈
  if (w.stats.energyRegen > 0) {
    w.stats.energy = Math.min(w.stats.energyMax, w.stats.energy + w.stats.energyRegen * dt);
  }

  // —— 闭环记账与「受伤即断带」——
  // A0：被击中一次，光带立刻断裂。大圈不再是免费的，暴露时间变成真实代价。
  if (ev.loop) {
    s.loopCount++; s.loopCaught += ev.loop.caught;
    if (ev.loop.caught > s.loopBest) s.loopBest = ev.loop.caught;
  }
  // 受击断带是明规则，但只丢最老的一段：全清会让枪断粮，形成死亡螺旋
  if (ev.hurt && w.loop.n > 0) {
    const before = w.loop.n;
    cutLoop(w.loop, w.data.tuning.loop.hurtKeep);
    spark(w, w.craft.x, w.craft.y, 8, 1, 240);
    if (before >= w.data.tuning.loop.minPoints) {
      w.floats.push({ x: w.craft.x, y: w.craft.y, t: 0.8, max: 0.8, n: 0, cleared: 0, snap: true });
      if (w.floats.length > 8) w.floats.shift();
    }
  }
  for (let i = w.floats.length - 1; i >= 0; i--) {
    w.floats[i].t -= dt;
    if (w.floats[i].t <= 0) w.floats.splice(i, 1);
  }

  if (w.stats.hp <= 0 && s.state === STATE.PLAYING) { endRun(s, 'lose'); ev.died = true; }
  if (s.bossKilled) ev.win = true;
  return ev;
}

function hurtCraft(w, amount) {
  const assist = w.assistReduction || 0;
  if (assist >= 1) return 0;              // 辅助模式：完全免伤
  if (w.invuln > 0) return 0;
  const dealt = mitigate(amount, w.stats.reduction) * (1 - assist);
  w.stats.hp = Math.max(0, w.stats.hp - dealt);
  if (dealt > 0) w.invuln = w.stats.iframes;
  return dealt;
}

export { STATE };
// 定长实体存储：SoA + Float32Array + 交换删除。
// 目的：帧内零分配、密集遍历、无 GC 抖动。容量满时拒绝生成（宁可掉敌人，不许掉帧）。
export function createStore(cap, fields) {
  const f = Object.create(null);
  for (const k of fields) f[k] = new Float32Array(cap);

  const store = {
    cap,
    count: 0,
    f,
    fields,
    /** 返回新槽位下标；容量已满返回 -1 */
    spawn() {
      if (store.count >= cap) return -1;
      return store.count++;
    },
    /** 交换删除。注意：调用后下标 i 上是另一个实体，正向遍历时需重新处理 i。 */
    kill(i) {
      if (i < 0 || i >= store.count) return false;
      const last = --store.count;
      if (i !== last) {
        for (const k of fields) f[k][i] = f[k][last];
      }
      return true;
    },
    clear() {
      store.count = 0;
    },
    get full() {
      return store.count >= cap;
    },
  };
  return store;
}

/** 安全的正向遍历删除模板：kill 后不递增下标 */
export function sweep(store, fn) {
  let i = 0;
  while (i < store.count) {
    if (fn(i) === true) store.kill(i);
    else i++;
  }
}